// WidgetBlueprintGeneratedClass WBP_PlayerLvUpTipWidget.WBP_PlayerLvUpTipWidget_C
// Size: 0x2b8 (Inherited: 0x298)
struct UWBP_PlayerLvUpTipWidget_C : UnKmRsee {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct UImage* bk; // 0x2a0(0x08)
	struct UImage* bk_2; // 0x2a8(0x08)
	struct UImage* bk_3; // 0x2b0(0x08)

	void SequenceEvent__ENTRYPOINTWBP_PlayerLvUpTipWidget_1(struct UCanvasPanel* Panel_Top); // Function WBP_PlayerLvUpTipWidget.WBP_PlayerLvUpTipWidget_C.SequenceEvent__ENTRYPOINTWBP_PlayerLvUpTipWidget_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Panel_Top_Event_1(struct UCanvasPanel* Panel_Top); // Function WBP_PlayerLvUpTipWidget.WBP_PlayerLvUpTipWidget_C.Panel_Top_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PlayerLvUpTipWidget(int32_t EntryPoint); // Function WBP_PlayerLvUpTipWidget.WBP_PlayerLvUpTipWidget_C.ExecuteUbergraph_WBP_PlayerLvUpTipWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

