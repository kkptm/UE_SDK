// BlueprintGeneratedClass BTt_JudgeJump.BTT_JudgeJump_C
// Size: 0xec (Inherited: 0xa8)
struct UBTT_JudgeJump_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector Target Actor; // 0xb8(0x28)
	float MaxDistance; // 0xe0(0x04)
	float MixDistance; // 0xe4(0x04)
	float Height; // 0xe8(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTt_JudgeJump.BTT_JudgeJump_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_JudgeJump(int32_t EntryPoint); // Function BTt_JudgeJump.BTT_JudgeJump_C.ExecuteUbergraph_BTT_JudgeJump // (Final|UbergraphFunction) // @ game+0x24b46a0
};

