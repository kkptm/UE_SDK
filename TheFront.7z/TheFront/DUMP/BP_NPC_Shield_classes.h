// BlueprintGeneratedClass BP_NPC_Shield.BP_NPC_Shield_C
// Size: 0x278 (Inherited: 0x278)
struct ABP_NPC_Shield_C : ALPUWTWe {
};

