// Class PrefabAsset.fJUSNfg
// Size: 0x248 (Inherited: 0x240)
struct AfJUSNfg : AActor {
	struct UqlWSJne* qlWSJne; // 0x240(0x08)

	void qonpSWe(bool sLhsNSf); // Function PrefabAsset.fJUSNfg.qonpSWe // (Final|Native|Public|BlueprintCallable) // @ game+0xf87f80
	void LjngWph(struct UVNtiLeg* hqLklhe, bool mLtsmSf); // Function PrefabAsset.fJUSNfg.LjngWph // (Final|Native|Public|BlueprintCallable) // @ game+0xf880c0
	struct UVNtiLeg* LiJIrke(); // Function PrefabAsset.fJUSNfg.LiJIrke // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xf88010
	void hlUPmUf(enum class EComponentMobility WMnqhmg); // Function PrefabAsset.fJUSNfg.hlUPmUf // (Final|Native|Public|BlueprintCallable) // @ game+0xf88040
};

// Class PrefabAsset.VNtiLeg
// Size: 0xd0 (Inherited: 0x28)
struct UVNtiLeg : UObject {
	struct TMap<struct FString, struct FSoftObjectPath> KelNmme; // 0x28(0x50)
	struct FSoftObjectPath IJOOVQh; // 0x78(0x18)
	struct FGuid frSJlPg; // 0x90(0x10)
	struct FString MIPLkVh; // 0xa0(0x10)
	struct FString Wltrrof; // 0xb0(0x10)
	int32_t SgptlOh; // 0xc0(0x04)
	struct FVector VRHhjSh; // 0xc4(0x0c)
};

// Class PrefabAsset.Vepfpkg
// Size: 0xd8 (Inherited: 0xd0)
struct UVepfpkg : UVNtiLeg {
	struct UVNtiLeg* LWLonVe; // 0xd0(0x08)
};

// Class PrefabAsset.qlWSJne
// Size: 0x520 (Inherited: 0x4a0)
struct UqlWSJne : UPrimitiveComponent {
	char WOInrfg : 1; // 0x4a0(0x01)
	char gMTipff : 1; // 0x4a0(0x01)
	char pad_4A0_2 : 6; // 0x4a0(0x01)
	char pad_4A1[0x7]; // 0x4a1(0x07)
	struct UVNtiLeg* VVTtIof; // 0x4a8(0x08)
	struct UBlueprint* siHJopf; // 0x4b0(0x08)
	struct TMap<struct FName, struct AActor*> tliJqRg; // 0x4b8(0x50)
	struct TArray<struct FlPrULPg> rNTtIWe; // 0x508(0x10)
	char VeJnNJe : 1; // 0x518(0x01)
	char pad_518_1 : 7; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)
};

// Class PrefabAsset.gpRNemh
// Size: 0x28 (Inherited: 0x28)
struct UgpRNemh : UBlueprintFunctionLibrary {

	struct AfJUSNfg* TeoeRKh(struct UObject* QIekWUh, struct UVNtiLeg* VNtiLeg, struct FTransform& kRrtOOf, struct TArray<struct AActor*>& lrtSSNe, bool JsMqWlh, enum class ESpawnActorCollisionHandlingMethod qmqJKNe, struct AActor* WghQsTg); // Function PrefabAsset.gpRNemh.TeoeRKh // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xf88190
};

// Class PrefabAsset.MMotiig
// Size: 0x78 (Inherited: 0x78)
struct UMMotiig : UExporter {
};

// Class PrefabAsset.NOQhqHf
// Size: 0x88 (Inherited: 0x78)
struct UNOQhqHf : UMMotiig {
	char pad_78[0x10]; // 0x78(0x10)
};

// Class PrefabAsset.TUPnhIe
// Size: 0x78 (Inherited: 0x78)
struct UTUPnhIe : UMMotiig {
};

// Class PrefabAsset.fHpHekh
// Size: 0x100 (Inherited: 0x28)
struct UfHpHekh : UObject {
	bool bReplaceActorsWithCreatedPrefab; // 0x28(0x01)
	bool bAutoIncludeAttachedActorsWhenCreateNewPrefab; // 0x29(0x01)
	bool bNestedPrefabSupport; // 0x2a(0x01)
	bool bRestorePrefabActorCollapseStatusAfterPIE; // 0x2b(0x01)
	bool bCollapseAllPrefabActorsAfterMapOpened; // 0x2c(0x01)
	bool bMoveActorsInWorldAfterSetPrefabPivot; // 0x2d(0x01)
	bool bDuplicateNoRevertWithOffset; // 0x2e(0x01)
	char pad_2F[0x1]; // 0x2f(0x01)
	struct FString NewPrefabNamePattern; // 0x30(0x10)
	enum class EPTUITheme UITheme; // 0x40(0x04)
	bool bUpdateAllPrefabActorsWhenOpenMap; // 0x44(0x01)
	bool bCheckPrefabChangeBeforeUpdateAllPrefabActorsWhenOpenMap; // 0x45(0x01)
	bool bUpdateAllPrefabActorsWhenApply; // 0x46(0x01)
	bool bApplyToNestedPrefab; // 0x47(0x01)
	bool bEnableApplyFromDisconnectedPrefabActor; // 0x48(0x01)
	bool bTryQuickApplyFirstWhenApply; // 0x49(0x01)
	bool bAutoAddRemoveVariantActorPrefix; // 0x4a(0x01)
	char pad_4B[0x5]; // 0x4b(0x05)
	struct FString VariantActorPrefix; // 0x50(0x10)
	bool bEnablePrefabComponentVisualizer; // 0x60(0x01)
	enum class EPrefabVisualizerType PrefabComponentVisualizerType; // 0x61(0x01)
	bool bDisplayPrefabComponentVisualizerEvenNotSelected; // 0x62(0x01)
	char pad_63[0x1]; // 0x63(0x01)
	struct FColor PrefabViewVisualizerColor; // 0x64(0x04)
	struct FColor TargetActorColor; // 0x68(0x04)
	struct FColor UnLockedConnectedColor; // 0x6c(0x04)
	struct FColor LockedConnectedColor; // 0x70(0x04)
	struct FColor UnLockedDisConnectedColor; // 0x74(0x04)
	struct FColor LockedDisConnectedColor; // 0x78(0x04)
	struct FColor UnLockedNoPrefabAssignedColor; // 0x7c(0x04)
	struct FColor LockedNoPrefabAssignedColor; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FSoftObjectPath PrefabMaterialPath; // 0x88(0x18)
	char pad_A0[0x28]; // 0xa0(0x28)
	bool bShadedPrefabViewVisualizer; // 0xc8(0x01)
	bool bLockPrefabSelectionByDefault; // 0xc9(0x01)
	bool bDisableLockPrefabSelectionFeature; // 0xca(0x01)
	bool bForceApplyPerInstanceVertexColor; // 0xcb(0x01)
	bool bHideChildActorsInPIEIfHiddenInEditor; // 0xcc(0x01)
	bool bCanToggleChildActorVisibilityInPIE; // 0xcd(0x01)
	char pad_CE[0x1]; // 0xce(0x01)
	bool bIgnoreLayersInPrefab; // 0xcf(0x01)
	bool bSupportGenerateBlueprint; // 0xd0(0x01)
	bool bHarvestComponentsWhenGeneratingBlueprint; // 0xd1(0x01)
	bool bUseActorNameAsVariableNameWhenGeneratingBlueprint; // 0xd2(0x01)
	bool bForceMobilityToMovableWhenGeneratingBlueprint; // 0xd3(0x01)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TArray<struct AActor*> IgnoreActorClassesWhenGeneratingBlueprint; // 0xd8(0x10)
	struct TArray<struct FName> IgnoreActorTagsWhenGeneratingBlueprint; // 0xe8(0x10)
	bool bFlashPrefabWindowForTargetPrefabActor; // 0xf8(0x01)
	bool bEnablePrefabTextEditor; // 0xf9(0x01)
	bool bDebugMode; // 0xfa(0x01)
	bool bDisableThumbnailRender; // 0xfb(0x01)
	bool bShowPrefabInstanceTagInPrefabToolWindow; // 0xfc(0x01)
	bool bSkipActorReferenceReplacement; // 0xfd(0x01)
	char pad_FE[0x2]; // 0xfe(0x02)
};

