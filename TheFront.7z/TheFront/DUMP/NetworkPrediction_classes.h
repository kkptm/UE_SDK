// Class NetworkPrediction.NetworkPhysicsManager
// Size: 0xa0 (Inherited: 0x30)
struct UNetworkPhysicsManager : UWorldSubsystem {
	char pad_30[0x70]; // 0x30(0x70)
};

// Class NetworkPrediction.NetworkPhysicsComponent
// Size: 0x130 (Inherited: 0xe0)
struct UNetworkPhysicsComponent : UActorComponent {
	struct FNetworkPhysicsState NetworkPhysicsState; // 0xe0(0x50)
};

// Class NetworkPrediction.NetworkPredictionComponent
// Size: 0x2d0 (Inherited: 0xe0)
struct UNetworkPredictionComponent : UActorComponent {
	struct FNetworkPredictionProxy NetworkPredictionProxy; // 0xe0(0xb0)
	struct FReplicationProxy ReplicationProxy_ServerRPC; // 0x190(0x50)
	struct FReplicationProxy ReplicationProxy_Autonomous; // 0x1e0(0x50)
	struct FReplicationProxy ReplicationProxy_Simulated; // 0x230(0x50)
	struct FReplicationProxy ReplicationProxy_Replay; // 0x280(0x50)

	void ServerReceiveClientInput(struct FServerReplicationRPCParameter ProxyParameter); // Function NetworkPrediction.NetworkPredictionComponent.ServerReceiveClientInput // (Net|Native|Event|Protected|NetServer|NetValidate) // @ game+0xef2ba0
};

// Class NetworkPrediction.NetworkPredictionPhysicsComponent
// Size: 0x200 (Inherited: 0xe0)
struct UNetworkPredictionPhysicsComponent : UActorComponent {
	struct FNetworkPredictionProxy NetworkPredictionProxy; // 0xe0(0xb0)
	struct UPrimitiveComponent* UpdatedPrimitive; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
	struct FReplicationProxy ReplicationProxy; // 0x1a0(0x50)
	char pad_1F0[0x10]; // 0x1f0(0x10)
};

// Class NetworkPrediction.NetworkPredictionReplicatedManager
// Size: 0x250 (Inherited: 0x240)
struct ANetworkPredictionReplicatedManager : AActor {
	struct FSharedPackageMap SharedPackageMap; // 0x240(0x10)
};

// Class NetworkPrediction.NetworkPredictionSettingsObject
// Size: 0x50 (Inherited: 0x28)
struct UNetworkPredictionSettingsObject : UObject {
	struct FNetworkPredictionSettings Settings; // 0x28(0x28)
};

// Class NetworkPrediction.NetworkPredictionWorldManager
// Size: 0x698 (Inherited: 0x30)
struct UNetworkPredictionWorldManager : UWorldSubsystem {
	struct ANetworkPredictionReplicatedManager* ReplicatedManager; // 0x30(0x08)
	char pad_38[0x660]; // 0x38(0x660)
};

