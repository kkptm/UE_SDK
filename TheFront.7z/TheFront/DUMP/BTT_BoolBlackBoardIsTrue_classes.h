// BlueprintGeneratedClass BTT_BoolBlackBoardIsTrue.BTT_BoolBlackBoardIsTrue_C
// Size: 0xd8 (Inherited: 0xa8)
struct UBTT_BoolBlackBoardIsTrue_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector Key; // 0xb0(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_BoolBlackBoardIsTrue.BTT_BoolBlackBoardIsTrue_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_BoolBlackBoardIsTrue(int32_t EntryPoint); // Function BTT_BoolBlackBoardIsTrue.BTT_BoolBlackBoardIsTrue_C.ExecuteUbergraph_BTT_BoolBlackBoardIsTrue // (Final|UbergraphFunction) // @ game+0x24b46a0
};

