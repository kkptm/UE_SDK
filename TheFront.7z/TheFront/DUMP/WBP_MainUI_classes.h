// WidgetBlueprintGeneratedClass WBP_MainUI.WBP_MainUI_C
// Size: 0x2d8 (Inherited: 0x2a8)
struct UWBP_MainUI_C : UNqTJrff {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UImage* CompassBG; // 0x2b0(0x08)
	struct UImage* Image_Compass; // 0x2b8(0x08)
	struct UWBP_MarkPointDirWidget_C* WBP_MarkPointDirWidget; // 0x2c0(0x08)
	struct UWBP_MiscNotificationWidget_C* WBP_MiscNotificationWidget; // 0x2c8(0x08)
	struct UWBP_PlayerLevelWidget_C* WBP_PlayerLevelWidget; // 0x2d0(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_MainUI.WBP_MainUI_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ResetPersonWeaponPanelData(); // Function WBP_MainUI.WBP_MainUI_C.ResetPersonWeaponPanelData // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_MainUI_Func(bool Yes); // Function WBP_MainUI.WBP_MainUI_C.BPCall_MainUI_Func // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_MainUI(int32_t EntryPoint); // Function WBP_MainUI.WBP_MainUI_C.ExecuteUbergraph_WBP_MainUI // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

