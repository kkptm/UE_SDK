// BlueprintGeneratedClass Exe_Damage_Power.Exe_Damage_Power_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_Power_C : UreLVite {
};

