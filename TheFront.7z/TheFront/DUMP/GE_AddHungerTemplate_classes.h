// BlueprintGeneratedClass GE_AddHungerTemplate.GE_AddHungerTemplate_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AddHungerTemplate_C : UGameplayEffect {
};

