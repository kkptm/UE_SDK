// BlueprintGeneratedClass GE_SpicyRoastMeat.GE_SpicyRoastMeat_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_SpicyRoastMeat_C : UGameplayEffect {
};

