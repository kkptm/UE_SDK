// WidgetBlueprintGeneratedClass WBP_MainForm_Game.WBP_MainForm_Game_C
// Size: 0x548 (Inherited: 0x490)
struct UWBP_MainForm_Game_C : UnimUWQe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	struct UWidgetAnimation* BreathRapidAnimation; // 0x498(0x08)
	struct UImage* BreathIcon; // 0x4a0(0x08)
	struct UConstructTestBP_C* FormConstructTestBP; // 0x4a8(0x08)
	struct UFormTrusteePanelBP_C* FormConstructTrusteePanelBP; // 0x4b0(0x08)
	struct UFormRmtSwResetChannelBP_C* FormRmtSwResetChannelBP; // 0x4b8(0x08)
	struct UImage* Image_64; // 0x4c0(0x08)
	struct UOverlay* Overlay_DamageDirection; // 0x4c8(0x08)
	struct UWBP_GunAimCross_C* WBP_GunAimCross; // 0x4d0(0x08)
	struct UWBP_WorldMap_C* WorldMap; // 0x4d8(0x08)
	struct TMap<struct TSoftObjectPtr<ApfSONSe>, struct UObject*> Map_CharactorToArrow; // 0x4e0(0x50)
	struct FVector DamageSourceLocation; // 0x530(0x0c)
	char pad_53C[0x4]; // 0x53c(0x04)
	struct UObject* NewVar_1; // 0x540(0x08)

	void ShowMainUI(bool Show); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.ShowMainUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void IsShowMainUI(bool& Show); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.IsShowMainUI // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ToggleHUD(); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.ToggleHUD // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_SCHI(struct FVector2D& Coord2D); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.BPCall_SCHI // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ClearnDamageDirection(); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.ClearnDamageDirection // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_OnToggleChat(); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.BPCall_OnToggleChat // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_OnReceiveChatMessage(enum class EChatChannel Channel, struct FString Account, struct FText& MsgText); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.BPCall_OnReceiveChatMessage // (HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void PlayBreathAnimation(); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.PlayBreathAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void StopBreathAnimation(); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.StopBreathAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_Ch01(enum class EChatChannel Channel); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.BPCall_Ch01 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_OnReCM(enum class EChatChannel C, struct FString A, struct FText& M); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.BPCall_OnReCM // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_MainForm_Game(int32_t EntryPoint); // Function WBP_MainForm_Game.WBP_MainForm_Game_C.ExecuteUbergraph_WBP_MainForm_Game // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

