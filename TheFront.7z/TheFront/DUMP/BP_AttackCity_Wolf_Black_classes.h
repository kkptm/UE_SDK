// BlueprintGeneratedClass BP_AttackCity_Wolf_Black.BP_AttackCity_Wolf_Black_C
// Size: 0x14f8 (Inherited: 0x14e0)
struct ABP_AttackCity_Wolf_Black_C : AqjpNNMe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x14e0(0x08)
	struct UStaticMeshComponent* NPC_Wolf_collar; // 0x14e8(0x08)
	struct UrfnLLpg* Ak_HItSound; // 0x14f0(0x08)

	void BPCall_F2(struct FHitResult& P1, struct UtriMsng* P2, enum class EAmmoHitResult P3); // Function BP_AttackCity_Wolf_Black.BP_AttackCity_Wolf_Black_C.BPCall_F2 // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_AttackCity_Wolf_Black(int32_t EntryPoint); // Function BP_AttackCity_Wolf_Black.BP_AttackCity_Wolf_Black_C.ExecuteUbergraph_BP_AttackCity_Wolf_Black // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

