// BlueprintGeneratedClass NavArea_Ocean.NavArea_Ocean_C
// Size: 0x48 (Inherited: 0x48)
struct UNavArea_Ocean_C : UNavArea {
};

