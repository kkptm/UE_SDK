// BlueprintGeneratedClass BTT_FindLocationForPatrol.BTT_FindLocationForPatrol_C
// Size: 0x100 (Inherited: 0xa8)
struct UBTT_FindLocationForPatrol_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector WKeyTargetLocation; // 0xb0(0x28)
	struct FBlackboardKeySelector SaveIdelLocation; // 0xd8(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindLocationForPatrol.BTT_FindLocationForPatrol_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FindLocationForPatrol(int32_t EntryPoint); // Function BTT_FindLocationForPatrol.BTT_FindLocationForPatrol_C.ExecuteUbergraph_BTT_FindLocationForPatrol // (Final|UbergraphFunction) // @ game+0x24b46a0
};

