// BlueprintGeneratedClass BP_ServerTagInfo.BP_ServerTagInfo_C
// Size: 0x41 (Inherited: 0x28)
struct UBP_ServerTagInfo_C : UObject {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x28(0x08)
	struct FString TagName; // 0x30(0x10)
	bool IsSelected; // 0x40(0x01)

	void SetValue(struct FString TagName, bool IsSelected); // Function BP_ServerTagInfo.BP_ServerTagInfo_C.SetValue // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_ServerTagInfo(int32_t EntryPoint); // Function BP_ServerTagInfo.BP_ServerTagInfo_C.ExecuteUbergraph_BP_ServerTagInfo // (Final|UbergraphFunction) // @ game+0x24b46a0
};

