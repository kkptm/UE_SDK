// UserDefinedEnum Enum_WeaponUI.Enum_WeaponUI
enum class Enum_WeaponUI : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator4 = 3,
	NewEnumerator5 = 4,
	NewEnumerator7 = 5,
	NewEnumerator15 = 6,
	NewEnumerator8 = 7,
	NewEnumerator9 = 8,
	NewEnumerator10 = 9,
	NewEnumerator16 = 10,
	NewEnumerator3 = 11,
	NewEnumerator12 = 12,
	NewEnumerator13 = 13,
	NewEnumerator11 = 14,
	Enum_MAX = 15
};

