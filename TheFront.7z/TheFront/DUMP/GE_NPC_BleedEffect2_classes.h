// BlueprintGeneratedClass GE_NPC_BleedEffect2.GE_NPC_BleedEffect2_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_NPC_BleedEffect2_C : UGameplayEffect {
};

