// BlueprintGeneratedClass GE_SmallMedicalBag1.GE_SmallMedicalBag1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_SmallMedicalBag1_C : UGameplayEffect {
};

