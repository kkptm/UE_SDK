// BlueprintGeneratedClass GE_AddReducedThirstTemplate.GE_AddReducedThirstTemplate_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AddReducedThirstTemplate_C : UGameplayEffect {
};

