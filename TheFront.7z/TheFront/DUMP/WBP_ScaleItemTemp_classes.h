// WidgetBlueprintGeneratedClass WBP_ScaleItemTemp.WBP_ScaleItemTemp_C
// Size: 0x328 (Inherited: 0x278)
struct UWBP_ScaleItemTemp_C : UhKIVNTe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)
	struct UImage* Image_Back; // 0x280(0x08)
	struct UImage* Image_Icon; // 0x288(0x08)
	struct UScaleBox* ScaleBox_214; // 0x290(0x08)
	struct UTextBlock* Text_Caption; // 0x298(0x08)
	struct FText Caption; // 0x2a0(0x18)
	struct FSlateColor NormalColor; // 0x2b8(0x28)
	struct FSlateColor HoverColor; // 0x2e0(0x28)
	struct UTexture2D* BackImage_Normal; // 0x308(0x08)
	struct UTexture2D* BackImage_Hover; // 0x310(0x08)
	struct UTexture2D* IconImage_Normal; // 0x318(0x08)
	struct UTexture2D* IconImage_Hover; // 0x320(0x08)

	void Setup(bool Focus); // Function WBP_ScaleItemTemp.WBP_ScaleItemTemp_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void PreConstruct(bool IsDesignTime); // Function WBP_ScaleItemTemp.WBP_ScaleItemTemp_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_ScaleItemTemp.WBP_ScaleItemTemp_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_SIT_Func3(bool Start); // Function WBP_ScaleItemTemp.WBP_ScaleItemTemp_C.BPCall_SIT_Func3 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ScaleItemTemp(int32_t EntryPoint); // Function WBP_ScaleItemTemp.WBP_ScaleItemTemp_C.ExecuteUbergraph_WBP_ScaleItemTemp // (Final|UbergraphFunction) // @ game+0x24b46a0
};

