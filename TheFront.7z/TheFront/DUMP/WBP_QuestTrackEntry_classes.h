// WidgetBlueprintGeneratedClass WBP_QuestTrackEntry.WBP_QuestTrackEntry_C
// Size: 0x2b0 (Inherited: 0x2a0)
struct UWBP_QuestTrackEntry_C : UlqnQoeg {
	struct UWBP_QuestTrackTargetWidget_C* WBP_QuestTrackTargetWidget; // 0x2a0(0x08)
	struct UWBP_QuestTrackTargetWidget_C* WBP_QuestTrackTargetWidget_2; // 0x2a8(0x08)
};

