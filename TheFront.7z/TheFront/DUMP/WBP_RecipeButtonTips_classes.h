// WidgetBlueprintGeneratedClass WBP_RecipeButtonTips.WBP_RecipeButtonTips_C
// Size: 0x2a0 (Inherited: 0x290)
struct UWBP_RecipeButtonTips_C : UrWhjOJg {
	struct UImage* Image_60; // 0x290(0x08)
	struct UImage* Image_108; // 0x298(0x08)
};

