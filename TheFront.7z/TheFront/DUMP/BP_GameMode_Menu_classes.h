// BlueprintGeneratedClass BP_GameMode_Menu.BP_GameMode_Menu_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct ABP_GameMode_Menu_C : ARsjffTe {
	struct USceneComponent* DefaultSceneRoot; // 0x2e0(0x08)
};

