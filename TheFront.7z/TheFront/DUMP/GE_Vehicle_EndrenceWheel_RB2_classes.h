// BlueprintGeneratedClass GE_Vehicle_EndrenceWheel_RB2.GE_Vehicle_EndrenceWheel_RB2_C
// Size: 0x828 (Inherited: 0x828)
struct UGE_Vehicle_EndrenceWheel_RB2_C : UTNoSqeg {
};

