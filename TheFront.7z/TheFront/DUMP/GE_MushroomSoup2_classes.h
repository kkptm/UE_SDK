// BlueprintGeneratedClass GE_MushroomSoup2.GE_MushroomSoup2_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_MushroomSoup2_C : UGameplayEffect {
};

