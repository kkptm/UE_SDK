// BlueprintGeneratedClass Weather_Override_Volume.Weather_Override_Volume_C
// Size: 0x404 (Inherited: 0x240)
struct AWeather_Override_Volume_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct URandom_Weather_Variation_C* Random_Weather_Variation; // 0x248(0x08)
	struct UBillboardComponent* Billboard; // 0x250(0x08)
	struct USplineComponent* Spline; // 0x258(0x08)
	enum class UDS_Weather_Override_Mode Mode; // 0x260(0x01)
	char pad_261[0x3]; // 0x261(0x03)
	float Transition Width; // 0x264(0x04)
	int32_t Priority; // 0x268(0x04)
	enum class UDS_WeatherTypes Weather Type; // 0x26c(0x01)
	char pad_26D[0x3]; // 0x26d(0x03)
	float Weather Intensity; // 0x270(0x04)
	float Cloud Coverage; // 0x274(0x04)
	float Wind Intensity; // 0x278(0x04)
	float  Snow; // 0x27c(0x04)
	bool Override Material Effects; // 0x280(0x01)
	char pad_281[0x3]; // 0x281(0x03)
	float Material Snow; // 0x284(0x04)
	float Material Wetness; // 0x288(0x04)
	float Scaled Transition Width; // 0x28c(0x04)
	struct AUltra_Dynamic_Weather_C* UDW; // 0x290(0x08)
	struct TMap<enum class UDS_WeatherTypes, float> Weather Type Probabilities (Spring); // 0x298(0x50)
	struct TMap<enum class UDS_WeatherTypes, float> Weather Type Probabilities (Summer); // 0x2e8(0x50)
	struct TMap<enum class UDS_WeatherTypes, float> Weather Type Probabilities (Autumn); // 0x338(0x50)
	struct TMap<enum class UDS_WeatherTypes, float> Weather Type Probabilities (Winter); // 0x388(0x50)
	float Total Sphere Bounds; // 0x3d8(0x04)
	struct FVector Spline Bounds Center; // 0x3dc(0x0c)
	bool Show Weather Label in Editor; // 0x3e8(0x01)
	char pad_3E9[0x7]; // 0x3e9(0x07)
	struct FString Key; // 0x3f0(0x10)
	float Temperature Offset; // 0x400(0x04)

	void Calculate Spline Bounds(); // Function Weather_Override_Volume.Weather_Override_Volume_C.Calculate Spline Bounds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UserConstructionScript(); // Function Weather_Override_Volume.Weather_Override_Volume_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveBeginPlay(); // Function Weather_Override_Volume.Weather_Override_Volume_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveTick(float DeltaSeconds); // Function Weather_Override_Volume.Weather_Override_Volume_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Weather_Override_Volume.Weather_Override_Volume_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void Force Start(); // Function Weather_Override_Volume.Weather_Override_Volume_C.Force Start // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Force Update Random Weather(); // Function Weather_Override_Volume.Weather_Override_Volume_C.Force Update Random Weather // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_Weather_Override_Volume(int32_t EntryPoint); // Function Weather_Override_Volume.Weather_Override_Volume_C.ExecuteUbergraph_Weather_Override_Volume // (Final|UbergraphFunction) // @ game+0x24b46a0
};

