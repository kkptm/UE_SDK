// WidgetBlueprintGeneratedClass ConstructTypeBtnBP.ConstructTypeBtnBP_C
// Size: 0x2b0 (Inherited: 0x260)
struct UConstructTypeBtnBP_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* ButtonItem; // 0x268(0x08)
	struct UImage* ImageBack; // 0x270(0x08)
	struct UTextBlock* TextBlockItem; // 0x278(0x08)
	struct FString ButtonText; // 0x280(0x10)
	int32_t StructureMainType; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct TArray<struct UUniformGridPanel*> PanelList; // 0x298(0x10)
	struct UUniformGridPanel* LinkToPanel; // 0x2a8(0x08)

	void InitMainTypeArray(struct UConstructTestBP_C* StructureSelBP); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.InitMainTypeArray // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void SetButtonText(); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.SetButtonText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void PreConstruct(bool IsDesignTime); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__ButtonItem_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.BndEvt__ButtonItem_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ConstructTypeBtnBP(int32_t EntryPoint); // Function ConstructTypeBtnBP.ConstructTypeBtnBP_C.ExecuteUbergraph_ConstructTypeBtnBP // (Final|UbergraphFunction) // @ game+0x24b46a0
};

