// BlueprintGeneratedClass GE_VehicleUnderWater.GE_VehicleUnderWater_C
// Size: 0x828 (Inherited: 0x828)
struct UGE_VehicleUnderWater_C : UTNoSqeg {
};

