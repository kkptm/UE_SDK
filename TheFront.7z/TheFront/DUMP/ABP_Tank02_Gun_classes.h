// AnimBlueprintGeneratedClass ABP_Tank02_Gun.ABP_Tank02_Gun_C
// Size: 0x724 (Inherited: 0x2d0)
struct UABP_Tank02_Gun_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose; // 0x308(0x10)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x318(0x108)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x420(0x48)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0x468(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x488(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x4a8(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x4c8(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x510(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x618(0x108)
	float Gun_Pitch; // 0x720(0x04)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_2C663C504B32C51A457C1E838660EAA5(); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_2C663C504B32C51A457C1E838660EAA5 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_863028E04C8E452FA6CCC285F0B2556E(); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_863028E04C8E452FA6CCC285F0B2556E // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_F57216174049C84C44998BA8422DA87B(); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Tank02_Gun_AnimGraphNode_ModifyBone_F57216174049C84C44998BA8422DA87B // (BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void AnimNotify_showAllAmmo(); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.AnimNotify_showAllAmmo // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Tank02_Gun(int32_t EntryPoint); // Function ABP_Tank02_Gun.ABP_Tank02_Gun_C.ExecuteUbergraph_ABP_Tank02_Gun // (Final|UbergraphFunction) // @ game+0x24b46a0
};

