// WidgetBlueprintGeneratedClass InteractToggleBP.InteractToggleBP_C
// Size: 0x288 (Inherited: 0x280)
struct UInteractToggleBP_C : UtlTiJth {
	struct UImage* ImageBackground; // 0x280(0x08)
};

