// BlueprintGeneratedClass GC_Character_Immobilized.GC_Character_Immobilized_C
// Size: 0x2b8 (Inherited: 0x2a0)
struct AGC_Character_Immobilized_C : AGameplayCueNotify_Actor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2a8(0x08)
	struct UNiagaraComponent* Buff_FireEffect; // 0x2b0(0x08)

	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Function GC_Character_Immobilized.GC_Character_Immobilized_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_GC_Character_Immobilized(int32_t EntryPoint); // Function GC_Character_Immobilized.GC_Character_Immobilized_C.ExecuteUbergraph_GC_Character_Immobilized // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

