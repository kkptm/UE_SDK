// BlueprintGeneratedClass BTT_CA_ClearBehavior.BTT_CA_ClearBehavior_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_CA_ClearBehavior_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CA_ClearBehavior.BTT_CA_ClearBehavior_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_CA_ClearBehavior(int32_t EntryPoint); // Function BTT_CA_ClearBehavior.BTT_CA_ClearBehavior_C.ExecuteUbergraph_BTT_CA_ClearBehavior // (Final|UbergraphFunction) // @ game+0x24b46a0
};

