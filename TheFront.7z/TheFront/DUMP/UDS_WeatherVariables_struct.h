// UserDefinedEnum UDS_WeatherVariables.UDS_WeatherVariables
enum class UDS_WeatherVariables : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator11 = 4,
	NewEnumerator12 = 5,
	UDS_MAX = 6
};

