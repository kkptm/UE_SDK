// WidgetBlueprintGeneratedClass WBP_InventoryItemButton.WBP_InventoryItemButton_C
// Size: 0x660 (Inherited: 0x3a8)
struct UWBP_InventoryItemButton_C : UokpsjLh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a8(0x08)
	struct UBorder* Border_28; // 0x3b0(0x08)
	struct UImage* Image_Hover; // 0x3b8(0x08)
	struct UImage* Image_Repairing; // 0x3c0(0x08)
	enum class EItemDragMode DragMode; // 0x3c8(0x01)
	bool IsInitialized; // 0x3c9(0x01)
	char pad_3CA[0x6]; // 0x3ca(0x06)
	struct UTexture2D* LockImage; // 0x3d0(0x08)
	struct UTexture2D* GridImage; // 0x3d8(0x08)
	struct UTexture2D* SelImage; // 0x3e0(0x08)
	struct FButtonStyle ButtonStyle; // 0x3e8(0x278)

	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnMouseButtonUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_1(); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.GetToolTipWidget_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnMouseMove // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Init(struct FButtonStyle Style, struct UTexture2D* SelImage); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnDrop // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnDragDetected // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnDragCancelled // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpdateItemEnable(bool IsEnable); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.BPCall_UpdateItemEnable // (BlueprintEvent) // @ game+0x24b46a0
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void OnInitialized(); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_IBE(bool bE); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.BPCall_IBE // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_InventoryItemButton(int32_t EntryPoint); // Function WBP_InventoryItemButton.WBP_InventoryItemButton_C.ExecuteUbergraph_WBP_InventoryItemButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

