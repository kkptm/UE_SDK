// AnimBlueprintGeneratedClass ABP_Hindenbury.ABP_Hindenbury_C
// Size: 0x8f1 (Inherited: 0x310)
struct UABP_Hindenbury_C : UjlfogLh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x318(0x30)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x348(0x158)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x4a0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x4c8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x4f0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x570(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x5a0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x620(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x650(0xb0)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x700(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x728(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x7a8(0x30)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x7d8(0x28)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x800(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x830(0xb0)
	bool bMoving; // 0x8e0(0x01)
	char pad_8E1[0x7]; // 0x8e1(0x07)
	struct AqjpNNMe* OwnerPawn; // 0x8e8(0x08)
	bool bDead_1; // 0x8f0(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Hindenbury.ABP_Hindenbury_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintBeginPlay(); // Function ABP_Hindenbury.ABP_Hindenbury_C.BlueprintBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Hindenbury.ABP_Hindenbury_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Hindenbury(int32_t EntryPoint); // Function ABP_Hindenbury.ABP_Hindenbury_C.ExecuteUbergraph_ABP_Hindenbury // (Final|UbergraphFunction) // @ game+0x24b46a0
};

