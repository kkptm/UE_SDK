// BlueprintGeneratedClass GE_Immobilized.GE_Immobilized_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Immobilized_C : UGameplayEffect {
};

