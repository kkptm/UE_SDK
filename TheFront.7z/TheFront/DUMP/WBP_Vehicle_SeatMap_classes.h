// WidgetBlueprintGeneratedClass WBP_Vehicle_SeatMap.WBP_Vehicle_SeatMap_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct UWBP_Vehicle_SeatMap_C : UnslJnNg {
};

