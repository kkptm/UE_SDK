// WidgetBlueprintGeneratedClass WBP_MarkPannel.WBP_MarkPannel_C
// Size: 0x308 (Inherited: 0x2b8)
struct UWBP_MarkPannel_C : UkRUJqWf {
	struct UImage* Image_2; // 0x2b8(0x08)
	struct UImage* Image_3; // 0x2c0(0x08)
	struct UImage* Image_4; // 0x2c8(0x08)
	struct UImage* Image_5; // 0x2d0(0x08)
	struct UImage* Image_6; // 0x2d8(0x08)
	struct UnlRqLnf* RadioButton_2; // 0x2e0(0x08)
	struct UnlRqLnf* RadioButton_3; // 0x2e8(0x08)
	struct UnlRqLnf* RadioButton_4; // 0x2f0(0x08)
	struct UnlRqLnf* RadioButton_5; // 0x2f8(0x08)
	struct UnlRqLnf* RadioButton_6; // 0x300(0x08)
};

