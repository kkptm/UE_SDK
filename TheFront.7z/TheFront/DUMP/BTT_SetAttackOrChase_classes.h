// BlueprintGeneratedClass BTT_SetAttackOrChase.BTT_SetAttackOrChase_C
// Size: 0xe4 (Inherited: 0xa8)
struct UBTT_SetAttackOrChase_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector KeyTargetActor; // 0xb0(0x28)
	struct AqjpNNMe* SelfActor; // 0xd8(0x08)
	int32_t WeaponIndex; // 0xe0(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetAttackOrChase.BTT_SetAttackOrChase_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_SetAttackOrChase(int32_t EntryPoint); // Function BTT_SetAttackOrChase.BTT_SetAttackOrChase_C.ExecuteUbergraph_BTT_SetAttackOrChase // (Final|UbergraphFunction) // @ game+0x24b46a0
};

