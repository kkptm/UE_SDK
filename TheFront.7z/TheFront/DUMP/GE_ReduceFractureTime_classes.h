// BlueprintGeneratedClass GE_ReduceFractureTime.GE_ReduceFractureTime_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_ReduceFractureTime_C : UGameplayEffect {
};

