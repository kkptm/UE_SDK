// BlueprintGeneratedClass BP_human_Axe.BP_human_Axe_C
// Size: 0x1518 (Inherited: 0x1508)
struct ABP_human_Axe_C : ABP_human_common_collar_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1508(0x08)
	struct USkeletalMeshComponent* SK_IronAxe; // 0x1510(0x08)
};

