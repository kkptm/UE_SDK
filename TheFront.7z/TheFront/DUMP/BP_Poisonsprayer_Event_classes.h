// BlueprintGeneratedClass BP_Poisonsprayer_Event.BP_Poisonsprayer_Event_C
// Size: 0x30 (Inherited: 0x30)
struct UBP_Poisonsprayer_Event_C : UetVgrSf {
};

