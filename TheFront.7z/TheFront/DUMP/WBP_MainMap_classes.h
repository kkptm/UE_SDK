// WidgetBlueprintGeneratedClass WBP_MainMap.WBP_MainMap_C
// Size: 0x4b0 (Inherited: 0x4a0)
struct UWBP_MainMap_C : UleTeRmg {
	struct UCanvasPanel* CanvasPanel_3; // 0x4a0(0x08)
	struct UImage* Image_145; // 0x4a8(0x08)

	void OnPaint(struct FPaintContext& Context); // Function WBP_MainMap.WBP_MainMap_C.OnPaint // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24b46a0
};

