// WidgetBlueprintGeneratedClass WBP_VehicleState_Armored.WBP_VehicleState_Armored_C
// Size: 0x420 (Inherited: 0x3e8)
struct UWBP_VehicleState_Armored_C : UMsglrmf {
	struct UImage* CompassImage_2; // 0x3e8(0x08)
	struct UImage* Image; // 0x3f0(0x08)
	struct UImage* Image_4; // 0x3f8(0x08)
	struct UImage* Image_6; // 0x400(0x08)
	struct UImage* Image_133; // 0x408(0x08)
	struct UImage* Img_Body; // 0x410(0x08)
	struct UImage* Img_Turret; // 0x418(0x08)
};

