// BlueprintGeneratedClass Exe_ReduceFractureTime_2.Exe_ReduceFractureTime_1_C
// Size: 0x68 (Inherited: 0x68)
struct UExe_ReduceFractureTime_1_C : UnKoOipe {
};

