// UserDefinedEnum UDS_NoiseType.UDS_NoiseType
enum class UDS_NoiseType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator4 = 3,
	NewEnumerator3 = 4,
	UDS_MAX = 5
};

