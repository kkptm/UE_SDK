// BlueprintGeneratedClass BTT_FindLocationToFlyFlee.BTT_FindLocationToFlyFlee_C
// Size: 0x110 (Inherited: 0xa8)
struct UBTT_FindLocationToFlyFlee_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct AActor* TargetActor; // 0xb8(0x08)
	struct FBlackboardKeySelector KeyTargetActor; // 0xc0(0x28)
	struct FBlackboardKeySelector KeyTargetLocation; // 0xe8(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindLocationToFlyFlee.BTT_FindLocationToFlyFlee_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FindLocationToFlyFlee(int32_t EntryPoint); // Function BTT_FindLocationToFlyFlee.BTT_FindLocationToFlyFlee_C.ExecuteUbergraph_BTT_FindLocationToFlyFlee // (Final|UbergraphFunction) // @ game+0x24b46a0
};

