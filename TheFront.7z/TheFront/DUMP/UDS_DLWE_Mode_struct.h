// UserDefinedEnum UDS_DLWE_Mode.UDS_DLWE_Mode
enum class UDS_DLWE_Mode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	UDS_DLWE_MAX = 3
};

