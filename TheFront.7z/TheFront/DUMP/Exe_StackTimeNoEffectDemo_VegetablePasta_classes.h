// BlueprintGeneratedClass Exe_StackTimeNoEffectDemo_VegetablePasta.Exe_StackTimeNoEffectDemo_VegetablePasta_C
// Size: 0x58 (Inherited: 0x58)
struct UExe_StackTimeNoEffectDemo_VegetablePasta_C : UMSnOjVf {
};

