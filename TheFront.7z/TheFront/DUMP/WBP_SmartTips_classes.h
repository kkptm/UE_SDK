// WidgetBlueprintGeneratedClass WBP_SmartTips.WBP_SmartTips_C
// Size: 0x2b0 (Inherited: 0x2b0)
struct UWBP_SmartTips_C : UsgTSRnh {
};

