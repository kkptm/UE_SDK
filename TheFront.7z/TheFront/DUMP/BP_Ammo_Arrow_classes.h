// BlueprintGeneratedClass BP_Ammo_Arrow.BP_Ammo_Arrow_C
// Size: 0x518 (Inherited: 0x518)
struct ABP_Ammo_Arrow_C : AjRjUpJh {
};

