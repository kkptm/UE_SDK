// WidgetBlueprintGeneratedClass WBP_PlayerLevelWidget.WBP_PlayerLevelWidget_C
// Size: 0x2b8 (Inherited: 0x2a0)
struct UWBP_PlayerLevelWidget_C : UNHILROh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a0(0x08)
	struct UImage* Image_Exp; // 0x2a8(0x08)
	struct UImage* Img_BG; // 0x2b0(0x08)

	void SequenceEvent__ENTRYPOINTWBP_PlayerLevelWidget_1(struct UTextBlock* Text_ExpChange); // Function WBP_PlayerLevelWidget.WBP_PlayerLevelWidget_C.SequenceEvent__ENTRYPOINTWBP_PlayerLevelWidget_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Text_ExpChange_Event_1(struct UTextBlock* Text_ExpChange); // Function WBP_PlayerLevelWidget.WBP_PlayerLevelWidget_C.Text_ExpChange_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PlayerLevelWidget(int32_t EntryPoint); // Function WBP_PlayerLevelWidget.WBP_PlayerLevelWidget_C.ExecuteUbergraph_WBP_PlayerLevelWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

