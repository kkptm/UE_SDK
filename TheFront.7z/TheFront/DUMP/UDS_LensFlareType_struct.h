// UserDefinedEnum UDS_LensFlareType.UDS_LensFlareType
enum class UDS_LensFlareType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	UDS_MAX = 3
};

