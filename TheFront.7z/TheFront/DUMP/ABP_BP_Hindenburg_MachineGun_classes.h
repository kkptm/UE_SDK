// AnimBlueprintGeneratedClass ABP_BP_Hindenburg_MachineGun.ABP_BP_Hindenburg_MachineGun_C
// Size: 0x7f2 (Inherited: 0x2d0)
struct UABP_BP_Hindenburg_MachineGun_C : UWonihVh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x308(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x410(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x430(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x538(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x558(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x580(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x5a8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x628(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x658(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x6d8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x708(0xb0)
	struct AjnmOlJh* OwnerPawn; // 0x7b8(0x08)
	float Delta Time X; // 0x7c0(0x04)
	char pad_7C4[0x4]; // 0x7c4(0x04)
	struct AActor* Get Target; // 0x7c8(0x08)
	float Return Value Y (Pitch); // 0x7d0(0x04)
	float Return Value Z (Yaw); // 0x7d4(0x04)
	struct FRotator Yaw_Z; // 0x7d8(0x0c)
	struct FRotator Pitch_Y; // 0x7e4(0x0c)
	bool Is Shooting; // 0x7f0(0x01)
	bool First Aim; // 0x7f1(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_BP_Hindenburg_MachineGun.ABP_BP_Hindenburg_MachineGun_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintBeginPlay(); // Function ABP_BP_Hindenburg_MachineGun.ABP_BP_Hindenburg_MachineGun_C.BlueprintBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_BP_Hindenburg_MachineGun.ABP_BP_Hindenburg_MachineGun_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_BP_Hindenburg_MachineGun(int32_t EntryPoint); // Function ABP_BP_Hindenburg_MachineGun.ABP_BP_Hindenburg_MachineGun_C.ExecuteUbergraph_ABP_BP_Hindenburg_MachineGun // (Final|UbergraphFunction) // @ game+0x24b46a0
};

