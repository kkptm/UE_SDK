// WidgetBlueprintGeneratedClass WBP_ListenServerAdvice.WBP_ListenServerAdvice_C
// Size: 0x350 (Inherited: 0x300)
struct UWBP_ListenServerAdvice_C : UJUqoRRh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct UWidgetAnimation* NoAnimation; // 0x308(0x08)
	struct UWidgetAnimation* OKAnimation; // 0x310(0x08)
	struct USrQNosh* Button_Cancel; // 0x318(0x08)
	struct USrQNosh* Button_ESC; // 0x320(0x08)
	struct USrQNosh* Button_Yes; // 0x328(0x08)
	struct UImage* Esc; // 0x330(0x08)
	struct UImage* Esc_2; // 0x338(0x08)
	struct UImage* Image_46; // 0x340(0x08)
	struct UImage* Image_82; // 0x348(0x08)

	void BndEvt__WBP_MessageDlg_Button_OK_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ListenServerAdvice.WBP_ListenServerAdvice_C.BndEvt__WBP_MessageDlg_Button_OK_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MessageDlg_Button_NO_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ListenServerAdvice.WBP_ListenServerAdvice_C.BndEvt__WBP_MessageDlg_Button_NO_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MessageDlg_Button_NO_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ListenServerAdvice.WBP_ListenServerAdvice_C.BndEvt__WBP_MessageDlg_Button_NO_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MessageDlg_Button_OK_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ListenServerAdvice.WBP_ListenServerAdvice_C.BndEvt__WBP_MessageDlg_Button_OK_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ListenServerAdvice(int32_t EntryPoint); // Function WBP_ListenServerAdvice.WBP_ListenServerAdvice_C.ExecuteUbergraph_WBP_ListenServerAdvice // (Final|UbergraphFunction) // @ game+0x24b46a0
};

