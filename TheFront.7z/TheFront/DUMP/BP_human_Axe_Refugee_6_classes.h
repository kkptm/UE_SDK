// BlueprintGeneratedClass BP_human_Axe_Refugee_6.BP_human_Axe_Refugee_5_C
// Size: 0x1518 (Inherited: 0x1518)
struct ABP_human_Axe_Refugee_5_C : ABP_human_Axe_C {
};

