// BlueprintGeneratedClass BTT_NoPathFindLocation.BTT_NoPathFindLocation_C
// Size: 0xe4 (Inherited: 0xa8)
struct UBTT_NoPathFindLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector WKey Target Location; // 0xb8(0x28)
	float Radius; // 0xe0(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_NoPathFindLocation.BTT_NoPathFindLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_NoPathFindLocation(int32_t EntryPoint); // Function BTT_NoPathFindLocation.BTT_NoPathFindLocation_C.ExecuteUbergraph_BTT_NoPathFindLocation // (Final|UbergraphFunction) // @ game+0x24b46a0
};

