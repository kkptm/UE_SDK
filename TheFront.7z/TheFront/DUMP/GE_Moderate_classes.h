// BlueprintGeneratedClass GE_Moderate.GE_Moderate_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Moderate_C : UGameplayEffect {
};

