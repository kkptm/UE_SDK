// BlueprintGeneratedClass BP_human_Spear.BP_human_Spear_C
// Size: 0x1518 (Inherited: 0x1508)
struct ABP_human_Spear_C : ABP_human_common_collar_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1508(0x08)
	struct USkeletalMeshComponent* SK_IronSpear; // 0x1510(0x08)
};

