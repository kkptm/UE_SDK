// BlueprintGeneratedClass Exe_ReduceFractureTime.Exe_ReduceFractureTime_C
// Size: 0x68 (Inherited: 0x68)
struct UExe_ReduceFractureTime_C : UnKoOipe {
};

