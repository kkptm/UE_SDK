// BlueprintGeneratedClass BP_TW_Tank03_R.BP_TW_Tank03_R_C
// Size: 0x228 (Inherited: 0x228)
struct UBP_TW_Tank03_R_C : UBP_TW_Tank03_L_C {
};

