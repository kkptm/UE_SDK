// BlueprintGeneratedClass Exe_ReduceFrostbiteTime_2.Exe_ReduceFrostbiteTime_1_C
// Size: 0x68 (Inherited: 0x68)
struct UExe_ReduceFrostbiteTime_1_C : UnKoOipe {
};

