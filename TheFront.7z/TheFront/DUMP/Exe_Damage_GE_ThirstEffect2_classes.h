// BlueprintGeneratedClass Exe_Damage_GE_ThirstEffect2.Exe_Damage_GE_ThirstEffect2_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_GE_ThirstEffect2_C : UreLVite {
};

