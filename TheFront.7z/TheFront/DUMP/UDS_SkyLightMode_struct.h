// UserDefinedEnum UDS_SkyLightMode.UDS_SkyLightMode
enum class UDS_SkyLightMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	UDS_MAX = 3
};

