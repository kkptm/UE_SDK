// BlueprintGeneratedClass BP_Grenade_NPC_CombinedVenom_Dead.BP_Grenade_NPC_CombinedVenom_Dead_C
// Size: 0x4b0 (Inherited: 0x490)
struct ABP_Grenade_NPC_CombinedVenom_Dead_C : AQVrrJOh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	struct UrfnLLpg* Ak_Bounce1; // 0x498(0x08)
	struct UNiagaraComponent* FX_NPC_Poison_Sprayer; // 0x4a0(0x08)
	struct UrfnLLpg* Ak_Bounce; // 0x4a8(0x08)

	void ReceiveBeginPlay(); // Function BP_Grenade_NPC_CombinedVenom_Dead.BP_Grenade_NPC_CombinedVenom_Dead_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Grenade_NPC_CombinedVenom_Dead.BP_Grenade_NPC_CombinedVenom_Dead_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Grenade_NPC_CombinedVenom_Dead(int32_t EntryPoint); // Function BP_Grenade_NPC_CombinedVenom_Dead.BP_Grenade_NPC_CombinedVenom_Dead_C.ExecuteUbergraph_BP_Grenade_NPC_CombinedVenom_Dead // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

