// BlueprintGeneratedClass BP_human_Unarmed_Civilians_7.BP_human_Unarmed_Civilians_6_C
// Size: 0x1510 (Inherited: 0x1510)
struct ABP_human_Unarmed_Civilians_6_C : ABP_human_C {
};

