// AnimBlueprintGeneratedClass ABP_Weapon_Bola.ABP_Weapon_Bola_C
// Size: 0x4e8 (Inherited: 0x2d0)
struct UABP_Weapon_Bola_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x308(0x48)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x350(0x90)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x3e0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x460(0x80)
	bool IsTriggered; // 0x4e0(0x01)
	char pad_4E1[0x3]; // 0x4e1(0x03)
	float Speed; // 0x4e4(0x04)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Weapon_Bola.ABP_Weapon_Bola_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Weapon_Bola.ABP_Weapon_Bola_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Weapon_Bola(int32_t EntryPoint); // Function ABP_Weapon_Bola.ABP_Weapon_Bola_C.ExecuteUbergraph_ABP_Weapon_Bola // (Final|UbergraphFunction) // @ game+0x24b46a0
};

