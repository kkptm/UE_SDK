// WidgetBlueprintGeneratedClass WBP_BoolSelectorTemplate.WBP_BoolSelectorTemplate_C
// Size: 0x3a0 (Inherited: 0x388)
struct UWBP_BoolSelectorTemplate_C : UShfJqNh {
	struct UImage* Image; // 0x388(0x08)
	struct UImage* Image_116; // 0x390(0x08)
	struct UImage* Image_194; // 0x398(0x08)
};

