// BlueprintGeneratedClass GE_TomatoEggAoup2.GE_TomatoEggAoup2_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_TomatoEggAoup2_C : UGameplayEffect {
};

