// WidgetBlueprintGeneratedClass WBP_SteamInventory.WBP_SteamInventory_C
// Size: 0x2b8 (Inherited: 0x298)
struct UWBP_SteamInventory_C : UtpeLpsh {
	struct UImage* Image_2; // 0x298(0x08)
	struct UImage* Image_3; // 0x2a0(0x08)
	struct UImage* Image_6; // 0x2a8(0x08)
	struct UImage* Image_7; // 0x2b0(0x08)
};

