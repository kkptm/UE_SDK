// WidgetBlueprintGeneratedClass WBP_ModConfigView.WBP_ModConfigView_C
// Size: 0x2c8 (Inherited: 0x288)
struct UWBP_ModConfigView_C : UQLIksJe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UButton* Button_Install; // 0x290(0x08)
	struct UButton* Button_ModBrief; // 0x298(0x08)
	struct UButton* Button_Subscribe; // 0x2a0(0x08)
	struct UButton* Button_Update; // 0x2a8(0x08)
	struct UButton* Button_UpdateAll; // 0x2b0(0x08)
	struct UImage* Image_Background; // 0x2b8(0x08)
	struct UMultiLineEditableTextBox* TextBox_ModBrief; // 0x2c0(0x08)

	struct FText Get_TextBox_ModBrief_HintText_1(); // Function WBP_ModConfigView.WBP_ModConfigView_C.Get_TextBox_ModBrief_HintText_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_Button_Install_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_Button_Install_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_Button_Update_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_Button_Update_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_Button_UpdateAll_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_Button_UpdateAll_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_Button_Subscribe_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_Button_Subscribe_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_Button_ModBrief_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_Button_ModBrief_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ModConfigView_ModConfigList_K2Node_ComponentBoundEvent_6_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_ModConfigView.WBP_ModConfigView_C.BndEvt__WBP_ModConfigView_ModConfigList_K2Node_ComponentBoundEvent_6_OnListItemSelectionChangedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ModConfigView(int32_t EntryPoint); // Function WBP_ModConfigView.WBP_ModConfigView_C.ExecuteUbergraph_WBP_ModConfigView // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

