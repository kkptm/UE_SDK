// WidgetBlueprintGeneratedClass WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C
// Size: 0x310 (Inherited: 0x278)
struct UWBP_TechScaleItemTemp_C : UhKIVNTe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)
	struct UImage* IconNormal; // 0x280(0x08)
	struct UScaleBox* ScaleBox_214; // 0x288(0x08)
	struct UTextBlock* Text_Caption; // 0x290(0x08)
	struct FText Caption; // 0x298(0x18)
	struct FSlateColor NormalColor; // 0x2b0(0x28)
	struct FSlateColor HoverColor; // 0x2d8(0x28)
	struct UTexture2D* IconImage_Normal; // 0x300(0x08)
	struct UTexture2D* IconImage_Hover; // 0x308(0x08)

	void Setup(bool Focus); // Function WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void PreConstruct(bool IsDesignTime); // Function WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_SIT_Func3(bool Start); // Function WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C.BPCall_SIT_Func3 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_TechScaleItemTemp(int32_t EntryPoint); // Function WBP_TechScaleItemTemp.WBP_TechScaleItemTemp_C.ExecuteUbergraph_WBP_TechScaleItemTemp // (Final|UbergraphFunction) // @ game+0x24b46a0
};

