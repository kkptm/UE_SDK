// Enum ModRT.EModStatus
enum class EModStatus : uint8 {
	IOeHtJg = 0,
	PRRmOMe = 1,
	jkMIHlg = 2,
	QHspNef = 3,
	kSlnSlg = 4,
	nRRMehe = 5,
	UWqojng = 6,
	jlsoOmf = 7,
	stkMLTh = 8,
	VVQUgfh = 9,
	IVSUnNf = 10,
	EModStatus_MAX = 11
};

// ScriptStruct ModRT.seLeUVh
// Size: 0x58 (Inherited: 0x00)
struct FseLeUVh {
	uint32_t riIQNTf; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	uint64_t oLOthmf; // 0x08(0x08)
	int32_t rSiUikg; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FDateTime enhPgjg; // 0x18(0x08)
	struct FDateTime kLWMgoh; // 0x20(0x08)
	struct FString siqQVWf; // 0x28(0x10)
	struct FString tjUPkff; // 0x38(0x10)
	struct FString ReSSpPh; // 0x48(0x10)
};

