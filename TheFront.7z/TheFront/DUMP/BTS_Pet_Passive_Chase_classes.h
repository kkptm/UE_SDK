// BlueprintGeneratedClass BTS_Pet_Passive_Chase.BTS_Pet_Passive_Chase_C
// Size: 0x120 (Inherited: 0x98)
struct UBTS_Pet_Passive_Chase_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct AqjpNNMe* SelfActor; // 0xa0(0x08)
	struct FBlackboardKeySelector MasterActor; // 0xa8(0x28)
	struct FBlackboardKeySelector ChaseRange; // 0xd0(0x28)
	struct FBlackboardKeySelector Target Actor; // 0xf8(0x28)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_Pet_Passive_Chase.BTS_Pet_Passive_Chase_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTS_Pet_Passive_Chase(int32_t EntryPoint); // Function BTS_Pet_Passive_Chase.BTS_Pet_Passive_Chase_C.ExecuteUbergraph_BTS_Pet_Passive_Chase // (Final|UbergraphFunction) // @ game+0x24b46a0
};

