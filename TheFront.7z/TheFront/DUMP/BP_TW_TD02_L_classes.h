// BlueprintGeneratedClass BP_TW_TD02_L.BP_TW_TD02_L_C
// Size: 0x228 (Inherited: 0x228)
struct UBP_TW_TD02_L_C : UJRTThTh {
};

