// BlueprintGeneratedClass BP_human_Gun03.BP_human_Gun03_C
// Size: 0x1548 (Inherited: 0x1500)
struct ABP_human_Gun03_C : ABP_human_common_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1500(0x08)
	struct UWidgetComponent* WidgetNameTag; // 0x1508(0x08)
	struct UStaticMeshComponent* SM_MG-01_BulletClamp_d3; // 0x1510(0x08)
	struct UStaticMeshComponent* SM_MG-01_BulletClamp_d2; // 0x1518(0x08)
	struct UStaticMeshComponent* SM_MG-01_BulletClamp_d1; // 0x1520(0x08)
	struct UStaticMeshComponent* SM_MG-01_BulletClamp_d; // 0x1528(0x08)
	struct UStaticMeshComponent* SM_MG-01_Stock_d; // 0x1530(0x08)
	struct UStaticMeshComponent* SM_MG-01_Mags_d; // 0x1538(0x08)
	struct USkeletalMeshComponent* SK_MG-01; // 0x1540(0x08)

	void PlayAttackStartSound(struct UtriMsng* Sound); // Function BP_human_Gun03.BP_human_Gun03_C.PlayAttackStartSound // (BlueprintEvent) // @ game+0x24b46a0
	void PlayAttackEndSound(struct UtriMsng* Sound); // Function BP_human_Gun03.BP_human_Gun03_C.PlayAttackEndSound // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_human_Gun03(int32_t EntryPoint); // Function BP_human_Gun03.BP_human_Gun03_C.ExecuteUbergraph_BP_human_Gun03 // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

