// BlueprintGeneratedClass Weather_Mask_Brush.Weather_Mask_Brush_C
// Size: 0x2c0 (Inherited: 0x240)
struct AWeather_Mask_Brush_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct UBoxComponent* Box; // 0x248(0x08)
	struct UBillboardComponent* Billboard; // 0x250(0x08)
	enum class UDS_Weather_Mask_Brush Brush; // 0x258(0x01)
	char pad_259[0x3]; // 0x259(0x03)
	float Mask Wetness; // 0x25c(0x04)
	float Mask Snow; // 0x260(0x04)
	char pad_264[0x4]; // 0x264(0x04)
	struct AUltra_Dynamic_Weather_C* UDW; // 0x268(0x08)
	struct TArray<struct FVector2D> Corners; // 0x270(0x10)
	float Yaw; // 0x280(0x04)
	struct FVector2D Brush Scale; // 0x284(0x08)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct UTexture2D* Brush Texture; // 0x290(0x08)
	struct FLinearColor Brush Color; // 0x298(0x10)
	struct FVector2D Brush Location; // 0x2a8(0x08)
	bool Cancel Masks Above; // 0x2b0(0x01)
	char pad_2B1[0x3]; // 0x2b1(0x03)
	struct FVector2D Center Location; // 0x2b4(0x08)
	float Max Distance; // 0x2bc(0x04)

	void UserConstructionScript(); // Function Weather_Mask_Brush.Weather_Mask_Brush_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveBeginPlay(); // Function Weather_Mask_Brush.Weather_Mask_Brush_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Weather_Mask_Brush.Weather_Mask_Brush_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_Weather_Mask_Brush(int32_t EntryPoint); // Function Weather_Mask_Brush.Weather_Mask_Brush_C.ExecuteUbergraph_Weather_Mask_Brush // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

