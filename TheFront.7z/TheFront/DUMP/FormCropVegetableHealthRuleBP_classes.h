// WidgetBlueprintGeneratedClass FormCropVegetableHealthRuleBP.FormCropVegetableHealthRuleBP_C
// Size: 0x350 (Inherited: 0x348)
struct UFormCropVegetableHealthRuleBP_C : UWQLUJgg {
	struct UImage* ImageTriangle; // 0x348(0x08)
};

