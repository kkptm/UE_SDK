// BlueprintGeneratedClass Exe_HungerTransformTarm.Exe_HungerTransformTarm_C
// Size: 0x40 (Inherited: 0x40)
struct UExe_HungerTransformTarm_C : UsHqNsHe {
};

