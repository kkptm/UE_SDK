// BlueprintGeneratedClass BP_Player_Character_None.BP_Player_Character_None_C
// Size: 0x268 (Inherited: 0x240)
struct ABP_Player_Character_None_C : AActor {
	struct USkeletalMeshComponent* coat; // 0x240(0x08)
	struct USkeletalMeshComponent* pant; // 0x248(0x08)
	struct USkeletalMeshComponent* head; // 0x250(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x258(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x260(0x08)

	void UserConstructionScript(); // Function BP_Player_Character_None.BP_Player_Character_None_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

