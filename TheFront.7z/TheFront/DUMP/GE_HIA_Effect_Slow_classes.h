// BlueprintGeneratedClass GE_HIA_Effect_Slow.GE_HIA_Effect_Slow_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_HIA_Effect_Slow_C : UGameplayEffect {
};

