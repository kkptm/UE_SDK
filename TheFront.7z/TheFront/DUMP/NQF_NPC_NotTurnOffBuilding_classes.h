// BlueprintGeneratedClass NQF_NPC_NotTurnOffBuilding.NQF_NPC_NotTurnOffBuilding_C
// Size: 0x58 (Inherited: 0x58)
struct UNQF_NPC_NotTurnOffBuilding_C : UrhoRmKg {
};

