// WidgetBlueprintGeneratedClass WBP_ItemDragButton.WBP_ItemDragButton_C
// Size: 0x26a (Inherited: 0x260)
struct UWBP_ItemDragButton_C : UUserWidget {
	struct UImage* Image_Item; // 0x260(0x08)
	enum class EItemDragMode DragMode; // 0x268(0x01)
	bool ItemDrog; // 0x269(0x01)
};

