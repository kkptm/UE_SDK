// BlueprintGeneratedClass GE_AntiRadiationOintment.GE_AntiRadiationOintment_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AntiRadiationOintment_C : UGameplayEffect {
};

