// BlueprintGeneratedClass BP_SovietUnion_4.BP_SovietUnion_3_C
// Size: 0x1518 (Inherited: 0x1518)
struct ABP_SovietUnion_3_C : ABP_Rebels_Common_C {
};

