// BlueprintGeneratedClass BTT_GunAttack_over_1_8.BTT_GunAttack_over_1_7_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_GunAttack_over_1_7_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector charger; // 0xb8(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_GunAttack_over_1_8.BTT_GunAttack_over_1_7_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_GunAttack_over_1_8(int32_t EntryPoint); // Function BTT_GunAttack_over_1_8.BTT_GunAttack_over_1_7_C.ExecuteUbergraph_BTT_GunAttack_over_1_8 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

