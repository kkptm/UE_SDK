// BlueprintGeneratedClass BP_human_Unarmed_Civilians_10.BP_human_Unarmed_Civilians_9_C
// Size: 0x1510 (Inherited: 0x1510)
struct ABP_human_Unarmed_Civilians_9_C : ABP_human_C {
};

