// WidgetBlueprintGeneratedClass FormNumberKeyboardBP.FormNumberKeyboardBP_C
// Size: 0x2e8 (Inherited: 0x2d0)
struct UFormNumberKeyboardBP_C : UPestege {
	struct UImage* Image; // 0x2d0(0x08)
	struct UImage* Image_69; // 0x2d8(0x08)
	struct UImage* ImageBackground; // 0x2e0(0x08)
};

