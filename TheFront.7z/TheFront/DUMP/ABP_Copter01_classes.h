// AnimBlueprintGeneratedClass ABP_Copter01.ABP_Copter01_C
// Size: 0xd9c (Inherited: 0x2d0)
struct UABP_Copter01_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10; // 0x2d8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9; // 0x3e0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8; // 0x4e8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7; // 0x5f0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6; // 0x6f8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5; // 0x800(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4; // 0x908(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0xa10(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0xb18(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0xc20(0x108)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose; // 0xd28(0x10)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0xd38(0x20)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xd58(0x30)
	float Rotor Mast Value; // 0xd88(0x04)
	float Rotor Back Value; // 0xd8c(0x04)
	float RotorPitch; // 0xd90(0x04)
	float Gun_Pitch; // 0xd94(0x04)
	float Gun_Yaw; // 0xd98(0x04)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Copter01.ABP_Copter01_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_4AACAAEB4C741EBE3CB6A18A2C2A8A0F(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_4AACAAEB4C741EBE3CB6A18A2C2A8A0F // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_0AF4454D4C14A32ABDF1E88AEC57B2D4(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_0AF4454D4C14A32ABDF1E88AEC57B2D4 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_7F0AA6FD4E9212B7AD47A390D86E3AB3(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_7F0AA6FD4E9212B7AD47A390D86E3AB3 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_8267F5EF4F4EE529FAF8AAA0AFCE7463(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_8267F5EF4F4EE529FAF8AAA0AFCE7463 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_9BD1231F4DF5A1F04A3656A392D33C5F(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_9BD1231F4DF5A1F04A3656A392D33C5F // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_E95EBFD8471DD90772DC9F82F73CC149(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_E95EBFD8471DD90772DC9F82F73CC149 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_F5F7EBD048205C456237F3AF4C77E379(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_F5F7EBD048205C456237F3AF4C77E379 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_214745D447A2DAEE90564A8ACD591330(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_214745D447A2DAEE90564A8ACD591330 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_489A52E04B071434FB292384AD2E05F6(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_489A52E04B071434FB292384AD2E05F6 // (BlueprintEvent) // @ game+0x24b46a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_A2048C604F4D2D2DAC19F6998B85BDA9(); // Function ABP_Copter01.ABP_Copter01_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Copter01_AnimGraphNode_ModifyBone_A2048C604F4D2D2DAC19F6998B85BDA9 // (BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Copter01.ABP_Copter01_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Copter01(int32_t EntryPoint); // Function ABP_Copter01.ABP_Copter01_C.ExecuteUbergraph_ABP_Copter01 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

