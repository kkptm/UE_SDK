// WidgetBlueprintGeneratedClass WBP_PersonPropertySlot.WBP_PersonPropertySlot_C
// Size: 0x278 (Inherited: 0x278)
struct UWBP_PersonPropertySlot_C : USHWTeWf {
};

