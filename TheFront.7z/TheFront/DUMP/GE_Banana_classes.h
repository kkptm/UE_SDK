// BlueprintGeneratedClass GE_Banana.GE_Banana_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Banana_C : UGameplayEffect {
};

