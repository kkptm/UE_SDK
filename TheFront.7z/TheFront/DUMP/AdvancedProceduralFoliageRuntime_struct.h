// Enum AdvancedProceduralFoliageRuntime.EAdvancedSimulationOverlap
enum class EAdvancedSimulationOverlap : uint8 {
	RMqqjOh = 0,
	kOSIUih = 1,
	pKKKQmh = 2,
	HNRtlKf = 3,
	EAdvancedSimulationOverlap_MAX = 4
};

// ScriptStruct AdvancedProceduralFoliageRuntime.nHoSJgg
// Size: 0x10 (Inherited: 0x00)
struct FnHoSJgg {
	struct UFoliageType* HrmRMSf; // 0x00(0x08)
	float MQnRsih; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

