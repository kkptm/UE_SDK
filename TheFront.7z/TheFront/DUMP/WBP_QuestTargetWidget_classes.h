// WidgetBlueprintGeneratedClass WBP_QuestTargetWidget.WBP_QuestTargetWidget_C
// Size: 0x280 (Inherited: 0x278)
struct UWBP_QuestTargetWidget_C : UfJJQVpg {
	struct UImage* Image_52; // 0x278(0x08)
};

