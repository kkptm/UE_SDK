// BlueprintGeneratedClass BP_human_BOSS.BP_human_BOSS_C
// Size: 0x1518 (Inherited: 0x1500)
struct ABP_human_BOSS_C : ABP_human_common_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1500(0x08)
	struct USkeletalMeshComponent* SK_Weapon_MonsterMutantHeavy; // 0x1508(0x08)
	struct USceneComponent* Scene; // 0x1510(0x08)

	void PlayAttackStartSound(struct UtriMsng* Sound); // Function BP_human_BOSS.BP_human_BOSS_C.PlayAttackStartSound // (BlueprintEvent) // @ game+0x24b46a0
	void PlayAttackEndSound(struct UtriMsng* Sound); // Function BP_human_BOSS.BP_human_BOSS_C.PlayAttackEndSound // (BlueprintEvent) // @ game+0x24b46a0
	void BP_OnDead(); // Function BP_human_BOSS.BP_human_BOSS_C.BP_OnDead // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_human_BOSS(int32_t EntryPoint); // Function BP_human_BOSS.BP_human_BOSS_C.ExecuteUbergraph_BP_human_BOSS // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

