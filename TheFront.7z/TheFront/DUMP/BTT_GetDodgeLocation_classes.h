// BlueprintGeneratedClass BTT_GetDodgeLocation.BTT_GetDodgeLocation_C
// Size: 0x124 (Inherited: 0xa8)
struct UBTT_GetDodgeLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector KeyTargetActor; // 0xb8(0x28)
	struct AActor* TargetActor; // 0xe0(0x08)
	float Distance; // 0xe8(0x04)
	float Radius; // 0xec(0x04)
	struct FBlackboardKeySelector KeyTargetLocation; // 0xf0(0x28)
	struct FVector Origin; // 0x118(0x0c)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_GetDodgeLocation.BTT_GetDodgeLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_GetDodgeLocation(int32_t EntryPoint); // Function BTT_GetDodgeLocation.BTT_GetDodgeLocation_C.ExecuteUbergraph_BTT_GetDodgeLocation // (Final|UbergraphFunction) // @ game+0x24b46a0
};

