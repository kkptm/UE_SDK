// WidgetBlueprintGeneratedClass WBP_QuestInfoEntryWidget.WBP_QuestInfoEntryWidget_C
// Size: 0x2a0 (Inherited: 0x288)
struct UWBP_QuestInfoEntryWidget_C : URIQssoe {
	struct UImage* Image; // 0x288(0x08)
	struct UImage* Image_2; // 0x290(0x08)
	struct UImage* Image_3; // 0x298(0x08)
};

