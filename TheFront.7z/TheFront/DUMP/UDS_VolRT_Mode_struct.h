// UserDefinedEnum UDS_VolRT_Mode.UDS_VolRT_Mode
enum class UDS_VolRT_Mode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	UDS_VolRT_MAX = 4
};

