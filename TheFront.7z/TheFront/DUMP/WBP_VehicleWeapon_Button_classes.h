// WidgetBlueprintGeneratedClass WBP_VehicleWeapon_Button.WBP_VehicleWeapon_Button_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UWBP_VehicleWeapon_Button_C : UkOWooTf {
};

