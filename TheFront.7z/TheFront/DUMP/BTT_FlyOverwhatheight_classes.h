// BlueprintGeneratedClass BTT_FlyOverwhatheight.BTT_FlyOverwhatheight_C
// Size: 0xc4 (Inherited: 0xa8)
struct UBTT_FlyOverwhatheight_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FVector NewVar_1; // 0xb8(0x0c)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FlyOverwhatheight.BTT_FlyOverwhatheight_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FlyOverwhatheight(int32_t EntryPoint); // Function BTT_FlyOverwhatheight.BTT_FlyOverwhatheight_C.ExecuteUbergraph_BTT_FlyOverwhatheight // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

