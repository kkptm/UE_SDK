// WidgetBlueprintGeneratedClass FormHouseFlagAutoRepairConsumePanelBP.FormHouseFlagAutoRepairConsumePanelBP_C
// Size: 0x308 (Inherited: 0x2d8)
struct UFormHouseFlagAutoRepairConsumePanelBP_C : UnmffNMg {
	struct UImage* Image_68; // 0x2d8(0x08)
	struct UFormHouseFlagAutoRepairConsumeItemBP_C* WBP_HouseFlagAutoRepairConsumeItem; // 0x2e0(0x08)
	struct UFormHouseFlagAutoRepairConsumeItemBP_C* WBP_HouseFlagAutoRepairConsumeItem_2; // 0x2e8(0x08)
	struct UFormHouseFlagAutoRepairConsumeItemBP_C* WBP_HouseFlagAutoRepairConsumeItem_3; // 0x2f0(0x08)
	struct UFormHouseFlagAutoRepairConsumeItemBP_C* WBP_HouseFlagAutoRepairConsumeItem_4; // 0x2f8(0x08)
	struct UFormHouseFlagAutoRepairConsumeItemBP_C* WBP_HouseFlagAutoRepairConsumeItem_5; // 0x300(0x08)
};

