// BlueprintGeneratedClass BTT_FlyChaseLocation.BTT_FlyChaseLocation_C
// Size: 0x13c (Inherited: 0xa8)
struct UBTT_FlyChaseLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector KeyTargetActor; // 0xb8(0x28)
	struct AActor* TargetActor; // 0xe0(0x08)
	float Distance; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FBlackboardKeySelector KeyTargetLocation; // 0xf0(0x28)
	float Yaw; // 0x118(0x04)
	float flight altitude Min; // 0x11c(0x04)
	float flight altitude Max; // 0x120(0x04)
	struct FVector TargetRLocation; // 0x124(0x0c)
	struct FVector TargetLLocation; // 0x130(0x0c)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FlyChaseLocation.BTT_FlyChaseLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FlyChaseLocation(int32_t EntryPoint); // Function BTT_FlyChaseLocation.BTT_FlyChaseLocation_C.ExecuteUbergraph_BTT_FlyChaseLocation // (Final|UbergraphFunction) // @ game+0x24b46a0
};

