// WidgetBlueprintGeneratedClass WBP_BaseGroup.WBP_BaseGroup_C
// Size: 0x281 (Inherited: 0x260)
struct UWBP_BaseGroup_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	bool Modified; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct TArray<struct FQomgOtf> ItemConfigList; // 0x270(0x10)
	bool bIsModified; // 0x280(0x01)

	void UpdateIntValue(struct FgtNPOSg Param, float Value, struct FString ParamName); // Function WBP_BaseGroup.WBP_BaseGroup_C.UpdateIntValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitItemList(struct TArray<struct FQomgOtf>& ItemConfigList, struct UUniformGridPanel* ItemCon); // Function WBP_BaseGroup.WBP_BaseGroup_C.InitItemList // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateStringValue(struct FNqVqkoe Param, struct FString Value, struct FString ParamName); // Function WBP_BaseGroup.WBP_BaseGroup_C.UpdateStringValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateValue(struct FgtNPOSg Param, float Value, struct FString ParamName); // Function WBP_BaseGroup.WBP_BaseGroup_C.UpdateValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void FillDatas(); // Function WBP_BaseGroup.WBP_BaseGroup_C.FillDatas // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_BaseGroup(int32_t EntryPoint); // Function WBP_BaseGroup.WBP_BaseGroup_C.ExecuteUbergraph_WBP_BaseGroup // (Final|UbergraphFunction) // @ game+0x24b46a0
};

