// WidgetBlueprintGeneratedClass GM_AttributeOtherInfoSlot.GM_AttributeOtherInfoSlot_C
// Size: 0x288 (Inherited: 0x280)
struct UGM_AttributeOtherInfoSlot_C : UkmhKogf {
	struct UImage* Image_40; // 0x280(0x08)

	void Update Value Text(struct FString InStr); // Function GM_AttributeOtherInfoSlot.GM_AttributeOtherInfoSlot_C.Update Value Text // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

