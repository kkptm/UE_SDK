// WidgetBlueprintGeneratedClass WBP_QuestTrackWidget.WBP_QuestTrackWidget_C
// Size: 0x2a0 (Inherited: 0x298)
struct UWBP_QuestTrackWidget_C : UWOthsfe {
	struct UImage* Image_131; // 0x298(0x08)
};

