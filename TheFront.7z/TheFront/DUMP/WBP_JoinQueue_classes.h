// WidgetBlueprintGeneratedClass WBP_JoinQueue.WBP_JoinQueue_C
// Size: 0x288 (Inherited: 0x260)
struct UWBP_JoinQueue_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct USrQNosh* Btn; // 0x268(0x08)
	struct UImage* Image_97; // 0x270(0x08)
	struct UTextBlock* TxtQueuePosition; // 0x278(0x08)
	struct UUserWidget* ParentWidget; // 0x280(0x08)

	void SetQueuePosition(int32_t InPosition); // Function WBP_JoinQueue.WBP_JoinQueue_C.SetQueuePosition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_JoinQueue_Btn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_JoinQueue.WBP_JoinQueue_C.BndEvt__WBP_JoinQueue_Btn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_JoinQueue(int32_t EntryPoint); // Function WBP_JoinQueue.WBP_JoinQueue_C.ExecuteUbergraph_WBP_JoinQueue // (Final|UbergraphFunction) // @ game+0x24b46a0
};

