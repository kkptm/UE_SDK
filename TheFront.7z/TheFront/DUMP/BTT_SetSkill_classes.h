// BlueprintGeneratedClass BTT_SetSkill.BTT_SetSkill_C
// Size: 0xb1 (Inherited: 0xa8)
struct UBTT_SetSkill_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	enum class EAISkill Skill; // 0xb0(0x01)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetSkill.BTT_SetSkill_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_SetSkill(int32_t EntryPoint); // Function BTT_SetSkill.BTT_SetSkill_C.ExecuteUbergraph_BTT_SetSkill // (Final|UbergraphFunction) // @ game+0x24b46a0
};

