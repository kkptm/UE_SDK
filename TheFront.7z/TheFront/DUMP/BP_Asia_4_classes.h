// BlueprintGeneratedClass BP_Asia_4.BP_Asia_3_C
// Size: 0x1518 (Inherited: 0x1518)
struct ABP_Asia_3_C : ABP_Rebels_Common_C {
};

