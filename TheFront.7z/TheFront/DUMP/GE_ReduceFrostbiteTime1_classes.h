// BlueprintGeneratedClass GE_ReduceFrostbiteTime1.GE_ReduceFrostbiteTime1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_ReduceFrostbiteTime1_C : UGameplayEffect {
};

