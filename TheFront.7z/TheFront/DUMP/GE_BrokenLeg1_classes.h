// BlueprintGeneratedClass GE_BrokenLeg1.GE_BrokenLeg1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_BrokenLeg1_C : UGameplayEffect {
};

