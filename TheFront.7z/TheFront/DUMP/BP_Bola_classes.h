// BlueprintGeneratedClass BP_Bola.BP_Bola_C
// Size: 0xa08 (Inherited: 0xa00)
struct ABP_Bola_C : AOsjmeUf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa00(0x08)

	void BPCall_TF1(enum class EThrowerStageEnum P1); // Function BP_Bola.BP_Bola_C.BPCall_TF1 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Bola(int32_t EntryPoint); // Function BP_Bola.BP_Bola_C.ExecuteUbergraph_BP_Bola // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

