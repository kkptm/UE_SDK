// WidgetBlueprintGeneratedClass WBP_UserSettingMain.WBP_UserSettingMain_C
// Size: 0x368 (Inherited: 0x300)
struct UWBP_UserSettingMain_C : UmhVVOrf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct UImage* BG; // 0x308(0x08)
	struct UImage* Image_64; // 0x310(0x08)
	struct UWBP_ControlSettingMenu_C* WBP_ControlSettingMenu; // 0x318(0x08)
	struct UWBP_GraphicsSettingMenu_C* WBP_GraphicsSettingMenu; // 0x320(0x08)
	struct UWBP_LanguageSettingMenu_C* WBP_LanguageSettingMenu; // 0x328(0x08)
	struct UWBP_ScaleItemTemp_C* WBP_Scale_Control; // 0x330(0x08)
	struct UWBP_ScaleItemTemp_C* WBP_Scale_Graphics; // 0x338(0x08)
	struct UWBP_ScaleItemTemp_C* WBP_Scale_Language; // 0x340(0x08)
	struct UWBP_ScaleItemTemp_C* WBP_Scale_Sound; // 0x348(0x08)
	struct UWBP_ScaleItemTemp_C* WBP_Scale_Streamer; // 0x350(0x08)
	struct UWBP_SoundSettingMenu_C* WBP_SoundSettingMenu; // 0x358(0x08)
	struct UWBP_StreamerSettingMenu_C* WBP_StreamerSettingMenu; // 0x360(0x08)

	bool BPCall_Native_GW_Func1(struct FKey& Key, struct FName& ActionName, bool Pressed); // Function WBP_UserSettingMain.WBP_UserSettingMain_C.BPCall_Native_GW_Func1 // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_UserSettingMain.WBP_UserSettingMain_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_UserSettingMain(int32_t EntryPoint); // Function WBP_UserSettingMain.WBP_UserSettingMain_C.ExecuteUbergraph_WBP_UserSettingMain // (Final|UbergraphFunction) // @ game+0x24b46a0
};

