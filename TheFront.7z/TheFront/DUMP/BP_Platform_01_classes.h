// BlueprintGeneratedClass BP_Platform_01.BP_Platform_01_C
// Size: 0xfc8 (Inherited: 0xfc8)
struct ABP_Platform_01_C : ABP_TrackPawn_C {

	void UserConstructionScript(); // Function BP_Platform_01.BP_Platform_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

