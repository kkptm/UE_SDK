// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x8d0 (Inherited: 0x890)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_890[0x8]; // 0x890(0x08)
	struct FName CurveSourceBindingName; // 0x898(0x08)
	float CurveSyncOffset; // 0x8a0(0x04)
	char pad_8A4[0x2c]; // 0x8a4(0x2c)
};

