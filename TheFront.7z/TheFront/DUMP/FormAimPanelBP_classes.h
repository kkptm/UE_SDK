// WidgetBlueprintGeneratedClass FormAimPanelBP.FormAimPanelBP_C
// Size: 0x2b8 (Inherited: 0x2b0)
struct UFormAimPanelBP_C : UlVehRTe {
	struct UImage* ImageBackground; // 0x2b0(0x08)
};

