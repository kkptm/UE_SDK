// BlueprintGeneratedClass GE_GypsumPlywood.GE_GypsumPlywood_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_GypsumPlywood_C : UGameplayEffect {
};

