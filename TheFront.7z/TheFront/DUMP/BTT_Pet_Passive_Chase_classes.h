// BlueprintGeneratedClass BTT_Pet_Passive_Chase.BTT_Pet_Passive_Chase_C
// Size: 0x130 (Inherited: 0xa8)
struct UBTT_Pet_Passive_Chase_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector MasterActor; // 0xb8(0x28)
	struct FBlackboardKeySelector ChaseRange; // 0xe0(0x28)
	struct FBlackboardKeySelector Target Actor; // 0x108(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_Pet_Passive_Chase.BTT_Pet_Passive_Chase_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_Pet_Passive_Chase(int32_t EntryPoint); // Function BTT_Pet_Passive_Chase.BTT_Pet_Passive_Chase_C.ExecuteUbergraph_BTT_Pet_Passive_Chase // (Final|UbergraphFunction) // @ game+0x24b46a0
};

