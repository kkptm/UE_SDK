// WidgetBlueprintGeneratedClass FormTubeJointPanelBP.FormTubeJointPanelBP_C
// Size: 0x2c8 (Inherited: 0x2b8)
struct UFormTubeJointPanelBP_C : UmLptSfg {
	struct UImage* Image_73; // 0x2b8(0x08)
	struct UImage* ImageBackground; // 0x2c0(0x08)
};

