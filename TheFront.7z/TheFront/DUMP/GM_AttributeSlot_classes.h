// WidgetBlueprintGeneratedClass GM_AttributeSlot.GM_AttributeSlot_C
// Size: 0x2c8 (Inherited: 0x2b8)
struct UGM_AttributeSlot_C : UmOeKteh {
	struct UImage* Image_40; // 0x2b8(0x08)
	int32_t EnumIndex; // 0x2c0(0x04)
	enum class EPlayerPart EPlayerPart; // 0x2c4(0x01)
	enum class EArmorType EArmorType; // 0x2c5(0x01)
	enum class ETemperatureState ETemperatureEnum; // 0x2c6(0x01)
	enum class EGMAttributeSlotType SlotType; // 0x2c7(0x01)

	void Update Value Text(struct FString InStr); // Function GM_AttributeSlot.GM_AttributeSlot_C.Update Value Text // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitTemperatureData(struct FString TemperatureName, enum class ETemperatureState TemperatureEnum, enum class EGMAttributeSlotType InSlotType); // Function GM_AttributeSlot.GM_AttributeSlot_C.InitTemperatureData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitDataByPlayerPartAndArmorType(enum class EPlayerPart InPlayerPart, enum class EArmorType iNArmorType, struct FString ShowName, enum class EGMAttributeSlotType InSlotType); // Function GM_AttributeSlot.GM_AttributeSlot_C.InitDataByPlayerPartAndArmorType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void GetEnumIndex(int32_t& Index); // Function GM_AttributeSlot.GM_AttributeSlot_C.GetEnumIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateValue(float InValue); // Function GM_AttributeSlot.GM_AttributeSlot_C.UpdateValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitData(struct FText InName, int32_t InIndex, enum class EGMAttributeSlotType InSlotType); // Function GM_AttributeSlot.GM_AttributeSlot_C.InitData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

