// BlueprintGeneratedClass GE_SettleDownCD.GE_SettleDownCD_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_SettleDownCD_C : UGameplayEffect {
};

