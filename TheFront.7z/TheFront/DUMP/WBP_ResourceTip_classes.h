// WidgetBlueprintGeneratedClass WBP_ResourceTip.WBP_ResourceTip_C
// Size: 0x278 (Inherited: 0x260)
struct UWBP_ResourceTip_C : UUserWidget {
	struct UButton* Button_198; // 0x260(0x08)
	struct UTextBlock* Text_DefaultActionDesc_2; // 0x268(0x08)
	struct UTextBlock* TipContent; // 0x270(0x08)

	void SetTips(struct FText InName); // Function WBP_ResourceTip.WBP_ResourceTip_C.SetTips // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

