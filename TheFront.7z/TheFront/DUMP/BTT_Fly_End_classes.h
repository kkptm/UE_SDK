// BlueprintGeneratedClass BTT_Fly_End.BTT_Fly_End_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_Fly_End_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_Fly_End.BTT_Fly_End_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_Fly_End(int32_t EntryPoint); // Function BTT_Fly_End.BTT_Fly_End_C.ExecuteUbergraph_BTT_Fly_End // (Final|UbergraphFunction) // @ game+0x24b46a0
};

