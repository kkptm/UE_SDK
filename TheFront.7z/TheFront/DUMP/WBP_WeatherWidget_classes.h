// WidgetBlueprintGeneratedClass WBP_WeatherWidget.WBP_WeatherWidget_C
// Size: 0x301 (Inherited: 0x260)
struct UWBP_WeatherWidget_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* HumidityIamge; // 0x268(0x08)
	struct UTextBlock* HumidityText; // 0x270(0x08)
	struct UImage* IlluminationIntensityImage; // 0x278(0x08)
	struct UTextBlock* IlluminationIntensityText; // 0x280(0x08)
	struct UImage* Img_Weather; // 0x288(0x08)
	struct UImage* PrecipitationImage; // 0x290(0x08)
	struct UTextBlock* PrecipitationText; // 0x298(0x08)
	struct UImage* TemperatureImage; // 0x2a0(0x08)
	struct UTextBlock* TemperatureText; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_57; // 0x2b0(0x08)
	struct UImage* WindPowerImage; // 0x2b8(0x08)
	struct UTextBlock* WindPowerText; // 0x2c0(0x08)
	float Temperature; // 0x2c8(0x04)
	float Humidity; // 0x2cc(0x04)
	float WindSpeed; // 0x2d0(0x04)
	float Sunlight; // 0x2d4(0x04)
	float Rainfall; // 0x2d8(0x04)
	char pad_2DC[0x4]; // 0x2dc(0x04)
	struct FText TimeString; // 0x2e0(0x18)
	struct ABP_WeatherManager_C* WeatherManager; // 0x2f8(0x08)
	bool bIsNight; // 0x300(0x01)

	void FindWeatherManager(); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.FindWeatherManager // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ToTwoDigitalDate(int32_t InNum, struct FString& OutStr); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.ToTwoDigitalDate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateTimeUsingCode(struct FTimecode NewTime); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.UpdateTimeUsingCode // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void SetWeatherUI(enum class EWeatherCate Weather); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.SetWeatherUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateTime(float SecondsOfDay); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.UpdateTime // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateEnvProp(struct FEnvProp NewProp); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.UpdateEnvProp // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_WeatherWidget(int32_t EntryPoint); // Function WBP_WeatherWidget.WBP_WeatherWidget_C.ExecuteUbergraph_WBP_WeatherWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

