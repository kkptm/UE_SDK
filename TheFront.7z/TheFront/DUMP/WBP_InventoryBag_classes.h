// WidgetBlueprintGeneratedClass WBP_InventoryBag.WBP_InventoryBag_C
// Size: 0xb40 (Inherited: 0x2e8)
struct UWBP_InventoryBag_C : UjULkOUf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)
	struct USrQNosh* Button_Drop; // 0x2f0(0x08)
	struct USrQNosh* Button_Move; // 0x2f8(0x08)
	struct USrQNosh* Button_Order; // 0x300(0x08)
	struct UCanvasPanel* CanvasPanel_Move; // 0x308(0x08)
	struct UImage* Image; // 0x310(0x08)
	struct UImage* Image_122; // 0x318(0x08)
	struct UImage* TitleBG; // 0x320(0x08)
	struct UWrapBox* WrapBox_Bag; // 0x328(0x08)
	int32_t SlotNumber; // 0x330(0x04)
	char pad_334[0x4]; // 0x334(0x04)
	struct FCheckBoxStyle BoxStyle; // 0x338(0x580)
	bool IsInited; // 0x8b8(0x01)
	char pad_8B9[0x7]; // 0x8b9(0x07)
	struct FButtonStyle ButtonStyle; // 0x8c0(0x278)
	struct UTexture2D* SelImage; // 0xb38(0x08)

	void WBP_InventoryBag_OrganizeCoolTime(bool InCoolTime); // Function WBP_InventoryBag.WBP_InventoryBag_C.WBP_InventoryBag_OrganizeCoolTime // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void WBP_InventoryBag_AutoGenFunc(struct UokpsjLh* ItemButton); // Function WBP_InventoryBag.WBP_InventoryBag_C.WBP_InventoryBag_AutoGenFunc // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Init(); // Function WBP_InventoryBag.WBP_InventoryBag_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_InventoryBag.WBP_InventoryBag_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_InventoryBag_Button_Order_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_InventoryBag.WBP_InventoryBag_C.BndEvt__WBP_InventoryBag_Button_Order_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpTB(bool bOth); // Function WBP_InventoryBag.WBP_InventoryBag_C.BPCall_UpTB // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_InventoryBag_Button_Move_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_InventoryBag.WBP_InventoryBag_C.BndEvt__WBP_InventoryBag_Button_Move_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_InventoryBag_Button_Drop_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_InventoryBag.WBP_InventoryBag_C.BndEvt__WBP_InventoryBag_Button_Drop_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_InventoryBag(int32_t EntryPoint); // Function WBP_InventoryBag.WBP_InventoryBag_C.ExecuteUbergraph_WBP_InventoryBag // (Final|UbergraphFunction) // @ game+0x24b46a0
};

