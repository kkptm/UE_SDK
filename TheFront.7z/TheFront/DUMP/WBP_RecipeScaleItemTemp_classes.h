// WidgetBlueprintGeneratedClass WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C
// Size: 0x2a0 (Inherited: 0x278)
struct UWBP_RecipeScaleItemTemp_C : UhKIVNTe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)
	struct UImage* IconNormal; // 0x280(0x08)
	struct UScaleBox* ScaleBox_214; // 0x288(0x08)
	struct UTexture2D* IconImage_Normal; // 0x290(0x08)
	struct UTexture2D* IconImage_Hover; // 0x298(0x08)

	void Setup(bool Focus); // Function WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void PreConstruct(bool IsDesignTime); // Function WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_SIT_Func3(bool Start); // Function WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C.BPCall_SIT_Func3 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_RecipeScaleItemTemp(int32_t EntryPoint); // Function WBP_RecipeScaleItemTemp.WBP_RecipeScaleItemTemp_C.ExecuteUbergraph_WBP_RecipeScaleItemTemp // (Final|UbergraphFunction) // @ game+0x24b46a0
};

