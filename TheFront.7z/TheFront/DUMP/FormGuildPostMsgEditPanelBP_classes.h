// WidgetBlueprintGeneratedClass FormGuildPostMsgEditPanelBP.FormGuildPostMsgEditPanelBP_C
// Size: 0x2a0 (Inherited: 0x290)
struct UFormGuildPostMsgEditPanelBP_C : UWiNKojh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UImage* Image_120; // 0x298(0x08)

	void BndEvt__FormGuildPostMsgEditPanelBP_TextContent_K2Node_ComponentBoundEvent_0_OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function FormGuildPostMsgEditPanelBP.FormGuildPostMsgEditPanelBP_C.BndEvt__FormGuildPostMsgEditPanelBP_TextContent_K2Node_ComponentBoundEvent_0_OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_FormGuildPostMsgEditPanelBP(int32_t EntryPoint); // Function FormGuildPostMsgEditPanelBP.FormGuildPostMsgEditPanelBP_C.ExecuteUbergraph_FormGuildPostMsgEditPanelBP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

