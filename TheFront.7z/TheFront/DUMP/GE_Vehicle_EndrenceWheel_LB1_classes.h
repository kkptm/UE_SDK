// BlueprintGeneratedClass GE_Vehicle_EndrenceWheel_LB1.GE_Vehicle_EndrenceWheel_LB1_C
// Size: 0x828 (Inherited: 0x828)
struct UGE_Vehicle_EndrenceWheel_LB1_C : UTNoSqeg {
};

