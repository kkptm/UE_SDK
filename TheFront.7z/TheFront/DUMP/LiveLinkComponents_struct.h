// ScriptStruct LiveLinkComponents.LiveLinkTransformControllerData
// Size: 0x06 (Inherited: 0x00)
struct FLiveLinkTransformControllerData {
	bool bWorldTransform; // 0x00(0x01)
	bool bUseLocation; // 0x01(0x01)
	bool bUseRotation; // 0x02(0x01)
	bool bUseScale; // 0x03(0x01)
	bool bSweep; // 0x04(0x01)
	bool bTeleport; // 0x05(0x01)
};

