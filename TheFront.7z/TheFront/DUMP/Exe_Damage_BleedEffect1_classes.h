// BlueprintGeneratedClass Exe_Damage_BleedEffect1.Exe_Damage_BleedEffect1_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_BleedEffect1_C : UreLVite {
};

