// BlueprintGeneratedClass Exe_Damage_GE_Cleavage.Exe_Damage_GE_Cleavage_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_GE_Cleavage_C : UreLVite {
};

