// BlueprintGeneratedClass GE_VegetablePasta2.GE_VegetablePasta2_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_VegetablePasta2_C : UGameplayEffect {
};

