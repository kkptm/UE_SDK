// WidgetBlueprintGeneratedClass WBP_QuestTreeWidget.WBP_QuestTreeWidget_C
// Size: 0x430 (Inherited: 0x310)
struct UWBP_QuestTreeWidget_C : UVqTqrgh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct UTextBlock* BranchQuest; // 0x318(0x08)
	struct UTextBlock* DailyQuest; // 0x320(0x08)
	struct UTextBlock* TrunckQuest; // 0x328(0x08)
	struct FSlateFontInfo HoverFont; // 0x330(0x58)
	struct FSlateColor HoverColor; // 0x388(0x28)
	struct FSlateFontInfo UnHoverFont; // 0x3b0(0x58)
	struct FSlateColor UnHoverColor; // 0x408(0x28)

	void Change Radio Show(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.Change Radio Show // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_BranchQuest_K2Node_ComponentBoundEvent_2_OnRadioButtonStateHover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_BranchQuest_K2Node_ComponentBoundEvent_2_OnRadioButtonStateHover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_BranchQuest_K2Node_ComponentBoundEvent_3_OnRadioButtonStateUnhover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_BranchQuest_K2Node_ComponentBoundEvent_3_OnRadioButtonStateUnhover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_DailyQuest_K2Node_ComponentBoundEvent_4_OnRadioButtonStateHover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_DailyQuest_K2Node_ComponentBoundEvent_4_OnRadioButtonStateHover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_DailyQuest_K2Node_ComponentBoundEvent_5_OnRadioButtonStateUnhover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_DailyQuest_K2Node_ComponentBoundEvent_5_OnRadioButtonStateUnhover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_TrunckQuest_K2Node_ComponentBoundEvent_1_OnRadioButtonStateUnhover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_TrunckQuest_K2Node_ComponentBoundEvent_1_OnRadioButtonStateUnhover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_QuestTreeWidget_RB_TrunckQuest_K2Node_ComponentBoundEvent_0_OnRadioButtonStateHover__DelegateSignature(struct UnlRqLnf* Button); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BndEvt__WBP_QuestTreeWidget_RB_TrunckQuest_K2Node_ComponentBoundEvent_0_OnRadioButtonStateHover__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BP_F1(struct UnlRqLnf* RB); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BP_F1 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BP_F2(struct UnlRqLnf* RB); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.BP_F2 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_QuestTreeWidget(int32_t EntryPoint); // Function WBP_QuestTreeWidget.WBP_QuestTreeWidget_C.ExecuteUbergraph_WBP_QuestTreeWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

