// WidgetBlueprintGeneratedClass WBP_NeedResourcePanel.WBP_NeedResourcePanel_C
// Size: 0x2e8 (Inherited: 0x2d8)
struct UWBP_NeedResourcePanel_C : UOjRLeRf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	struct UTextBlock* 1_2; // 0x2e0(0x08)

	void BP_OnEntryReleased(); // Function WBP_NeedResourcePanel.WBP_NeedResourcePanel_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function WBP_NeedResourcePanel.WBP_NeedResourcePanel_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function WBP_NeedResourcePanel.WBP_NeedResourcePanel_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_NeedResourcePanel(int32_t EntryPoint); // Function WBP_NeedResourcePanel.WBP_NeedResourcePanel_C.ExecuteUbergraph_WBP_NeedResourcePanel // (Final|UbergraphFunction) // @ game+0x24b46a0
};

