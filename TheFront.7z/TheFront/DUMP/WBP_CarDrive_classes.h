// WidgetBlueprintGeneratedClass WBP_CarDrive.WBP_CarDrive_C
// Size: 0x318 (Inherited: 0x300)
struct UWBP_CarDrive_C : UkJVhQMh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct UTextBlock* OilMaxValueText; // 0x308(0x08)
	struct UTextBlock* OilValueText; // 0x310(0x08)

	void BPCall_DriverUI_Func(bool IsDriver, bool OpenSight); // Function WBP_CarDrive.WBP_CarDrive_C.BPCall_DriverUI_Func // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_CarDrive(int32_t EntryPoint); // Function WBP_CarDrive.WBP_CarDrive_C.ExecuteUbergraph_WBP_CarDrive // (Final|UbergraphFunction) // @ game+0x24b46a0
};

