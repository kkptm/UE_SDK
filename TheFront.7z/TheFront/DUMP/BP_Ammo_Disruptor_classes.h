// BlueprintGeneratedClass BP_Ammo_Disruptor.BP_Ammo_Disruptor_C
// Size: 0x520 (Inherited: 0x4f8)
struct ABP_Ammo_Disruptor_C : ABP_Ammo_Sync_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f8(0x08)
	float Smoke_SpawnRate; // 0x500(0x04)
	float Smoke_LifeMin; // 0x504(0x04)
	float Smoke_LifeMax; // 0x508(0x04)
	float Smoke_SizeMin; // 0x50c(0x04)
	float Smoke_SizeMax; // 0x510(0x04)
	struct FVector Fire_MeshSize; // 0x514(0x0c)

	struct FVector BPCall_VAmmo_Func4(struct APawn* OwnerPawn, float InitSpeed); // Function BP_Ammo_Disruptor.BP_Ammo_Disruptor_C.BPCall_VAmmo_Func4 // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_OnSpawnTrail(struct UNiagaraComponent* Trail); // Function BP_Ammo_Disruptor.BP_Ammo_Disruptor_C.BPCall_OnSpawnTrail // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_OnSpawnSmoke(struct UNiagaraComponent* Smoke); // Function BP_Ammo_Disruptor.BP_Ammo_Disruptor_C.BPCall_OnSpawnSmoke // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Ammo_Disruptor(int32_t EntryPoint); // Function BP_Ammo_Disruptor.BP_Ammo_Disruptor_C.ExecuteUbergraph_BP_Ammo_Disruptor // (Final|UbergraphFunction) // @ game+0x24b46a0
};

