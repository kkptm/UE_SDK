// BlueprintGeneratedClass BP_AttackCity_human_Pickaxe.BP_AttackCity_human_Pickaxe_C
// Size: 0x1520 (Inherited: 0x1508)
struct ABP_AttackCity_human_Pickaxe_C : ABP_human_common_collar_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1508(0x08)
	struct USkeletalMeshComponent* SK_IronPickaxe; // 0x1510(0x08)
	struct USceneComponent* Pickaxe; // 0x1518(0x08)

	void PlayAttackStartSound(struct UtriMsng* Sound); // Function BP_AttackCity_human_Pickaxe.BP_AttackCity_human_Pickaxe_C.PlayAttackStartSound // (BlueprintEvent) // @ game+0x24b46a0
	void PlayAttackEndSound(struct UtriMsng* Sound); // Function BP_AttackCity_human_Pickaxe.BP_AttackCity_human_Pickaxe_C.PlayAttackEndSound // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_AttackCity_human_Pickaxe(int32_t EntryPoint); // Function BP_AttackCity_human_Pickaxe.BP_AttackCity_human_Pickaxe_C.ExecuteUbergraph_BP_AttackCity_human_Pickaxe // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

