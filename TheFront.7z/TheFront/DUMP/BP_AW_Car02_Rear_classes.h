// BlueprintGeneratedClass BP_AW_Car02_Rear.BP_AW_Car02_Rear_C
// Size: 0x220 (Inherited: 0x220)
struct UBP_AW_Car02_Rear_C : UChaosVehicleWheel {
};

