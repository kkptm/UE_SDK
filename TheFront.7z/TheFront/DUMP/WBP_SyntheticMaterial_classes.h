// WidgetBlueprintGeneratedClass WBP_SyntheticMaterial.WBP_SyntheticMaterial_C
// Size: 0x280 (Inherited: 0x278)
struct UWBP_SyntheticMaterial_C : UTmneHie {
	struct UImage* Image_75; // 0x278(0x08)
};

