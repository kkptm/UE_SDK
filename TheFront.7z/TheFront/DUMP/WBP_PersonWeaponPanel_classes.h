// WidgetBlueprintGeneratedClass WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C
// Size: 0x318 (Inherited: 0x2b0)
struct UWBP_PersonWeaponPanel_C : UWsUUjrg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2b0(0x08)
	struct UWidgetAnimation* AmmoListOpenAnim; // 0x2b8(0x08)
	struct UWidgetAnimation* ReloadEndAnim; // 0x2c0(0x08)
	struct UWBP_BombRemoteControllerPanel_C* BombRemoteControllerPanel; // 0x2c8(0x08)
	struct UImage* BulletValueBG; // 0x2d0(0x08)
	struct UCanvasPanel* ChangeFireMode; // 0x2d8(0x08)
	struct UDynamicEntryBox* DynamicEntryBox_SwitchAmmo; // 0x2e0(0x08)
	struct UImage* Image; // 0x2e8(0x08)
	struct UImage* Image_2; // 0x2f0(0x08)
	struct UImage* Image_63; // 0x2f8(0x08)
	struct UImage* Image_WeaponBg; // 0x300(0x08)
	struct UTextBlock* Text1; // 0x308(0x08)
	float RefreshInterval; // 0x310(0x04)
	float RefreshRemain; // 0x314(0x04)

	enum class ESlateVisibility Get_ChangeFireMode_Visibility_1(); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.Get_ChangeFireMode_Visibility_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	void BPCall_F3(bool bP1); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.BPCall_F3 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_F1(); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.BPCall_F1 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_F2(); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.BPCall_F2 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_F5(struct AWeHQeeg* P1); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.BPCall_F5 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_F4(); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.BPCall_F4 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PersonWeaponPanel(int32_t EntryPoint); // Function WBP_PersonWeaponPanel.WBP_PersonWeaponPanel_C.ExecuteUbergraph_WBP_PersonWeaponPanel // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

