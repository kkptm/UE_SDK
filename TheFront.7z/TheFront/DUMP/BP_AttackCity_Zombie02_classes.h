// BlueprintGeneratedClass BP_AttackCity_Zombie02.BP_AttackCity_Zombie02_C
// Size: 0x1510 (Inherited: 0x1508)
struct ABP_AttackCity_Zombie02_C : ABP_human_common_collar_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1508(0x08)

	void PlayAttackStartSound(struct UtriMsng* Sound); // Function BP_AttackCity_Zombie02.BP_AttackCity_Zombie02_C.PlayAttackStartSound // (BlueprintEvent) // @ game+0x24b46a0
	void PlayAttackEndSound(struct UtriMsng* Sound); // Function BP_AttackCity_Zombie02.BP_AttackCity_Zombie02_C.PlayAttackEndSound // (BlueprintEvent) // @ game+0x24b46a0
	void BP_OnDead(); // Function BP_AttackCity_Zombie02.BP_AttackCity_Zombie02_C.BP_OnDead // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_AttackCity_Zombie02(int32_t EntryPoint); // Function BP_AttackCity_Zombie02.BP_AttackCity_Zombie02_C.ExecuteUbergraph_BP_AttackCity_Zombie02 // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

