// BlueprintGeneratedClass Exe_Damage_PoisoningEffect1.Exe_Damage_PoisoningEffect1_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_PoisoningEffect1_C : UreLVite {
};

