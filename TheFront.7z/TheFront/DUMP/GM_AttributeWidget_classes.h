// WidgetBlueprintGeneratedClass GM_AttributeWidget.GM_AttributeWidget_C
// Size: 0x2e0 (Inherited: 0x2c8)
struct UGM_AttributeWidget_C : UIMJJnnh {
	struct UGM_AttributeSlot_C* GM_AttributeSlot; // 0x2c8(0x08)
	struct UGM_AttributeSlot_C* GM_AttributeSlot_2; // 0x2d0(0x08)
	struct UImage* Image_110; // 0x2d8(0x08)
};

