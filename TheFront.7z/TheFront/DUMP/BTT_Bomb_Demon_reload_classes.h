// BlueprintGeneratedClass BTT_Bomb_Demon_reload.BTT_Bomb_Demon_reload_C
// Size: 0x170 (Inherited: 0xa8)
struct UBTT_Bomb_Demon_reload_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	int32_t MaxProbability; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct FBlackboardKeySelector BigWeaponR; // 0xc0(0x28)
	int32_t Probability; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FBlackboardKeySelector BigWeaponL; // 0xf0(0x28)
	bool WeaponR_bool; // 0x118(0x01)
	bool WeaponL_bool; // 0x119(0x01)
	char pad_11A[0x6]; // 0x11a(0x06)
	struct FBlackboardKeySelector HasWeaponR; // 0x120(0x28)
	struct FBlackboardKeySelector HasWeaponL; // 0x148(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_Bomb_Demon_reload.BTT_Bomb_Demon_reload_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_Bomb_Demon_reload(int32_t EntryPoint); // Function BTT_Bomb_Demon_reload.BTT_Bomb_Demon_reload_C.ExecuteUbergraph_BTT_Bomb_Demon_reload // (Final|UbergraphFunction) // @ game+0x24b46a0
};

