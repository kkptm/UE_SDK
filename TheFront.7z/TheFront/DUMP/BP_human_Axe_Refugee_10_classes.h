// BlueprintGeneratedClass BP_human_Axe_Refugee_10.BP_human_Axe_Refugee_9_C
// Size: 0x1518 (Inherited: 0x1518)
struct ABP_human_Axe_Refugee_9_C : ABP_human_Axe_C {
};

