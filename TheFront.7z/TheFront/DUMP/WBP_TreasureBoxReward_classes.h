// WidgetBlueprintGeneratedClass WBP_TreasureBoxReward.WBP_TreasureBoxReward_C
// Size: 0x2c0 (Inherited: 0x2a0)
struct UWBP_TreasureBoxReward_C : UnnVUSqh {
	struct USrQNosh* Btn_TopClose; // 0x2a0(0x08)
	struct UImage* Esc_3; // 0x2a8(0x08)
	struct UImage* Esc_4; // 0x2b0(0x08)
	struct UImage* Image_Bg; // 0x2b8(0x08)

	struct FLinearColor Get_test_ColorAndOpacity_1(); // Function WBP_TreasureBoxReward.WBP_TreasureBoxReward_C.Get_test_ColorAndOpacity_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
};

