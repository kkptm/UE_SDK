// WidgetBlueprintGeneratedClass FormCropVegetableTipsBP.FormCropVegetableTipsBP_C
// Size: 0x288 (Inherited: 0x288)
struct UFormCropVegetableTipsBP_C : UnsnoTfg {
};

