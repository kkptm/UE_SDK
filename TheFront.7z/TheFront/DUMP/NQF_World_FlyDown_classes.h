// BlueprintGeneratedClass NQF_World_FlyDown.NQF_World_FlyDown_C
// Size: 0x58 (Inherited: 0x58)
struct UNQF_World_FlyDown_C : UrhoRmKg {
};

