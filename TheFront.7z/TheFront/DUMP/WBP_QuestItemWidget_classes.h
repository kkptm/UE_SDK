// WidgetBlueprintGeneratedClass WBP_QuestItemWidget.WBP_QuestItemWidget_C
// Size: 0x288 (Inherited: 0x288)
struct UWBP_QuestItemWidget_C : USoJnQmg {
};

