// WidgetBlueprintGeneratedClass WBP_CraftPanel.WBP_CraftPanel_C
// Size: 0x488 (Inherited: 0x3a8)
struct UWBP_CraftPanel_C : UeMRHVhh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a8(0x08)
	struct UWidgetAnimation* CraftOpenAni; // 0x3b0(0x08)
	struct UImage* CraftingListBG; // 0x3b8(0x08)
	struct UImage* Image_46; // 0x3c0(0x08)
	struct UImage* Image_428; // 0x3c8(0x08)
	struct UImage* InputBoxBG; // 0x3d0(0x08)
	struct UnlRqLnf* RadioButton; // 0x3d8(0x08)
	struct UnlRqLnf* RadioButton_1; // 0x3e0(0x08)
	struct UnlRqLnf* RadioButton_2; // 0x3e8(0x08)
	struct UnlRqLnf* RadioButton_3; // 0x3f0(0x08)
	struct UnlRqLnf* RadioButton_4; // 0x3f8(0x08)
	struct UnlRqLnf* RadioButton_5; // 0x400(0x08)
	struct UnlRqLnf* RadioButton_6; // 0x408(0x08)
	struct UnlRqLnf* RadioButton_7; // 0x410(0x08)
	struct UImage* SearchIcon; // 0x418(0x08)
	struct UWBP_RecipeButton_C* WBP_RecipeButton; // 0x420(0x08)
	struct UWBP_RecipeButton_C* WBP_RecipeButton_7; // 0x428(0x08)
	struct UWBP_RecipeButton_C* WBP_RecipeButton_8; // 0x430(0x08)
	struct UWBP_RecipeButton_C* WBP_RecipeButton_9; // 0x438(0x08)
	struct UWBP_RecipeButton_C* WBP_RecipeButton_142; // 0x440(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleAll; // 0x448(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleBasic; // 0x450(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleEquipment; // 0x458(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleStructure; // 0x460(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleSupply; // 0x468(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleTechnology; // 0x470(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleVehicle; // 0x478(0x08)
	struct UWBP_RecipeScaleItemTemp_C* WBP_ScaleWeapon; // 0x480(0x08)

	struct UWidget* Get_RadioButton_5_ToolTipWidget_1(); // Function WBP_CraftPanel.WBP_CraftPanel_C.Get_RadioButton_5_ToolTipWidget_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_7(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_7 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_6(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_6 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_5(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_5 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_4(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_4 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_3(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_3 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_2(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_2 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	struct UWidget* GetToolTipWidget_1(); // Function WBP_CraftPanel.WBP_CraftPanel_C.GetToolTipWidget_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24b46a0
	void Construct(); // Function WBP_CraftPanel.WBP_CraftPanel_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void CustomEvent_1(struct UokpsjLh* ItemButton); // Function WBP_CraftPanel.WBP_CraftPanel_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_CraftPanel(int32_t EntryPoint); // Function WBP_CraftPanel.WBP_CraftPanel_C.ExecuteUbergraph_WBP_CraftPanel // (Final|UbergraphFunction) // @ game+0x24b46a0
};

