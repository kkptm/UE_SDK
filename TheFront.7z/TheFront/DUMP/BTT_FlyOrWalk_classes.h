// BlueprintGeneratedClass BTT_FlyOrWalk.BTT_FlyOrWalk_C
// Size: 0xd8 (Inherited: 0xa8)
struct UBTT_FlyOrWalk_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector Fly; // 0xb0(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FlyOrWalk.BTT_FlyOrWalk_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FlyOrWalk(int32_t EntryPoint); // Function BTT_FlyOrWalk.BTT_FlyOrWalk_C.ExecuteUbergraph_BTT_FlyOrWalk // (Final|UbergraphFunction) // @ game+0x24b46a0
};

