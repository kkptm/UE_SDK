// BlueprintGeneratedClass AN_Bomb_Demon_ReloadWeapon.AN_Bomb_Demon_ReloadWeapon_C
// Size: 0x38 (Inherited: 0x38)
struct UAN_Bomb_Demon_ReloadWeapon_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_Bomb_Demon_ReloadWeapon.AN_Bomb_Demon_ReloadWeapon_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24b46a0
};

