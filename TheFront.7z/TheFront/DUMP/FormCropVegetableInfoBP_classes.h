// WidgetBlueprintGeneratedClass FormCropVegetableInfoBP.FormCropVegetableInfoBP_C
// Size: 0x2c0 (Inherited: 0x2b8)
struct UFormCropVegetableInfoBP_C : UkNToMUf {
	struct UImage* ImageBackground; // 0x2b8(0x08)
};

