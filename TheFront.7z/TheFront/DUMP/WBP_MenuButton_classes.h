// WidgetBlueprintGeneratedClass WBP_MenuButton.WBP_MenuButton_C
// Size: 0x300 (Inherited: 0x2f0)
struct UWBP_MenuButton_C : UfksKljh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f0(0x08)
	struct UCanvasPanel* CanvasPanel_Menu; // 0x2f8(0x08)

	void Construct(); // Function WBP_MenuButton.WBP_MenuButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpdateMenuSelected(bool IsSelected); // Function WBP_MenuButton.WBP_MenuButton_C.BPCall_UpdateMenuSelected // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpdateMenuPosition(struct FVector2D Pos); // Function WBP_MenuButton.WBP_MenuButton_C.BPCall_UpdateMenuPosition // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpdateMenuEnable(bool Enable); // Function WBP_MenuButton.WBP_MenuButton_C.BPCall_UpdateMenuEnable // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UMP(struct FVector2D Pos); // Function WBP_MenuButton.WBP_MenuButton_C.BPCall_UMP // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UME(bool bE); // Function WBP_MenuButton.WBP_MenuButton_C.BPCall_UME // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_MenuButton(int32_t EntryPoint); // Function WBP_MenuButton.WBP_MenuButton_C.ExecuteUbergraph_WBP_MenuButton // (Final|UbergraphFunction) // @ game+0x24b46a0
};

