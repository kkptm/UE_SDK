// BlueprintGeneratedClass BP_Hindenburg_Machine_Gun.BP_Hindenburg_Machine_Gun_C
// Size: 0x2f8 (Inherited: 0x2e0)
struct ABP_Hindenburg_Machine_Gun_C : AjnmOlJh {
	struct UArrowComponent* Arrow; // 0x2e0(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x2e8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2f0(0x08)
};

