// BlueprintGeneratedClass BP_Grenade_NPC_F_ClusterGrenade.BP_Grenade_NPC_F_ClusterGrenade_C
// Size: 0x448 (Inherited: 0x430)
struct ABP_Grenade_NPC_F_ClusterGrenade_C : AkNinPLh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)
	struct UNiagaraComponent* Niagara; // 0x438(0x08)
	struct UrfnLLpg* Ak_Bounce; // 0x440(0x08)

	void ReceiveBeginPlay(); // Function BP_Grenade_NPC_F_ClusterGrenade.BP_Grenade_NPC_F_ClusterGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Grenade_NPC_F_ClusterGrenade.BP_Grenade_NPC_F_ClusterGrenade_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveDestroyed(); // Function BP_Grenade_NPC_F_ClusterGrenade.BP_Grenade_NPC_F_ClusterGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Grenade_NPC_F_ClusterGrenade(int32_t EntryPoint); // Function BP_Grenade_NPC_F_ClusterGrenade.BP_Grenade_NPC_F_ClusterGrenade_C.ExecuteUbergraph_BP_Grenade_NPC_F_ClusterGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

