// WidgetBlueprintGeneratedClass WBP_RecipeButton.WBP_RecipeButton_C
// Size: 0x320 (Inherited: 0x318)
struct UWBP_RecipeButton_C : UPjtQkog {
	struct UImage* Image_56; // 0x318(0x08)
};

