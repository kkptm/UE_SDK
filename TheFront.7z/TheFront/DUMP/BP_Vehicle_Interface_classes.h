// BlueprintGeneratedClass BP_Vehicle_Interface.BP_Vehicle_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_Vehicle_Interface_C : UInterface {

	void IFunc_IsClientRunning(bool& Yes); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.IFunc_IsClientRunning // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void IFunc_IsClient(bool& Yes); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.IFunc_IsClient // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void IFunc_GetEngineSmokeNiagaras(struct TArray<struct UNiagaraComponent*>& Niagaras); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.IFunc_GetEngineSmokeNiagaras // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnLockTargetResult(bool Lock); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.OnLockTargetResult // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnEngineStateChanged(bool Start); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.OnEngineStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnRotorStateChanged(bool Start); // Function BP_Vehicle_Interface.BP_Vehicle_Interface_C.OnRotorStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

