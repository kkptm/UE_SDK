// BlueprintGeneratedClass GE_NPC_ElectricShock.GE_NPC_ElectricShock_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_NPC_ElectricShock_C : UGameplayEffect {
};

