// UserDefinedEnum UDS_ControlPointMode.UDS_ControlPointMode
enum class UDS_ControlPointMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	UDS_MAX = 3
};

