// WidgetBlueprintGeneratedClass WBP_MainForm_Menu.WBP_MainForm_Menu_C
// Size: 0x8c4 (Inherited: 0x378)
struct UWBP_MainForm_Menu_C : URerqUPg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x378(0x08)
	struct USrQNosh* BtnRefreshServers; // 0x380(0x08)
	struct USrQNosh* Button_Back; // 0x388(0x08)
	struct USrQNosh* Button_CreateDedicatidServer; // 0x390(0x08)
	struct USrQNosh* Button_CreateNonDsServer; // 0x398(0x08)
	struct USrQNosh* Button_EnterGame_2; // 0x3a0(0x08)
	struct USrQNosh* Button_Exit; // 0x3a8(0x08)
	struct USrQNosh* Button_SelectServer; // 0x3b0(0x08)
	struct USrQNosh* Button_Set; // 0x3b8(0x08)
	struct UHQQLjPh* CBoxGroup_ServerMenu; // 0x3c0(0x08)
	struct UnlRqLnf* CheckBoxEx_Custom; // 0x3c8(0x08)
	struct UnlRqLnf* CheckBoxEx_Fighter; // 0x3d0(0x08)
	struct UnlRqLnf* CheckBoxEx_Officia; // 0x3d8(0x08)
	struct UCircularThrobber* CircularThrobber_113; // 0x3e0(0x08)
	struct USrQNosh* Create; // 0x3e8(0x08)
	struct UTextBlock* CreateDedicatidServer; // 0x3f0(0x08)
	struct USrQNosh* DeleteRole; // 0x3f8(0x08)
	struct UEditableTextBox* EditableTextBox_204; // 0x400(0x08)
	struct UWBP_GameServerList_C* GameServerListNew; // 0x408(0x08)
	struct UHorizontalBox* HorizontalBox_Create; // 0x410(0x08)
	struct UHorizontalBox* HorizontalBox_Delete; // 0x418(0x08)
	struct UImage* Image; // 0x420(0x08)
	struct UImage* Image_108; // 0x428(0x08)
	struct UImage* Image_FindServer; // 0x430(0x08)
	struct UImage* Image_FindServer_2; // 0x438(0x08)
	struct UCanvasPanel* MainPanel; // 0x440(0x08)
	struct UWidgetSwitcher* PanelSwitch; // 0x448(0x08)
	struct UEditableTextBox* PlayerNameEditor; // 0x450(0x08)
	struct UCanvasPanel* RightMenu_Panel; // 0x458(0x08)
	struct UScrollBox* ScrollServers; // 0x460(0x08)
	struct UImage* SearchIcon; // 0x468(0x08)
	struct UCanvasPanel* SearchingPanel; // 0x470(0x08)
	struct UTextBlock* SearchStatuText; // 0x478(0x08)
	struct UTextBlock* TB_CreateServer; // 0x480(0x08)
	struct UTextBlock* TB_Entry; // 0x488(0x08)
	struct UTextBlock* TB_Exit; // 0x490(0x08)
	struct UTextBlock* TB_Select_Server; // 0x498(0x08)
	struct UTextBlock* TB_Settings; // 0x4a0(0x08)
	struct UTextBlock* TB_SteamInventory; // 0x4a8(0x08)
	struct UTextBlock* TextBlock_CDTime; // 0x4b0(0x08)
	struct UTextBlock* TextBlock_Version; // 0x4b8(0x08)
	struct UTextBlock* TextBlockOperID; // 0x4c0(0x08)
	struct UWBP_AnyKey_C* WBP_AnyKey; // 0x4c8(0x08)
	struct UWBP_MainForm_ServerMaster_C* WBP_MainForm_ServerMaster; // 0x4d0(0x08)
	struct USrQNosh* WiseButtonCopy; // 0x4d8(0x08)
	struct TArray<struct FRgOMlJg> FoundServers; // 0x4e0(0x10)
	struct TArray<struct UWBP_ServerRow_C*> FoundServersWidgets; // 0x4f0(0x10)
	struct UWBP_SimpleLoading_C* LoadingWidget; // 0x500(0x08)
	struct FString CustomPlayerName; // 0x508(0x10)
	int32_t PanelIdxMain; // 0x518(0x04)
	int32_t PanelIdxPlayerName; // 0x51c(0x04)
	int32_t PanelIdNonDsServer; // 0x520(0x04)
	int32_t PanelIdxSrvList; // 0x524(0x04)
	bool IsLANMode; // 0x528(0x01)
	char pad_529[0x7]; // 0x529(0x07)
	struct FRgOMlJg SelectGameResult; // 0x530(0x108)
	struct FSlateFontInfo NewFont; // 0x638(0x58)
	struct FSlateFontInfo DefaultFont; // 0x690(0x58)
	struct FSlateColor NewFontColor; // 0x6e8(0x28)
	struct FSlateColor DefaultFontColor; // 0x710(0x28)
	struct TArray<struct FRgOMlJg> OfficialServers; // 0x738(0x10)
	struct TArray<struct FRgOMlJg> CustomServers; // 0x748(0x10)
	struct TArray<struct FRgOMlJg> FightServers; // 0x758(0x10)
	struct FRgOMlJg Array Element; // 0x768(0x108)
	struct UWBP_ServerInfoUMG_C* ServerInfoPanel; // 0x870(0x08)
	struct FMulticastInlineDelegate OnKeyDownDispatcher; // 0x878(0x10)
	struct UWBP_JoinQueue_C* QueueWidget; // 0x888(0x08)
	float CDLeftTime; // 0x890(0x04)
	char pad_894[0x4]; // 0x894(0x04)
	struct FText Format_CDTime; // 0x898(0x18)
	struct UObject* SelectedGameItem; // 0x8b0(0x08)
	struct UObject* Item; // 0x8b8(0x08)
	int32_t PanelIdxSteamInventory; // 0x8c0(0x04)

	void UpdateCDTime(int32_t Time); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.UpdateCDTime // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ToggleAvatarForm(bool IsOpen); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.ToggleAvatarForm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdateCreateUI(struct FString PlayerName, bool IsConnected); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.UpdateCreateUI // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnUserLogin(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnUserLogin // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void RefreshMainPanel(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.RefreshMainPanel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void SetSelectGameResultX(struct FRgOMlJg InGameResult); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.SetSelectGameResultX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ClearServerList(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.ClearServerList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void HideLoading(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.HideLoading // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Show Loading(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Show Loading // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Fill Online Games(struct TArray<struct FRgOMlJg>& OnlineGames); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Fill Online Games // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnFailure_7DF8C20E452019D3C93001A9A9ECFA32(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnFailure_7DF8C20E452019D3C93001A9A9ECFA32 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSuccess_7DF8C20E452019D3C93001A9A9ECFA32(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnSuccess_7DF8C20E452019D3C93001A9A9ECFA32 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnFailure_C1D5C0F042D596989EF23E9F18A611C7(struct TArray<struct FRgOMlJg>& Results); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnFailure_C1D5C0F042D596989EF23E9F18A611C7 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSuccess_C1D5C0F042D596989EF23E9F18A611C7(struct TArray<struct FRgOMlJg>& Results); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnSuccess_C1D5C0F042D596989EF23E9F18A611C7 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnFailure_891BDE804D2927EB9859B4812437E42B(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnFailure_891BDE804D2927EB9859B4812437E42B // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSuccess_891BDE804D2927EB9859B4812437E42B(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnSuccess_891BDE804D2927EB9859B4812437E42B // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnInitialized(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_BtnRefreshServers_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_BtnRefreshServers_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_PlayerNameEditor_K2Node_ComponentBoundEvent_1_OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_PlayerNameEditor_K2Node_ComponentBoundEvent_1_OnEditableTextChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_10_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_10_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_13_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_13_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_14_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_14_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_15_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_SelectServer_K2Node_ComponentBoundEvent_15_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_CreateServer_K2Node_ComponentBoundEvent_16_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_CreateServer_K2Node_ComponentBoundEvent_16_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_17_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Set_K2Node_ComponentBoundEvent_17_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_18_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_Exit_K2Node_ComponentBoundEvent_18_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_Button_145_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_Button_145_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Load_CBoxGroup_ServerMenu_K2Node_ComponentBoundEvent_16_OnRadioStateChanged__DelegateSignature(struct UnlRqLnf* Button, int32_t Index, struct UnlRqLnf* OldButton, int32_t OldIndex); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Load_CBoxGroup_ServerMenu_K2Node_ComponentBoundEvent_16_OnRadioStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void RefreshServers(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.RefreshServers // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_CharacterCreateUI(struct FString PlayerName); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_CharacterCreateUI // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Create_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Create_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_ToggleCreateAvatarForm(bool IsOpen); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_ToggleCreateAvatarForm // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_DeleteRole_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_DeleteRole_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_CreateServer_K2Node_ComponentBoundEvent_21_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_CreateServer_K2Node_ComponentBoundEvent_21_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_EnterGame_1_K2Node_ComponentBoundEvent_12_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_EnterGame_1_K2Node_ComponentBoundEvent_12_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void InitServerListUI(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.InitServerListUI // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSelelctServerList(struct FNiWItIh ServerInfo); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnSelelctServerList // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnGameListPressBack(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnGameListPressBack // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnServerItemClicked(struct FNiWItIh ServerInfo); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnServerItemClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExsCloseGameServerListPage(struct FKeyEvent KeyEvent); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.ExsCloseGameServerListPage // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_ACUI(struct FString PN, bool bServerConnect); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_ACUI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_CAF01(bool bO); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_CAF01 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_Err(struct FString ErrC); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_Err // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void OnPresentForm(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnPresentForm // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_NoC01(bool bO); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_NoC01 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_EtrSvr(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_EtrSvr // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void Receive_OGQW(int32_t position); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Receive_OGQW // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Receive_UGQP(int32_t NewPos); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Receive_UGQP // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Receive_CGQW(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Receive_CGQW // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Receive_QGQ(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Receive_QGQ // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_QTL(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_QTL // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpCD(float CDTime); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BPCall_UpCD // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_9_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_9_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_25_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_CreateDedicatidServer_K2Node_ComponentBoundEvent_25_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ConnectToSelectedServer(struct FNiWItIh TargetServerInfo, struct FString Password); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.ConnectToSelectedServer // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_WiseButton_105_K2Node_ComponentBoundEvent_26_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_WiseButton_105_K2Node_ComponentBoundEvent_26_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_CreateNonDsServer_K2Node_ComponentBoundEvent_27_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_CreateNonDsServer_K2Node_ComponentBoundEvent_27_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_23_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_23_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_24_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_24_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_28_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.BndEvt__WBP_MainForm_Menu_Button_SteamInventory_K2Node_ComponentBoundEvent_28_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_MainForm_Menu(int32_t EntryPoint); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.ExecuteUbergraph_WBP_MainForm_Menu // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
	void OnKeyDownDispatcher__DelegateSignature(struct FKeyEvent KeyEvent); // Function WBP_MainForm_Menu.WBP_MainForm_Menu_C.OnKeyDownDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

