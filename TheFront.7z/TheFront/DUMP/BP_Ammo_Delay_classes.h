// BlueprintGeneratedClass BP_Ammo_Delay.BP_Ammo_Delay_C
// Size: 0x4f8 (Inherited: 0x4f0)
struct ABP_Ammo_Delay_C : ArNhULjf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f0(0x08)

	void BPCall_OnDestroy(struct UNiagaraComponent* Niagara); // Function BP_Ammo_Delay.BP_Ammo_Delay_C.BPCall_OnDestroy // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Ammo_Delay(int32_t EntryPoint); // Function BP_Ammo_Delay.BP_Ammo_Delay_C.ExecuteUbergraph_BP_Ammo_Delay // (Final|UbergraphFunction) // @ game+0x24b46a0
};

