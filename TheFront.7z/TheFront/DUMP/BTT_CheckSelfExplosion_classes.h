// BlueprintGeneratedClass BTT_CheckSelfExplosion.BTT_CheckSelfExplosion_C
// Size: 0xb4 (Inherited: 0xa8)
struct UBTT_CheckSelfExplosion_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	float SelfExplosion_HP_PCT; // 0xb0(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CheckSelfExplosion.BTT_CheckSelfExplosion_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_CheckSelfExplosion(int32_t EntryPoint); // Function BTT_CheckSelfExplosion.BTT_CheckSelfExplosion_C.ExecuteUbergraph_BTT_CheckSelfExplosion // (Final|UbergraphFunction) // @ game+0x24b46a0
};

