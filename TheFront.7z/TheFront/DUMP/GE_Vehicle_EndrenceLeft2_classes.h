// BlueprintGeneratedClass GE_Vehicle_EndrenceLeft2.GE_Vehicle_EndrenceLeft2_C
// Size: 0x828 (Inherited: 0x828)
struct UGE_Vehicle_EndrenceLeft2_C : UTNoSqeg {
};

