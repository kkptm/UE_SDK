// BlueprintGeneratedClass GameSetting_Shortcut.GameSetting_Shortcut_C
// Size: 0x68 (Inherited: 0x68)
struct UGameSetting_Shortcut_C : ULVSQQoe {
};

