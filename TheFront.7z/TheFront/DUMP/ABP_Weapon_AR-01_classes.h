// AnimBlueprintGeneratedClass ABP_Weapon_AR-01.ABP_Weapon_AR-01_C
// Size: 0x3d0 (Inherited: 0x2d0)
struct UABP_Weapon_AR-01_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x308(0x80)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x388(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Weapon_AR-01.ABP_Weapon_AR-01_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Weapon_AR-01(int32_t EntryPoint); // Function ABP_Weapon_AR-01.ABP_Weapon_AR-01_C.ExecuteUbergraph_ABP_Weapon_AR-01 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

