// BlueprintGeneratedClass GE_Kungaloosh.GE_Kungaloosh_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Kungaloosh_C : UGameplayEffect {
};

