// BlueprintGeneratedClass Exe_ReduceBloodTime_2.Exe_ReduceBloodTime_1_C
// Size: 0x68 (Inherited: 0x68)
struct UExe_ReduceBloodTime_1_C : UnKoOipe {
};

