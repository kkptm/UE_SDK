// BlueprintGeneratedClass ConstructManagerBP.ConstructManagerBP_C
// Size: 0x950 (Inherited: 0x950)
struct UConstructManagerBP_C : UTpVTetg {
};

