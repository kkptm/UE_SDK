// AnimBlueprintGeneratedClass ABP_Weapon_Soldiers_002.ABP_Weapon_Soldiers_002_C
// Size: 0x3d0 (Inherited: 0x2d0)
struct UABP_Weapon_Soldiers_002_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x308(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x350(0x80)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Weapon_Soldiers_002.ABP_Weapon_Soldiers_002_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Weapon_Soldiers_002(int32_t EntryPoint); // Function ABP_Weapon_Soldiers_002.ABP_Weapon_Soldiers_002_C.ExecuteUbergraph_ABP_Weapon_Soldiers_002 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

