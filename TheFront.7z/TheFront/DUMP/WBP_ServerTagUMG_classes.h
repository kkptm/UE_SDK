// WidgetBlueprintGeneratedClass WBP_ServerTagUMG.WBP_ServerTagUMG_C
// Size: 0x288 (Inherited: 0x260)
struct UWBP_ServerTagUMG_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_683; // 0x268(0x08)
	struct UTextBlock* Tag_TextCtrl; // 0x270(0x08)
	struct FString Text; // 0x278(0x10)

	void Construct(); // Function WBP_ServerTagUMG.WBP_ServerTagUMG_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ServerTagUMG(int32_t EntryPoint); // Function WBP_ServerTagUMG.WBP_ServerTagUMG_C.ExecuteUbergraph_WBP_ServerTagUMG // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

