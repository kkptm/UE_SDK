// BlueprintGeneratedClass BP_Bomb_Demon.BP_Bomb_Demon_C
// Size: 0x1534 (Inherited: 0x1500)
struct ABP_Bomb_Demon_C : ABP_human_common_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1500(0x08)
	struct UStaticMeshComponent* NPC_Bomb_Demon_Weapon_002_R; // 0x1508(0x08)
	struct UStaticMeshComponent* NPC_Bomb_Demon_Weapon_002_L; // 0x1510(0x08)
	struct UStaticMeshComponent* NPC_Bomb_Demon_Weapon_001_L; // 0x1518(0x08)
	struct UStaticMeshComponent* NPC_Bomb_Demon_Weapon_001_R; // 0x1520(0x08)
	struct UWidgetComponent* WidgetNameTag; // 0x1528(0x08)
	bool TreeWeapon L; // 0x1530(0x01)
	bool TreeWeapon R; // 0x1531(0x01)
	bool WeaponL_Display; // 0x1532(0x01)
	bool WeaponR_Display; // 0x1533(0x01)

	void Bomb_Demon_reload(bool WeaponL, bool WeaponR); // Function BP_Bomb_Demon.BP_Bomb_Demon_C.Bomb_Demon_reload // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Bomb_Demon_WeaponL(bool WeaponL); // Function BP_Bomb_Demon.BP_Bomb_Demon_C.Bomb_Demon_WeaponL // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Bomb_Demon_WeaponR(bool WeaponR); // Function BP_Bomb_Demon.BP_Bomb_Demon_C.Bomb_Demon_WeaponR // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Bomb_Demon_reload_A(); // Function BP_Bomb_Demon.BP_Bomb_Demon_C.Bomb_Demon_reload_A // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Bomb_Demon(int32_t EntryPoint); // Function BP_Bomb_Demon.BP_Bomb_Demon_C.ExecuteUbergraph_BP_Bomb_Demon // (Final|UbergraphFunction) // @ game+0x24b46a0
};

