// AnimBlueprintGeneratedClass SK_Harvester_Skeleton_AnimBlueprint.SK_Harvester_Skeleton_AnimBlueprint_C
// Size: 0x554 (Inherited: 0x2d0)
struct USK_Harvester_Skeleton_AnimBlueprint_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose; // 0x308(0x10)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x318(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x338(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x440(0x108)
	struct FRotator EquipRot; // 0x548(0x0c)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function SK_Harvester_Skeleton_AnimBlueprint.SK_Harvester_Skeleton_AnimBlueprint_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function SK_Harvester_Skeleton_AnimBlueprint.SK_Harvester_Skeleton_AnimBlueprint_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_SK_Harvester_Skeleton_AnimBlueprint(int32_t EntryPoint); // Function SK_Harvester_Skeleton_AnimBlueprint.SK_Harvester_Skeleton_AnimBlueprint_C.ExecuteUbergraph_SK_Harvester_Skeleton_AnimBlueprint // (Final|UbergraphFunction) // @ game+0x24b46a0
};

