// BlueprintGeneratedClass BP_AW_TD01_Front.BP_AW_TD01_Front_C
// Size: 0x220 (Inherited: 0x220)
struct UBP_AW_TD01_Front_C : UChaosVehicleWheel {
};

