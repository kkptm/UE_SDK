// WidgetBlueprintGeneratedClass WBP_ItemTipsPanel.WBP_ItemTipsPanel_C
// Size: 0x398 (Inherited: 0x330)
struct UWBP_ItemTipsPanel_C : UnMLpJfh {
	struct UImage* Image; // 0x330(0x08)
	struct UImage* Image_2; // 0x338(0x08)
	struct UImage* Image_3; // 0x340(0x08)
	struct UImage* Image_4; // 0x348(0x08)
	struct UImage* Image_99; // 0x350(0x08)
	struct UImage* Image_103; // 0x358(0x08)
	struct UImage* NameBG; // 0x360(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel; // 0x368(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel_2; // 0x370(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel_3; // 0x378(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel_4; // 0x380(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel_5; // 0x388(0x08)
	struct UWBP_NeedResourcePanel_C* WBP_NeedResourcePanel_6; // 0x390(0x08)
};

