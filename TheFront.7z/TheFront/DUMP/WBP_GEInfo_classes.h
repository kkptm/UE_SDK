// WidgetBlueprintGeneratedClass WBP_GEInfo.WBP_GEInfo_C
// Size: 0x2c8 (Inherited: 0x2b8)
struct UWBP_GEInfo_C : UrmJtnmg {
	struct UImage* BG; // 0x2b8(0x08)
	struct UImage* IconBg; // 0x2c0(0x08)
};

