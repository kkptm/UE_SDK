// WidgetBlueprintGeneratedClass WBP_RepairResourceList.WBP_RepairResourceList_C
// Size: 0x288 (Inherited: 0x280)
struct UWBP_RepairResourceList_C : UhmqHhPg {
	struct UImage* Image_50; // 0x280(0x08)
};

