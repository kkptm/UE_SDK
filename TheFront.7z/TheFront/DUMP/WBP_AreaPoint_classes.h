// WidgetBlueprintGeneratedClass WBP_AreaPoint.WBP_AreaPoint_C
// Size: 0x2a0 (Inherited: 0x298)
struct UWBP_AreaPoint_C : UVfnNjJg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_AreaPoint.WBP_AreaPoint_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_AreaPoint(int32_t EntryPoint); // Function WBP_AreaPoint.WBP_AreaPoint_C.ExecuteUbergraph_WBP_AreaPoint // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

