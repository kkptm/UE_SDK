// WidgetBlueprintGeneratedClass WBP_SimpleCountdownBar.WBP_SimpleCountdownBar_C
// Size: 0x290 (Inherited: 0x288)
struct UWBP_SimpleCountdownBar_C : UQTgtQVh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)

	void Construct(); // Function WBP_SimpleCountdownBar.WBP_SimpleCountdownBar_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_SimpleCountdownBar(int32_t EntryPoint); // Function WBP_SimpleCountdownBar.WBP_SimpleCountdownBar_C.ExecuteUbergraph_WBP_SimpleCountdownBar // (Final|UbergraphFunction) // @ game+0x24b46a0
};

