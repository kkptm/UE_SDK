// WidgetBlueprintGeneratedClass ConstructRepairResourceListBP.ConstructRepairResourceListBP_C
// Size: 0x268 (Inherited: 0x268)
struct UConstructRepairResourceListBP_C : UOSmhlsh {
};

