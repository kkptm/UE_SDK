// WidgetBlueprintGeneratedClass WBP_ServerInfoUMG.WBP_ServerInfoUMG_C
// Size: 0x510 (Inherited: 0x260)
struct UWBP_ServerInfoUMG_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* BigClose_Button; // 0x268(0x08)
	struct UProgressBar* Download_ProgressBar; // 0x270(0x08)
	struct UImage* Esc; // 0x278(0x08)
	struct UImage* Esc_2; // 0x280(0x08)
	struct UImage* Image; // 0x288(0x08)
	struct UImage* Image_217; // 0x290(0x08)
	struct UImage* Image_355; // 0x298(0x08)
	struct UVerticalBox* ModDesc_Container; // 0x2a0(0x08)
	struct UMultiLineEditableText* ModDesc_TextCtrl; // 0x2a8(0x08)
	struct UMultiLineEditableText* ServerDesc_TextCtrl; // 0x2b0(0x08)
	struct UHorizontalBox* ServerTags_CtrlContainer; // 0x2b8(0x08)
	struct UButton* SmallClose_Button; // 0x2c0(0x08)
	struct UButton* Start_ButtonCtrl; // 0x2c8(0x08)
	struct UTextBlock* StartButton_TextCtrl; // 0x2d0(0x08)
	struct UTextBlock* Status_TextCtrl; // 0x2d8(0x08)
	struct UTextBlock* Tips_TextCtrl; // 0x2e0(0x08)
	struct FMulticastInlineDelegate OnConnectServer; // 0x2e8(0x10)
	struct FText ServerDesc; // 0x2f8(0x18)
	struct TArray<int32_t> TagArray; // 0x310(0x10)
	struct FString ModDesc; // 0x320(0x10)
	bool IsDownloadComplete; // 0x330(0x01)
	bool IsModServer; // 0x331(0x01)
	char pad_332[0x2]; // 0x332(0x02)
	int32_t ModNum; // 0x334(0x04)
	struct FMulticastInlineDelegate OnDownloadComplete; // 0x338(0x10)
	struct FMulticastInlineDelegate OnDownloadNext; // 0x348(0x10)
	struct TArray<int64_t> DownloadFailedArray; // 0x358(0x10)
	int32_t ModIndex; // 0x368(0x04)
	char pad_36C[0x4]; // 0x36c(0x04)
	struct FText TipText; // 0x370(0x18)
	struct TArray<int64_t> ToMountArray; // 0x388(0x10)
	bool IsMountSuccess; // 0x398(0x01)
	char pad_399[0x7]; // 0x399(0x07)
	struct TArray<struct FIteKOeg> ModInfoArray; // 0x3a0(0x10)
	struct FIteKOeg ModInfo; // 0x3b0(0x18)
	struct FNiWItIh ServerInfo; // 0x3c8(0x138)
	struct TArray<struct FIteKOeg> ToDownloadArray; // 0x500(0x10)

	void OnProgress_50DD97F44D8E4C4E995696A4E10C3D81(bool Success, struct FString ModName, int64_t ModId, float Percent); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnProgress_50DD97F44D8E4C4E995696A4E10C3D81 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnFailure_50DD97F44D8E4C4E995696A4E10C3D81(bool Success, struct FString ModName, int64_t ModId, float Percent); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnFailure_50DD97F44D8E4C4E995696A4E10C3D81 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSuccess_50DD97F44D8E4C4E995696A4E10C3D81(bool Success, struct FString ModName, int64_t ModId, float Percent); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnSuccess_50DD97F44D8E4C4E995696A4E10C3D81 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__BP_ServerInfoUMG_Button_57_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.BndEvt__BP_ServerInfoUMG_Button_57_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__BP_ServerInfoUMG_Button_84_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.BndEvt__BP_ServerInfoUMG_Button_84_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__BP_ServerInfoUMG_Start_ButtonCtrl_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.BndEvt__BP_ServerInfoUMG_Start_ButtonCtrl_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void OnDownloadNext_Event(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnDownloadNext_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnDownloadComplete_Event(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnDownloadComplete_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ServerInfoUMG(int32_t EntryPoint); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.ExecuteUbergraph_WBP_ServerInfoUMG // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
	void OnDownloadNext__DelegateSignature(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnDownloadNext__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnDownloadComplete__DelegateSignature(); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnDownloadComplete__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnConnectServer__DelegateSignature(struct FNiWItIh ServerInfo); // Function WBP_ServerInfoUMG.WBP_ServerInfoUMG_C.OnConnectServer__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

