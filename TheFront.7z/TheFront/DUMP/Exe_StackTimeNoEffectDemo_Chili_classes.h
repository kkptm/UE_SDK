// BlueprintGeneratedClass Exe_StackTimeNoEffectDemo_Chili.Exe_StackTimeNoEffectDemo_Chili_C
// Size: 0x58 (Inherited: 0x58)
struct UExe_StackTimeNoEffectDemo_Chili_C : UMSnOjVf {
};

