// BlueprintGeneratedClass GE_StunGrenade_Slow.GE_StunGrenade_Slow_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_StunGrenade_Slow_C : UGameplayEffect {
};

