// WidgetBlueprintGeneratedClass WBP_NpcSkillWidget.WBP_NpcSkillWidget_C
// Size: 0x2c8 (Inherited: 0x2a8)
struct UWBP_NpcSkillWidget_C : UWRpQJUe {
	struct UImage* RecipeBG; // 0x2a8(0x08)
	struct UImage* TalentBG_2; // 0x2b0(0x08)
	struct UTextBlock* Text_Recipe; // 0x2b8(0x08)
	struct UTextBlock* Text_Talent; // 0x2c0(0x08)
};

