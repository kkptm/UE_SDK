// WidgetBlueprintGeneratedClass WBP_VehicleAssistWeapon_Button.WBP_VehicleAssistWeapon_Button_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct UWBP_VehicleAssistWeapon_Button_C : UKfpqqLh {
};

