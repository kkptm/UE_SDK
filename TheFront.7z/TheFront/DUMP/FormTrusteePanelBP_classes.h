// WidgetBlueprintGeneratedClass FormTrusteePanelBP.FormTrusteePanelBP_C
// Size: 0x358 (Inherited: 0x310)
struct UFormTrusteePanelBP_C : UOsLekjf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP; // 0x318(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP_2; // 0x320(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP_3; // 0x328(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP_4; // 0x330(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP_5; // 0x338(0x08)
	struct UFormTrusteeItemBP_C* FormTrusteeItemBP_6; // 0x340(0x08)
	struct UImage* Image_186; // 0x348(0x08)
	struct USrQNosh* WiseButton_63; // 0x350(0x08)

	void Construct(); // Function FormTrusteePanelBP.FormTrusteePanelBP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_FormTrusteePanelBP(int32_t EntryPoint); // Function FormTrusteePanelBP.FormTrusteePanelBP_C.ExecuteUbergraph_FormTrusteePanelBP // (Final|UbergraphFunction) // @ game+0x24b46a0
};

