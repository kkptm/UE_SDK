// BlueprintGeneratedClass BTT_TargetActorDistance.BTT_TargetActorDistance_C
// Size: 0xe8 (Inherited: 0xa8)
struct UBTT_TargetActorDistance_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct FBlackboardKeySelector Target Actor; // 0xb8(0x28)
	float MaxDustance; // 0xe0(0x04)
	float MixDustance; // 0xe4(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_TargetActorDistance.BTT_TargetActorDistance_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_TargetActorDistance(int32_t EntryPoint); // Function BTT_TargetActorDistance.BTT_TargetActorDistance_C.ExecuteUbergraph_BTT_TargetActorDistance // (Final|UbergraphFunction) // @ game+0x24b46a0
};

