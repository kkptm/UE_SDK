// BlueprintGeneratedClass NQF_World_FlyDown_D.NQF_World_FlyDown_D_C
// Size: 0x58 (Inherited: 0x58)
struct UNQF_World_FlyDown_D_C : UrhoRmKg {
};

