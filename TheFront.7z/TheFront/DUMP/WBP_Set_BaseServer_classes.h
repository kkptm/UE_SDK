// WidgetBlueprintGeneratedClass WBP_Set_BaseServer.WBP_Set_BaseServer_C
// Size: 0x298 (Inherited: 0x281)
struct UWBP_Set_BaseServer_C : UWBP_BaseGroup_C {
	char pad_281[0x7]; // 0x281(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UUniformGridPanel* UniformGridPanel; // 0x290(0x08)

	void FillDatas(); // Function WBP_Set_BaseServer.WBP_Set_BaseServer_C.FillDatas // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_Set_BaseServer(int32_t EntryPoint); // Function WBP_Set_BaseServer.WBP_Set_BaseServer_C.ExecuteUbergraph_WBP_Set_BaseServer // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

