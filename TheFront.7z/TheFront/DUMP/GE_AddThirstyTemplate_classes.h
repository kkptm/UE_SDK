// BlueprintGeneratedClass GE_AddThirstyTemplate.GE_AddThirstyTemplate_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AddThirstyTemplate_C : UGameplayEffect {
};

