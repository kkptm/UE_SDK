// WidgetBlueprintGeneratedClass WBP_PartUnitItem.WBP_PartUnitItem_C
// Size: 0x294 (Inherited: 0x260)
struct UWBP_PartUnitItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCheckBox* CheckBox_Selected; // 0x268(0x08)
	struct UImage* Icon; // 0x270(0x08)
	struct FMulticastInlineDelegate OnSelectedEvent; // 0x278(0x10)
	int32_t PosIdx; // 0x288(0x04)
	struct FName Ident; // 0x28c(0x08)

	void InitAvatarHairColor(int32_t InPosIdx, struct FName InIdent, struct FKgriLhg InAvatarHairColor); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.InitAvatarHairColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitAvatarItem(int32_t InPosIndex, struct FgnQfsmh InAvatarEquipItem); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.InitAvatarItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void SetSelected(bool bSelected, bool bInit); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.SetSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnSelected(bool bSelected); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.OnSelected // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_PartUnitItem_CheckBox_Selected_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.BndEvt__WBP_PartUnitItem_CheckBox_Selected_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PartUnitItem(int32_t EntryPoint); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.ExecuteUbergraph_WBP_PartUnitItem // (Final|UbergraphFunction) // @ game+0x24b46a0
	void OnSelectedEvent__DelegateSignature(int32_t PosIdx, struct FName Ident); // Function WBP_PartUnitItem.WBP_PartUnitItem_C.OnSelectedEvent__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

