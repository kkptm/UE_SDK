// WidgetBlueprintGeneratedClass FormGuildMainBP.FormGuildMainBP_C
// Size: 0x638 (Inherited: 0x5b8)
struct UFormGuildMainBP_C : UrJtTQqh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5b8(0x08)
	struct UWidgetAnimation* GuildMainBPAnim; // 0x5c0(0x08)
	struct UWidgetAnimation* CreateHoverAni; // 0x5c8(0x08)
	struct UWidgetAnimation* JoinHoverAni; // 0x5d0(0x08)
	struct UImage* Image; // 0x5d8(0x08)
	struct UImage* Image_2; // 0x5e0(0x08)
	struct UImage* Image_3; // 0x5e8(0x08)
	struct UImage* Image_4; // 0x5f0(0x08)
	struct UImage* Image_5; // 0x5f8(0x08)
	struct UImage* Image_72; // 0x600(0x08)
	struct UImage* Image_168; // 0x608(0x08)
	struct UImage* Image_183; // 0x610(0x08)
	struct UImage* Image_262; // 0x618(0x08)
	struct UImage* Image_305; // 0x620(0x08)
	struct UImage* ImageBackground; // 0x628(0x08)
	struct UImage* Mark; // 0x630(0x08)

	void Construct(); // Function FormGuildMainBP.FormGuildMainBP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__FormGuildMainBP_BtnCreateNewGuild_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function FormGuildMainBP.FormGuildMainBP_C.BndEvt__FormGuildMainBP_BtnCreateNewGuild_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__FormGuildMainBP_BtnCreateNewGuild_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function FormGuildMainBP.FormGuildMainBP_C.BndEvt__FormGuildMainBP_BtnCreateNewGuild_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__FormGuildMainBP_BtnJoinGuild_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function FormGuildMainBP.FormGuildMainBP_C.BndEvt__FormGuildMainBP_BtnJoinGuild_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__FormGuildMainBP_BtnJoinGuild_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function FormGuildMainBP.FormGuildMainBP_C.BndEvt__FormGuildMainBP_BtnJoinGuild_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_FormGuildMainBP(int32_t EntryPoint); // Function FormGuildMainBP.FormGuildMainBP_C.ExecuteUbergraph_FormGuildMainBP // (Final|UbergraphFunction) // @ game+0x24b46a0
};

