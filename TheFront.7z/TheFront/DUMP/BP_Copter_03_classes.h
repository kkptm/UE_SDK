// BlueprintGeneratedClass BP_Copter_03.BP_Copter_03_C
// Size: 0x968 (Inherited: 0x94d)
struct ABP_Copter_03_C : ABP_CopterPawn_C {
	char pad_94D[0x3]; // 0x94d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x950(0x08)
	struct UKoOseSh* SM_MainRotor2; // 0x958(0x08)
	struct UNiagaraComponent* NS_HeatWave2; // 0x960(0x08)

	void ShowRotorBlade(bool Show); // Function BP_Copter_03.BP_Copter_03_C.ShowRotorBlade // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveBeginPlay(); // Function BP_Copter_03.BP_Copter_03_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void OnRotorStateChanged(bool Start); // Function BP_Copter_03.BP_Copter_03_C.OnRotorStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void OnEngineStateChanged(bool Start); // Function BP_Copter_03.BP_Copter_03_C.OnEngineStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_C0009(); // Function BP_Copter_03.BP_Copter_03_C.BPCall_C0009 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_C0002(struct AQRjQiNh* Passenger, enum class EVehicleSeatType Seat, struct AWeHQeeg* Weapon); // Function BP_Copter_03.BP_Copter_03_C.BPCall_C0002 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_C0003(struct AQRjQiNh* Passenger, enum class EVehicleSeatType Seat, struct AWeHQeeg* Weapon); // Function BP_Copter_03.BP_Copter_03_C.BPCall_C0003 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Copter_03(int32_t EntryPoint); // Function BP_Copter_03.BP_Copter_03_C.ExecuteUbergraph_BP_Copter_03 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

