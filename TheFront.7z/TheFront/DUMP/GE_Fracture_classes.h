// BlueprintGeneratedClass GE_Fracture.GE_Fracture_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Fracture_C : UGameplayEffect {
};

