// BlueprintGeneratedClass Exe_Damage_Burn.Exe_Damage_Burn_C
// Size: 0x50 (Inherited: 0x50)
struct UExe_Damage_Burn_C : UreLVite {
};

