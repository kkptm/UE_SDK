// WidgetBlueprintGeneratedClass WBP_VehicleAssistWeaponShortcutPannel.WBP_VehicleAssistWeaponShortcutPannel_C
// Size: 0x298 (Inherited: 0x278)
struct UWBP_VehicleAssistWeaponShortcutPannel_C : UpeLqgIh {
	struct UWBP_VehicleAssistWeapon_Button_C* WBP_VehicleAssistWeapon_Button_1; // 0x278(0x08)
	struct UWBP_VehicleAssistWeapon_Button_C* WBP_VehicleAssistWeapon_Button_2; // 0x280(0x08)
	struct UWBP_VehicleAssistWeapon_Button_C* WBP_VehicleAssistWeapon_Button_3; // 0x288(0x08)
	struct UWrapBox* WrapBoxShortcut; // 0x290(0x08)
};

