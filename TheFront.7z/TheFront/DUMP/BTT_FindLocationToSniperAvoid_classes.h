// BlueprintGeneratedClass BTT_FindLocationToSniperAvoid.BTT_FindLocationToSniperAvoid_C
// Size: 0x114 (Inherited: 0xa8)
struct UBTT_FindLocationToSniperAvoid_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AqjpNNMe* SelfActor; // 0xb0(0x08)
	struct AActor* TargetActor; // 0xb8(0x08)
	struct FBlackboardKeySelector KeyTargetActor; // 0xc0(0x28)
	struct FBlackboardKeySelector KeyTargetLocation; // 0xe8(0x28)
	float Distance; // 0x110(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindLocationToSniperAvoid.BTT_FindLocationToSniperAvoid_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BTT_FindLocationToSniperAvoid(int32_t EntryPoint); // Function BTT_FindLocationToSniperAvoid.BTT_FindLocationToSniperAvoid_C.ExecuteUbergraph_BTT_FindLocationToSniperAvoid // (Final|UbergraphFunction) // @ game+0x24b46a0
};

