// WidgetBlueprintGeneratedClass FormPlayerLocationPaneBP.FormPlayerLocationPaneBP_C
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFormPlayerLocationPaneBP_C : UoRSeHUg {
	struct UImage* ImageBackground; // 0x2a8(0x08)
};

