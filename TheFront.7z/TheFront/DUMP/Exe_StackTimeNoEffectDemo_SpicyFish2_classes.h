// BlueprintGeneratedClass Exe_StackTimeNoEffectDemo_SpicyFish2.Exe_StackTimeNoEffectDemo_SpicyFish2_C
// Size: 0x58 (Inherited: 0x58)
struct UExe_StackTimeNoEffectDemo_SpicyFish2_C : UMSnOjVf {
};

