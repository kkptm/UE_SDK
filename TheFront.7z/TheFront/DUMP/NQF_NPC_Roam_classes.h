// BlueprintGeneratedClass NQF_NPC_Roam.NQF_NPC_Roam_C
// Size: 0x58 (Inherited: 0x58)
struct UNQF_NPC_Roam_C : UrhoRmKg {
};

