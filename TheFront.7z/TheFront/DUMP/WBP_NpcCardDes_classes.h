// WidgetBlueprintGeneratedClass WBP_NpcCardDes.WBP_NpcCardDes_C
// Size: 0x328 (Inherited: 0x2c0)
struct UWBP_NpcCardDes_C : ULgLqVqh {
	struct UCanvasPanel* CanvasPanel_Attribute; // 0x2c0(0x08)
	struct UCanvasPanel* CanvasPanel_Drop; // 0x2c8(0x08)
	struct UCanvasPanel* CanvasPanel_NpcCard; // 0x2d0(0x08)
	struct UCanvasPanel* CanvasPanel_NpcCardDes; // 0x2d8(0x08)
	struct UCanvasPanel* CanvasPanel_Use; // 0x2e0(0x08)
	struct UImage* ItemBG; // 0x2e8(0x08)
	struct UWBP_NpcCardInfoWidget_C* WBP_NpcCardInfoWidget; // 0x2f0(0x08)
	struct UWBP_NpcCardInfoWidget_C* WBP_NpcCardInfoWidget_2; // 0x2f8(0x08)
	struct UWBP_NpcCardInfoWidget_C* WBP_NpcCardInfoWidget_3; // 0x300(0x08)
	struct UWBP_PropertyLine_C* WBP_PropertyLine; // 0x308(0x08)
	struct UWBP_PropertyLine_C* WBP_PropertyLine_2; // 0x310(0x08)
	struct UWBP_PropertyLine_C* WBP_PropertyLine_3; // 0x318(0x08)
	struct UWBP_PropertyLine_C* WBP_PropertyLine_4; // 0x320(0x08)
};

