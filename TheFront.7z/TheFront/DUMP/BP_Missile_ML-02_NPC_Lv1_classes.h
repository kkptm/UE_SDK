// BlueprintGeneratedClass BP_Missile_ML-02_NPC_Lv1.BP_Missile_ML-02_NPC_Lv1_C
// Size: 0x3a0 (Inherited: 0x390)
struct ABP_Missile_ML-02_NPC_Lv1_C : AUsMjfRg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct UNiagaraComponent* Niagara; // 0x398(0x08)

	void BPCall_MF2(); // Function BP_Missile_ML-02_NPC_Lv1.BP_Missile_ML-02_NPC_Lv1_C.BPCall_MF2 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_MF1(); // Function BP_Missile_ML-02_NPC_Lv1.BP_Missile_ML-02_NPC_Lv1_C.BPCall_MF1 // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Missile_ML-02_NPC_Lv1(int32_t EntryPoint); // Function BP_Missile_ML-02_NPC_Lv1.BP_Missile_ML-02_NPC_Lv1_C.ExecuteUbergraph_BP_Missile_ML-02_NPC_Lv1 // (Final|UbergraphFunction) // @ game+0x24b46a0
};

