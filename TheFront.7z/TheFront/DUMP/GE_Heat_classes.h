// BlueprintGeneratedClass GE_Heat.GE_Heat_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Heat_C : UGameplayEffect {
};

