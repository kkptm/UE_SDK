// BlueprintGeneratedClass Exe_StackTimeNoEffectDemo_Carrot.Exe_StackTimeNoEffectDemo_Carrot_C
// Size: 0x58 (Inherited: 0x58)
struct UExe_StackTimeNoEffectDemo_Carrot_C : UMSnOjVf {
};

