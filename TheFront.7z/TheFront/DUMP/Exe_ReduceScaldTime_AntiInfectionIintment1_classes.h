// BlueprintGeneratedClass Exe_ReduceScaldTime_AntiInfectionIintment1.Exe_ReduceScaldTime_AntiInfectionIintment1_C
// Size: 0x68 (Inherited: 0x68)
struct UExe_ReduceScaldTime_AntiInfectionIintment1_C : UnKoOipe {
};

