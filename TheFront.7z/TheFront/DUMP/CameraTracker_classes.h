// Class CameraTracker.mpeHsLf
// Size: 0x280 (Inherited: 0x260)
struct UmpeHsLf : UUserWidget {
	int32_t iKHesWf; // 0x260(0x04)
	char eKkJtne : 1; // 0x264(0x01)
	char kQjSRlf : 1; // 0x264(0x01)
	char pad_264_2 : 6; // 0x264(0x01)
	char pad_265[0x3]; // 0x265(0x03)
	struct TArray<struct FName> JOnVpIf; // 0x268(0x10)
	enum class ESlateVisibility hqJNsRe; // 0x278(0x01)
	char QNNQIVf : 1; // 0x279(0x01)
	char pad_279_1 : 7; // 0x279(0x01)
	bool pejUStg; // 0x27a(0x01)
	char pad_27B[0x5]; // 0x27b(0x05)

	struct UWidget* SikmWLh(struct FName& siqQVWf); // Function CameraTracker.mpeHsLf.SikmWLh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x1185ea0
	void ShowWithAnimation(); // Function CameraTracker.mpeHsLf.ShowWithAnimation // (Native|Public|BlueprintCallable) // @ game+0x1186620
	bool QWeiROe(); // Function CameraTracker.mpeHsLf.QWeiROe // (Final|Native|Public|BlueprintCallable) // @ game+0x1185f60
	void HideWithAnimation(); // Function CameraTracker.mpeHsLf.HideWithAnimation // (Native|Public|BlueprintCallable) // @ game+0x1185f40
	bool EscExit(); // Function CameraTracker.mpeHsLf.EscExit // (Native|Public) // @ game+0x1185e70
	void CustomAddToViewport(); // Function CameraTracker.mpeHsLf.CustomAddToViewport // (Native|Public|BlueprintCallable) // @ game+0x1185e50
	void CloseWithAnimation(); // Function CameraTracker.mpeHsLf.CloseWithAnimation // (Native|Public|BlueprintCallable) // @ game+0x1185e30
};

// Class CameraTracker.tPPQMVh
// Size: 0x298 (Inherited: 0x240)
struct AtPPQMVh : AActor {
	char pad_240[0x10]; // 0x240(0x10)
	float qpHjHre; // 0x250(0x04)
	char pad_254[0x14]; // 0x254(0x14)
	struct UpIKMtPe* jrQooQe; // 0x268(0x08)
	struct UpIKMtPe* MSeSfqh; // 0x270(0x08)
	struct TWeakObjectPtr<struct UpIKMtPe> pIKMtPe; // 0x278(0x08)
	struct TWeakObjectPtr<struct AOLJiNMg> rMmJPRh; // 0x280(0x08)
	struct FGuid WepjHIe; // 0x288(0x10)

	void KHMkOtf(); // Function CameraTracker.tPPQMVh.KHMkOtf // (Final|Native|Public) // @ game+0x1186250
};

// Class CameraTracker.OLJiNMg
// Size: 0x328 (Inherited: 0x2c8)
struct AOLJiNMg : ASpectatorPawn {
	struct USpringArmComponent* HKILWTg; // 0x2c8(0x08)
	struct UCameraComponent* qWipTVh; // 0x2d0(0x08)
	struct UCameraComponent* PNpOWfh; // 0x2d8(0x08)
	struct TArray<enum class EObjectTypeQuery> JlqHhLf; // 0x2e0(0x10)
	float OkinSUh; // 0x2f0(0x04)
	struct FVector HTHNkSe; // 0x2f4(0x0c)
	float qsmSRUf; // 0x300(0x04)
	bool PjiLrWh; // 0x304(0x01)
	char pad_305[0x7]; // 0x305(0x07)
	struct TWeakObjectPtr<struct APawn> NrPogHg; // 0x30c(0x08)
	struct TWeakObjectPtr<struct AtPPQMVh> VHWMPMh; // 0x314(0x08)
	struct TWeakObjectPtr<struct AActor> PgHmhig; // 0x31c(0x08)
	char pad_324[0x4]; // 0x324(0x04)

	void Server_Destroy(); // Function CameraTracker.OLJiNMg.Server_Destroy // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x1186600
	struct AActor* LiHtJIg(); // Function CameraTracker.OLJiNMg.LiHtJIg // (Final|Native|Public|BlueprintCallable) // @ game+0x11865d0
	void KjSRQgf(float qTLsHqg); // Function CameraTracker.OLJiNMg.KjSRQgf // (Final|Native|Public|BlueprintCallable) // @ game+0x1186550
	void JtJnhMg(struct APlayerController* TLPrRSg, struct FGuid& NjVHpMf); // Function CameraTracker.OLJiNMg.JtJnhMg // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1186640
	bool IOrUeof(); // Function CameraTracker.OLJiNMg.IOrUeof // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1185f90
	struct FHitResult BPCall_TraceTarget(struct AActor* JHTgKRf, struct FVector& shOUTVf, struct FVector& QjQjHMh, struct TArray<struct AActor*>& gWPKoNf); // Function CameraTracker.OLJiNMg.BPCall_TraceTarget // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x24b46a0
};

// Class CameraTracker.TpJQiMh
// Size: 0x4b0 (Inherited: 0x108)
struct UTpJQiMh : UWidget {
	struct FSlateBrush rigHSgf; // 0x108(0x88)
	struct FSlateBrush pipqTjg; // 0x190(0x88)
	float ilUKNHf; // 0x218(0x04)
	char pad_21C[0x4]; // 0x21c(0x04)
	struct FSlateBrush jVRrfgf; // 0x220(0x88)
	struct FVector2D OtHHRpg; // 0x2a8(0x08)
	struct FSlateBrush TogPPTh; // 0x2b0(0x88)
	struct FSlateBrush IeSHOof; // 0x338(0x88)
	struct FVector2D SgpkQih; // 0x3c0(0x08)
	struct FSlateBrush JtjLmNe; // 0x3c8(0x88)
	struct FMulticastInlineDelegate mnUHNLh; // 0x450(0x10)
	struct FMulticastInlineDelegate HsViUne; // 0x460(0x10)
	struct FMulticastInlineDelegate SIiQoNf; // 0x470(0x10)
	struct FMulticastInlineDelegate sMtftsh; // 0x480(0x10)
	char pad_490[0x20]; // 0x490(0x20)
};

// Class CameraTracker.qMkqhSh
// Size: 0x458 (Inherited: 0x260)
struct UqMkqhSh : UUserWidget {
	char pad_260[0x28]; // 0x260(0x28)
	struct FName VPLISUe; // 0x288(0x08)
	struct FName gNLWPoe; // 0x290(0x08)
	struct FName QKqqjQf; // 0x298(0x08)
	struct FSlateBrush NfeeSie; // 0x2a0(0x88)
	struct FSlateBrush eeWQLtg; // 0x328(0x88)
	struct FSlateBrush SUogfhe; // 0x3b0(0x88)
	char QtSsike : 1; // 0x438(0x01)
	char pad_438_1 : 7; // 0x438(0x01)
	char pad_439[0x1f]; // 0x439(0x1f)

	void keiepOg(struct FText& kUrNnfe, enum class ETextCommit lllTIMh); // Function CameraTracker.qMkqhSh.keiepOg // (Final|Native|Public|HasOutParms) // @ game+0x1186090
};

// Class CameraTracker.pIKMtPe
// Size: 0x3f8 (Inherited: 0x280)
struct UpIKMtPe : UmpeHsLf {
	char pad_280[0x88]; // 0x280(0x88)
	struct UButton* pOOfile; // 0x308(0x08)
	struct UCanvasPanel* SJVSJlg; // 0x310(0x08)
	struct UTextBlock* UhJIKog; // 0x318(0x08)
	struct AtPPQMVh* VHWMPMh; // 0x320(0x08)
	char pad_328[0x2c]; // 0x328(0x2c)
	struct FName IJNmiMf; // 0x354(0x08)
	struct FName PtHHpMf; // 0x35c(0x08)
	struct FName WkfUkig; // 0x364(0x08)
	struct FName mprfIlf; // 0x36c(0x08)
	struct FName hLTLNth; // 0x374(0x08)
	struct FName kqjOOqg; // 0x37c(0x08)
	struct FName teSOsoh; // 0x384(0x08)
	struct FName jWlOOof; // 0x38c(0x08)
	struct FName geqrPeh; // 0x394(0x08)
	struct FName RhrKnHg; // 0x39c(0x08)
	struct FName SenWRHf; // 0x3a4(0x08)
	struct FName IHTRsRf; // 0x3ac(0x08)
	struct FName NsUqifh; // 0x3b4(0x08)
	struct FName NmHjNkf; // 0x3bc(0x08)
	struct FName WheeVNe; // 0x3c4(0x08)
	struct FName iUQUsqg; // 0x3cc(0x08)
	struct FName MMPMOWh; // 0x3d4(0x08)
	char pad_3DC[0x4]; // 0x3dc(0x04)
	struct UqMkqhSh* rgitUne; // 0x3e0(0x08)
	char pad_3E8[0x10]; // 0x3e8(0x10)

	void UOUNLee(); // Function CameraTracker.pIKMtPe.UOUNLee // (Final|Native|Public) // @ game+0x11862b0
	void Toggle(); // Function CameraTracker.pIKMtPe.Toggle // (Native|Public|BlueprintCallable) // @ game+0x1186730
	void TKjNMoh(); // Function CameraTracker.pIKMtPe.TKjNMoh // (Final|Native|Public) // @ game+0x1186030
	void sMtftsh(); // Function CameraTracker.pIKMtPe.sMtftsh // (Final|Native|Public) // @ game+0x1186290
	void SIiQoNf(); // Function CameraTracker.pIKMtPe.SIiQoNf // (Final|Native|Public) // @ game+0x1186290
	void pslINLh(); // Function CameraTracker.pIKMtPe.pslINLh // (Final|Native|Public) // @ game+0x1186270
	struct FGuid Present(); // Function CameraTracker.pIKMtPe.Present // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x1186510
	void PNlINVh(struct FText& kUrNnfe, enum class ETextCommit lllTIMh); // Function CameraTracker.pIKMtPe.PNlINVh // (Final|Native|Public|HasOutParms) // @ game+0x11863f0
	void OMMNoie(); // Function CameraTracker.pIKMtPe.OMMNoie // (Final|Native|Public) // @ game+0x1185fd0
	void mnUHNLh(); // Function CameraTracker.pIKMtPe.mnUHNLh // (Final|Native|Public) // @ game+0x11861b0
	void mhliPRe(); // Function CameraTracker.pIKMtPe.mhliPRe // (Final|Native|Public) // @ game+0x1186010
	void lOiVNlg(); // Function CameraTracker.pIKMtPe.lOiVNlg // (Final|Native|Public) // @ game+0x1186070
	void LnPnHMf(); // Function CameraTracker.pIKMtPe.LnPnHMf // (Final|Native|Public) // @ game+0x1185ff0
	void lIUeKlh(); // Function CameraTracker.pIKMtPe.lIUeKlh // (Final|Native|Public) // @ game+0x11861d0
	void jjooHpe(); // Function CameraTracker.pIKMtPe.jjooHpe // (Final|Native|Public) // @ game+0x1186210
	void jeoKSVh(); // Function CameraTracker.pIKMtPe.jeoKSVh // (Final|Native|Public) // @ game+0x11861f0
	void ItsJeUe(); // Function CameraTracker.pIKMtPe.ItsJeUe // (Final|Native|Public) // @ game+0x1186050
	void hTfsTie(); // Function CameraTracker.pIKMtPe.hTfsTie // (Final|Native|Public) // @ game+0x1186230
	void gslRTqf(struct FText& kUrNnfe, enum class ETextCommit lllTIMh); // Function CameraTracker.pIKMtPe.gslRTqf // (Final|Native|Public|HasOutParms) // @ game+0x11862d0
};

