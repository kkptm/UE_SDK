// UserDefinedEnum UDS_TemperatureType.UDS_TemperatureType
enum class UDS_TemperatureType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	UDS_MAX = 2
};

