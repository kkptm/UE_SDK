// BlueprintGeneratedClass BP_human_Knife_Refugee_9.BP_human_Knife_Refugee_8_C
// Size: 0x1518 (Inherited: 0x1518)
struct ABP_human_Knife_Refugee_8_C : ABP_human_Knife_C {
};

