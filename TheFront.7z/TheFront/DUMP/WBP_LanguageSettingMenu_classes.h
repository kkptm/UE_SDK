// WidgetBlueprintGeneratedClass WBP_LanguageSettingMenu.WBP_LanguageSettingMenu_C
// Size: 0x340 (Inherited: 0x320)
struct UWBP_LanguageSettingMenu_C : UhIWNsVg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct UImage* Image_74; // 0x328(0x08)
	struct FMulticastInlineDelegate LanguageSelected; // 0x330(0x10)

	void PreConstruct(bool IsDesignTime); // Function WBP_LanguageSettingMenu.WBP_LanguageSettingMenu_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_LanguageSettingMenu(int32_t EntryPoint); // Function WBP_LanguageSettingMenu.WBP_LanguageSettingMenu_C.ExecuteUbergraph_WBP_LanguageSettingMenu // (Final|UbergraphFunction) // @ game+0x24b46a0
	void LanguageSelected__DelegateSignature(); // Function WBP_LanguageSettingMenu.WBP_LanguageSettingMenu_C.LanguageSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

