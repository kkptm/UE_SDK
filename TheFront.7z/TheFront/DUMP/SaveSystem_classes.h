// Class SaveSystem.sOPgIJf
// Size: 0x88 (Inherited: 0x30)
struct UsOPgIJf : UGameInstanceSubsystem {
	char pad_30[0x58]; // 0x30(0x58)
};

// Class SaveSystem.UtthHHe
// Size: 0x28 (Inherited: 0x28)
struct UUtthHHe : UInterface {

	void OnPreSave(); // Function SaveSystem.UtthHHe.OnPreSave // (Native|Event|Public|BlueprintEvent) // @ game+0x125d590
	void OnPreLoad(); // Function SaveSystem.UtthHHe.OnPreLoad // (Native|Event|Public|BlueprintEvent) // @ game+0x125d570
	void OnPostSave(); // Function SaveSystem.UtthHHe.OnPostSave // (Native|Event|Public|BlueprintEvent) // @ game+0x125d550
	void OnPostLoad(); // Function SaveSystem.UtthHHe.OnPostLoad // (Native|Event|Public|BlueprintEvent) // @ game+0x125d530
};

