// WidgetBlueprintGeneratedClass WBP_ItemDesc.WBP_ItemDesc_C
// Size: 0x480 (Inherited: 0x408)
struct UWBP_ItemDesc_C : UhRgpKWg {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x408(0x08)
	struct USrQNosh* Button_Drop; // 0x410(0x08)
	struct USrQNosh* Button_Use; // 0x418(0x08)
	struct UCanvasPanel* CanvasPanel_ItemPropertyList; // 0x420(0x08)
	struct UScrollBox* ScrollBox_Items; // 0x428(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton; // 0x430(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_1; // 0x438(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_2; // 0x440(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_3; // 0x448(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_4; // 0x450(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_5; // 0x458(0x08)
	struct UWBP_ItemBlackPanel_C* WBP_ItemBlackPanel; // 0x460(0x08)
	struct UWBP_NpcCardDes_C* WBP_NpcCardDes; // 0x468(0x08)
	struct UWBP_RecipeDes_C* WBP_RecipeDes; // 0x470(0x08)
	bool IsRepairing; // 0x478(0x01)
	char pad_479[0x3]; // 0x479(0x03)
	int32_t LeftTime; // 0x47c(0x04)

	void ShowProperties(); // Function WBP_ItemDesc.WBP_ItemDesc_C.ShowProperties // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Init(); // Function WBP_ItemDesc.WBP_ItemDesc_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BPCall_UpdateItemProperties(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BPCall_UpdateItemProperties // (BlueprintEvent) // @ game+0x24b46a0
	void BPCall_IP1(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BPCall_IP1 // (Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_ItemDesc.WBP_ItemDesc_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ItemDesc_Button_Repair_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BndEvt__WBP_ItemDesc_Button_Repair_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ItemDesc_Button_Drop_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BndEvt__WBP_ItemDesc_Button_Drop_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void CustomEvent_1(struct UokpsjLh* ItemButton); // Function WBP_ItemDesc.WBP_ItemDesc_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void CustomEvent_2(); // Function WBP_ItemDesc.WBP_ItemDesc_C.CustomEvent_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ItemDesc_Button_Use_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BndEvt__WBP_ItemDesc_Button_Use_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void CustomEvent_3(struct UokpsjLh* ItemButton); // Function WBP_ItemDesc.WBP_ItemDesc_C.CustomEvent_3 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void  ��  _1(struct UokpsjLh* ItemButton); // Function WBP_ItemDesc.WBP_ItemDesc_C. ��  _1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ItemDesc_Button_Make_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ItemDesc.WBP_ItemDesc_C.BndEvt__WBP_ItemDesc_Button_Make_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ItemDesc(int32_t EntryPoint); // Function WBP_ItemDesc.WBP_ItemDesc_C.ExecuteUbergraph_WBP_ItemDesc // (Final|UbergraphFunction) // @ game+0x24b46a0
};

