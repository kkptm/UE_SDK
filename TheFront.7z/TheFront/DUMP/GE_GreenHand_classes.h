// BlueprintGeneratedClass GE_GreenHand.GE_GreenHand_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_GreenHand_C : UGameplayEffect {
};

