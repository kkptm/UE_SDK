// BlueprintGeneratedClass BP_human.BP_human_C
// Size: 0x1510 (Inherited: 0x1508)
struct ABP_human_C : ABP_human_common_collar_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1508(0x08)
};

