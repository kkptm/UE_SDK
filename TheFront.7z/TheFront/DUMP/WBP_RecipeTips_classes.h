// WidgetBlueprintGeneratedClass WBP_RecipeTips.WBP_RecipeTips_C
// Size: 0x410 (Inherited: 0x3f8)
struct UWBP_RecipeTips_C : ULIIRoHe {
	struct UImage* Image; // 0x3f8(0x08)
	struct UImage* Image_103; // 0x400(0x08)
	struct UImage* Image_168; // 0x408(0x08)
};

