// WidgetBlueprintGeneratedClass WBP_DirPoint.WBP_DirPoint_C
// Size: 0x3c0 (Inherited: 0x3b0)
struct UWBP_DirPoint_C : UJmJqmSf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b0(0x08)
	struct UImage* Image; // 0x3b8(0x08)

	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DirPoint.WBP_DirPoint_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_DirPoint(int32_t EntryPoint); // Function WBP_DirPoint.WBP_DirPoint_C.ExecuteUbergraph_WBP_DirPoint // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

