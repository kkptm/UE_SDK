// BlueprintGeneratedClass BP_human_Unarmed_Refugee_5.BP_human_Unarmed_Refugee_4_C
// Size: 0x1510 (Inherited: 0x1510)
struct ABP_human_Unarmed_Refugee_4_C : ABP_human_C {
};

