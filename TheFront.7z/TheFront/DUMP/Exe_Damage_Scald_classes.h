// BlueprintGeneratedClass Exe_Damage_Scald.Exe_Damage_Scald_C
// Size: 0x60 (Inherited: 0x60)
struct UExe_Damage_Scald_C : UnsnKLth {
};

