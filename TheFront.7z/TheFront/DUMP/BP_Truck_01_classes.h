// BlueprintGeneratedClass BP_Truck_01.BP_Truck_01_C
// Size: 0xfb8 (Inherited: 0xfb8)
struct ABP_Truck_01_C : ABP_WheelPawn_C {

	void UserConstructionScript(); // Function BP_Truck_01.BP_Truck_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

