// WidgetBlueprintGeneratedClass WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C
// Size: 0x5c8 (Inherited: 0x2e8)
struct UWBP_Inventory_AvatarPannel_C : UjULkOUf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)
	struct UImage* BG; // 0x2f0(0x08)
	struct USrQNosh* Button_Move; // 0x2f8(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton; // 0x300(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_2; // 0x308(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_3; // 0x310(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_4; // 0x318(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_5; // 0x320(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_6; // 0x328(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_7; // 0x330(0x08)
	struct UWBP_InventoryItemButton_C* WBP_InventoryItemButton_8; // 0x338(0x08)
	struct UWrapBox* WrapBox_Item; // 0x340(0x08)
	struct FButtonStyle ButtonStyle; // 0x348(0x278)
	struct UTexture2D* SelImage; // 0x5c0(0x08)

	void WBP_Inventory_AvatarPannel_AutoGenFunc(struct UokpsjLh* ItemButton); // Function WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C.WBP_Inventory_AvatarPannel_AutoGenFunc // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Init(); // Function WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_Inventory_AvatarPannel_Button_Move_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C.BndEvt__WBP_Inventory_AvatarPannel_Button_Move_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_Inventory_AvatarPannel(int32_t EntryPoint); // Function WBP_Inventory_AvatarPannel.WBP_Inventory_AvatarPannel_C.ExecuteUbergraph_WBP_Inventory_AvatarPannel // (Final|UbergraphFunction) // @ game+0x24b46a0
};

