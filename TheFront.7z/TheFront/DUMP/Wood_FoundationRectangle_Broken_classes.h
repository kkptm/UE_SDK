// BlueprintGeneratedClass Wood_FoundationRectangle_Broken.Wood_FoundationRectangle_Broken_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct AWood_FoundationRectangle_Broken_C : AConstructGeometryCollectionActor {
};

