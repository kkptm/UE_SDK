// BlueprintGeneratedClass BP_Heavy_Axe_Bearer.BP_Heavy_Axe_Bearer_C
// Size: 0x1510 (Inherited: 0x1500)
struct ABP_Heavy_Axe_Bearer_C : ABP_human_common_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1500(0x08)
	struct USkeletalMeshComponent* SK_NPC_Heavy_Axe_Bearer_Weapon; // 0x1508(0x08)
};

