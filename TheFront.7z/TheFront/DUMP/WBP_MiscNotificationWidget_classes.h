// WidgetBlueprintGeneratedClass WBP_MiscNotificationWidget.WBP_MiscNotificationWidget_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct UWBP_MiscNotificationWidget_C : UoVsgJgh {
};

