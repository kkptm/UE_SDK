// WidgetBlueprintGeneratedClass FormTrusteeItemBP.FormTrusteeItemBP_C
// Size: 0x298 (Inherited: 0x298)
struct UFormTrusteeItemBP_C : UOJnoMme {
};

