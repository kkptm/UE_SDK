// AnimBlueprintGeneratedClass ABP_Boss_Weapon.ABP_Boss_Weapon_C
// Size: 0x4f0 (Inherited: 0x310)
struct UABP_Boss_Weapon_C : UjlfogLh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x318(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x348(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x3c8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x3f8(0xb0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x4a8(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Boss_Weapon.ABP_Boss_Weapon_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ABP_Boss_Weapon(int32_t EntryPoint); // Function ABP_Boss_Weapon.ABP_Boss_Weapon_C.ExecuteUbergraph_ABP_Boss_Weapon // (Final|UbergraphFunction) // @ game+0x24b46a0
};

