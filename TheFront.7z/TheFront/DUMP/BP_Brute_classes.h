// BlueprintGeneratedClass BP_Brute.BP_Brute_C
// Size: 0x1508 (Inherited: 0x1500)
struct ABP_Brute_C : ABP_human_common_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1500(0x08)
};

