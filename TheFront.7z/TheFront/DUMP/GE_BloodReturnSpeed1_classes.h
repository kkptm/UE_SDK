// BlueprintGeneratedClass GE_BloodReturnSpeed1.GE_BloodReturnSpeed1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_BloodReturnSpeed1_C : UGameplayEffect {
};

