// BlueprintGeneratedClass BP_Tank_Gun_CameraShakeTank04.BP_Tank_Gun_CameraShakeTank04_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UBP_Tank_Gun_CameraShakeTank04_C : UMatineeCameraShake {
};

