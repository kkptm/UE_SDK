// WidgetBlueprintGeneratedClass WBP_NpcStateWidget.WBP_NpcStateWidget_C
// Size: 0x2b0 (Inherited: 0x2b0)
struct UWBP_NpcStateWidget_C : UNrtjHNf {
};

