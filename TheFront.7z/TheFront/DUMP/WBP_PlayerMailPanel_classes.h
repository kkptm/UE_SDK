// WidgetBlueprintGeneratedClass WBP_PlayerMailPanel.WBP_PlayerMailPanel_C
// Size: 0x3a8 (Inherited: 0x318)
struct UWBP_PlayerMailPanel_C : UqQVUJee {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UImage* BG_2; // 0x320(0x08)
	struct UImage* Esc; // 0x328(0x08)
	struct UImage* Esc_2; // 0x330(0x08)
	struct UImage* Image; // 0x338(0x08)
	struct UImage* Image_2; // 0x340(0x08)
	struct UImage* Image_3; // 0x348(0x08)
	struct UImage* Image_4; // 0x350(0x08)
	struct UImage* Image_5; // 0x358(0x08)
	struct UImage* Image_6; // 0x360(0x08)
	struct UImage* Image_7; // 0x368(0x08)
	struct UImage* Image_8; // 0x370(0x08)
	struct UImage* Image_9; // 0x378(0x08)
	struct UImage* Image_10; // 0x380(0x08)
	struct UImage* Image_11; // 0x388(0x08)
	struct UImage* Image_12; // 0x390(0x08)
	struct UImage* Image_112; // 0x398(0x08)
	struct UImage* Image_292; // 0x3a0(0x08)

	void BndEvt__WBP_PlayerMailPanel_Button_DeleteOne_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_PlayerMailPanel.WBP_PlayerMailPanel_C.BndEvt__WBP_PlayerMailPanel_Button_DeleteOne_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_PlayerMailPanel_Button_ExtractOne_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_PlayerMailPanel.WBP_PlayerMailPanel_C.BndEvt__WBP_PlayerMailPanel_Button_ExtractOne_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_PlayerMailPanel_Button_DeleteAll_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_PlayerMailPanel.WBP_PlayerMailPanel_C.BndEvt__WBP_PlayerMailPanel_Button_DeleteAll_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_PlayerMailPanel_Button_ExtractAll_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function WBP_PlayerMailPanel.WBP_PlayerMailPanel_C.BndEvt__WBP_PlayerMailPanel_Button_ExtractAll_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PlayerMailPanel(int32_t EntryPoint); // Function WBP_PlayerMailPanel.WBP_PlayerMailPanel_C.ExecuteUbergraph_WBP_PlayerMailPanel // (Final|UbergraphFunction) // @ game+0x24b46a0
};

