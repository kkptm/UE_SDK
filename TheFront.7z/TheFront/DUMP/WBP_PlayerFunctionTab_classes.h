// WidgetBlueprintGeneratedClass WBP_PlayerFunctionTab.WBP_PlayerFunctionTab_C
// Size: 0x420 (Inherited: 0x308)
struct UWBP_PlayerFunctionTab_C : UeMUQSJe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x308(0x08)
	struct UWidgetAnimation* FunctionTabAnim; // 0x310(0x08)
	struct UCanvasPanel* CanvasPanel_TabSel; // 0x318(0x08)
	struct UImage* Image_36; // 0x320(0x08)
	struct UnlRqLnf* RBtn_Guild; // 0x328(0x08)
	struct UnlRqLnf* RBtn_Inventory; // 0x330(0x08)
	struct UnlRqLnf* RBtn_Mail; // 0x338(0x08)
	struct UnlRqLnf* RBtn_Map; // 0x340(0x08)
	struct UnlRqLnf* RBtn_Recipe; // 0x348(0x08)
	struct UnlRqLnf* RBtn_Talent; // 0x350(0x08)
	struct UnlRqLnf* RBtn_Task; // 0x358(0x08)
	struct UnlRqLnf* RBtn_Tech; // 0x360(0x08)
	struct UnlRqLnf* RBtn_Wiki; // 0x368(0x08)
	struct UWBP_PlayerInventory_C* WBP_PlayerInventory; // 0x370(0x08)
	struct UWBP_PlayerMailPanel_C* WBP_PlayerMail; // 0x378(0x08)
	struct UWBP_PlayerTask_C* WBP_PlayerTask; // 0x380(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleIGuild; // 0x388(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleIMail; // 0x390(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleIMap; // 0x398(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleInventory; // 0x3a0(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleInventoryTalent; // 0x3a8(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleIRecipe; // 0x3b0(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleITask; // 0x3b8(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleITech; // 0x3c0(0x08)
	struct UWBP_FunctionTabScaleItemTemp_C* WBP_ScaleIWiki; // 0x3c8(0x08)
	struct UWBP_FunctionTab_C* WBP_TabInventory; // 0x3d0(0x08)
	struct UWBP_FunctionTab_C* WBP_TabMap; // 0x3d8(0x08)
	struct UWBP_FunctionTab_C* WBP_TabRecipe; // 0x3e0(0x08)
	struct UWBP_FunctionTab_C* WBP_TabRecipeUnlock; // 0x3e8(0x08)
	struct UWBP_FunctionTab_C* WBP_TabTalent; // 0x3f0(0x08)
	struct UWBP_FunctionTab_C* WBP_TabTask; // 0x3f8(0x08)
	struct UWBP_TalentMainWidget_C* WBP_TalentMainWidget; // 0x400(0x08)
	struct UWBP_Wiki_C* WBP_Wiki; // 0x408(0x08)
	struct UWBP_WorldMap_C* WBP_WorldMap; // 0x410(0x08)
	struct UWBP_PlayerInventory_C* WBP Player Inventory; // 0x418(0x08)

	void Construct(); // Function WBP_PlayerFunctionTab.WBP_PlayerFunctionTab_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_PlayerFunctionTab_RadioPanel_Func_K2Node_ComponentBoundEvent_0_OnRadioStateChanged__DelegateSignature(struct UnlRqLnf* Button, int32_t Index, struct UnlRqLnf* OldButton, int32_t OldIndex); // Function WBP_PlayerFunctionTab.WBP_PlayerFunctionTab_C.BndEvt__WBP_PlayerFunctionTab_RadioPanel_Func_K2Node_ComponentBoundEvent_0_OnRadioStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_PlayerFunctionTab(int32_t EntryPoint); // Function WBP_PlayerFunctionTab.WBP_PlayerFunctionTab_C.ExecuteUbergraph_WBP_PlayerFunctionTab // (Final|UbergraphFunction) // @ game+0x24b46a0
};

