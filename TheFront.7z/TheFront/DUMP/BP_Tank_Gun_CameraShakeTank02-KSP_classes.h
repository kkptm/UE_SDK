// BlueprintGeneratedClass BP_Tank_Gun_CameraShakeTank02-KSP.BP_Tank_Gun_CameraShakeTank02-KSP_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UBP_Tank_Gun_CameraShakeTank02-KSP_C : UMatineeCameraShake {
};

