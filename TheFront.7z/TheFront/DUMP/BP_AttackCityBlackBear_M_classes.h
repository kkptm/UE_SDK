// BlueprintGeneratedClass BP_AttackCityBlackBear_M.BP_AttackCityBlackBear_M_C
// Size: 0x14f8 (Inherited: 0x14e0)
struct ABP_AttackCityBlackBear_M_C : AqjpNNMe {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x14e0(0x08)
	struct UStaticMeshComponent* NPC_BlackBear_collar; // 0x14e8(0x08)
	struct UrfnLLpg* Ak_HItSound; // 0x14f0(0x08)

	void BPCall_F2(struct FHitResult& P1, struct UtriMsng* P2, enum class EAmmoHitResult P3); // Function BP_AttackCityBlackBear_M.BP_AttackCityBlackBear_M_C.BPCall_F2 // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_AttackCityBlackBear_M(int32_t EntryPoint); // Function BP_AttackCityBlackBear_M.BP_AttackCityBlackBear_M_C.ExecuteUbergraph_BP_AttackCityBlackBear_M // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

