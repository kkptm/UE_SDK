// BlueprintGeneratedClass GE_SpicyRoastMeat1.GE_SpicyRoastMeat1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_SpicyRoastMeat1_C : UGameplayEffect {
};

