// BlueprintGeneratedClass BP_Test_PlayerCharacter_Game.BP_Test_PlayerCharacter_Game_C
// Size: 0x17f4 (Inherited: 0x17d8)
struct ABP_Test_PlayerCharacter_Game_C : ABP_PlayerCharacter_Game_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x17d8(0x08)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource; // 0x17e0(0x08)
	struct FVector Line Start; // 0x17e8(0x0c)

	void ReceiveBeginPlay(); // Function BP_Test_PlayerCharacter_Game.BP_Test_PlayerCharacter_Game_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void ReceiveFoundInteractableObject(struct FVector Location); // Function BP_Test_PlayerCharacter_Game.BP_Test_PlayerCharacter_Game_C.ReceiveFoundInteractableObject // (BlueprintEvent) // @ game+0x24b46a0
	void Server_TraceResource(); // Function BP_Test_PlayerCharacter_Game.BP_Test_PlayerCharacter_Game_C.Server_TraceResource // (Net|NetServer|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_BP_Test_PlayerCharacter_Game(int32_t EntryPoint); // Function BP_Test_PlayerCharacter_Game.BP_Test_PlayerCharacter_Game_C.ExecuteUbergraph_BP_Test_PlayerCharacter_Game // (Final|UbergraphFunction|HasDefaults) // @ game+0x24b46a0
};

