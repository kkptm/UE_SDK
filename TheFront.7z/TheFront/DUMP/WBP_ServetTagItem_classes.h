// WidgetBlueprintGeneratedClass WBP_ServetTagItem.WBP_ServetTagItem_C
// Size: 0x290 (Inherited: 0x260)
struct UWBP_ServetTagItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCheckBox* CheckBox_1; // 0x268(0x08)
	struct UImage* Image_46; // 0x270(0x08)
	struct UTextBlock* TextBlock_1; // 0x278(0x08)
	struct UBP_ServerTagInfo_C* TagInfo; // 0x280(0x08)
	struct UWBP_Set_ServerSetting_C* MainForm; // 0x288(0x08)

	void UpdateView(struct UBP_ServerTagInfo_C* TagInfo); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.UpdateView // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void InitItem(struct UWBP_Set_ServerSetting_C* MainForm); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.InitItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UpdataChoose(bool Condition); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.UpdataChoose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BP_OnEntryReleased(); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__WBP_ServetTagItem_CheckBox_0_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.BndEvt__WBP_ServetTagItem_CheckBox_0_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_ServetTagItem(int32_t EntryPoint); // Function WBP_ServetTagItem.WBP_ServetTagItem_C.ExecuteUbergraph_WBP_ServetTagItem // (Final|UbergraphFunction) // @ game+0x24b46a0
};

