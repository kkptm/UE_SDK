// WidgetBlueprintGeneratedClass WBP_SystemNotification.WBP_SystemNotification_C
// Size: 0x290 (Inherited: 0x288)
struct UWBP_SystemNotification_C : UNIinqRe {
	struct UImage* Image_32; // 0x288(0x08)
};

