// BlueprintGeneratedClass BP_BearController.BP_BearController_C
// Size: 0x888 (Inherited: 0x880)
struct ABP_BearController_C : ALofnROg {
	struct AActor* PerceptionActor; // 0x880(0x08)
};

