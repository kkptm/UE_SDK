// Class GameHostList.qrUtHTe
// Size: 0xd8 (Inherited: 0x28)
struct UqrUtHTe : UObject {
	char pad_28[0xb0]; // 0x28(0xb0)
};

// Class GameHostList.nlmsINh
// Size: 0x50 (Inherited: 0x30)
struct UnlmsINh : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate lnWKsrg; // 0x30(0x10)
	struct FMulticastInlineDelegate KVKRppe; // 0x40(0x10)

	struct UnlmsINh* QNpnlig(struct UObject* QIekWUh, int32_t ehONSqf, enum class EGameServerType TnsOsfe, enum class EGameServerOwner ghtKlhg); // Function GameHostList.nlmsINh.QNpnlig // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x115e0e0
	void AsyncNodeResult__DelegateSignature(struct TArray<struct FNiWItIh>& ResultServerList); // DelegateFunction GameHostList.nlmsINh.AsyncNodeResult__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x24b46a0
};

// Class GameHostList.LHQJiOf
// Size: 0x50 (Inherited: 0x30)
struct ULHQJiOf : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate nMJVRlf; // 0x30(0x10)
	struct FMulticastInlineDelegate qlpqesg; // 0x40(0x10)

	struct ULHQJiOf* WqpnRSh(struct UObject* QIekWUh, struct FString OTJTIqe, int32_t rLeOpJf, float jrRPfkg); // Function GameHostList.LHQJiOf.WqpnRSh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x115e230
	void AsyncNodeResult__DelegateSignature(float PingInMS); // DelegateFunction GameHostList.LHQJiOf.AsyncNodeResult__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24b46a0
};

// Class GameHostList.nMRSlWf
// Size: 0x28 (Inherited: 0x28)
struct UnMRSlWf : UBlueprintFunctionLibrary {

	bool LofLRig(struct AGameModeBase* lPJJoNh, struct FNiWItIh& UfHPVIe, float LOSopjh); // Function GameHostList.nMRSlWf.LofLRig // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x115e390
};

