// UserDefinedStruct PingInMsColor.PingInMsColor
// Size: 0x58 (Inherited: 0x00)
struct FPingInMsColor {
	int32_t Range_3_541BCEC04B5E0328BCEA248AFC2A8C96; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FSlateColor Color_6_62613F714AF22F4F644A7C8B701C1040; // 0x08(0x28)
	struct FText Desc_10_1FD950234410AF5853D17F8F4ECC21EF; // 0x30(0x18)
	struct FString PingInMs_13_011703B34580395C4A5A21B07A2491FB; // 0x48(0x10)
};

