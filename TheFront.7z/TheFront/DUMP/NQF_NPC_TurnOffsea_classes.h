// BlueprintGeneratedClass NQF_NPC_TurnOffsea.NQF_NPC_TurnOffsea_C
// Size: 0x58 (Inherited: 0x58)
struct UNQF_NPC_TurnOffsea_C : UrhoRmKg {
};

