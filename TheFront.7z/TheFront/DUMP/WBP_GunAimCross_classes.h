// WidgetBlueprintGeneratedClass WBP_GunAimCross.WBP_GunAimCross_C
// Size: 0x278 (Inherited: 0x260)
struct UWBP_GunAimCross_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* HitAnimation; // 0x268(0x08)
	struct UCanvasPanel* HitCross; // 0x270(0x08)

	void BeginShow(struct FVector2D Coord); // Function WBP_GunAimCross.WBP_GunAimCross_C.BeginShow // (BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_GunAimCross(int32_t EntryPoint); // Function WBP_GunAimCross.WBP_GunAimCross_C.ExecuteUbergraph_WBP_GunAimCross // (Final|UbergraphFunction) // @ game+0x24b46a0
};

