// WidgetBlueprintGeneratedClass FormCableInfoBP.FormCableInfoBP_C
// Size: 0x278 (Inherited: 0x270)
struct UFormCableInfoBP_C : UIPJHMof {
	struct UImage* Image_130; // 0x270(0x08)
};

