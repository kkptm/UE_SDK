// BlueprintGeneratedClass BP_Pickup_01.BP_Pickup_01_C
// Size: 0xfc0 (Inherited: 0xfb8)
struct ABP_Pickup_01_C : ABP_WheelPawn_C {
	struct UMaterialInstanceDynamic* LightMatIns; // 0xfb8(0x08)

	void UserConstructionScript(); // Function BP_Pickup_01.BP_Pickup_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

