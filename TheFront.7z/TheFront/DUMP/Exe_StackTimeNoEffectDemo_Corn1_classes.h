// BlueprintGeneratedClass Exe_StackTimeNoEffectDemo_Corn1.Exe_StackTimeNoEffectDemo_Corn1_C
// Size: 0x58 (Inherited: 0x58)
struct UExe_StackTimeNoEffectDemo_Corn1_C : UMSnOjVf {
};

