// WidgetBlueprintGeneratedClass WBP_StreamerSettingMenu.WBP_StreamerSettingMenu_C
// Size: 0x2a0 (Inherited: 0x298)
struct UWBP_StreamerSettingMenu_C : UgheKlHg {
	struct UWBP_BoolSelectorTemplate_C* BoolSel_EnableFilter; // 0x298(0x08)
};

