// BlueprintGeneratedClass BP_human_Gun01.BP_human_Gun01_C
// Size: 0x1518 (Inherited: 0x1508)
struct ABP_human_Gun01_C : ABP_human_common_collar_C {
	struct UWidgetComponent* WidgetNameTag; // 0x1508(0x08)
	struct USkeletalMeshComponent* SK_M1911; // 0x1510(0x08)
};

