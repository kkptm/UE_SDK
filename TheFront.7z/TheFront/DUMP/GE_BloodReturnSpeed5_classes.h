// BlueprintGeneratedClass GE_BloodReturnSpeed5.GE_BloodReturnSpeed5_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_BloodReturnSpeed5_C : UGameplayEffect {
};

