// BlueprintGeneratedClass GE_AntiRadiationOintment1.GE_AntiRadiationOintment1_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AntiRadiationOintment1_C : UGameplayEffect {
};

