// BlueprintGeneratedClass BP_DeadSpectator.BP_DeadSpectator_C
// Size: 0x2c0 (Inherited: 0x2a8)
struct ABP_DeadSpectator_C : AInlpjIg {
	struct UCineCameraComponent* CineCamera; // 0x2a8(0x08)
	struct USpringArmComponent* SpringArm; // 0x2b0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2b8(0x08)
};

