// BlueprintGeneratedClass GE_Tired.GE_Tired_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Tired_C : UGameplayEffect {
};

