// BlueprintGeneratedClass BP_CougarController.BP_CougarController_C
// Size: 0x890 (Inherited: 0x880)
struct ABP_CougarController_C : ALofnROg {
	struct UAIPerceptionComponent* AIPerception; // 0x880(0x08)
	struct AActor* PerceptionActor; // 0x888(0x08)
};

