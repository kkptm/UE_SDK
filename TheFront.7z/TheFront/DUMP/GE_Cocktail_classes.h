// BlueprintGeneratedClass GE_Cocktail.GE_Cocktail_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Cocktail_C : UGameplayEffect {
};

