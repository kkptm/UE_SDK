// Class EnhancedWidget.EnhancedWidgetSettings
// Size: 0x68 (Inherited: 0x38)
struct UEnhancedWidgetSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UDataTable> FilterTable; // 0x38(0x28)
	float ClickTimeout; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class EnhancedWidget.NrmOUkg
// Size: 0x28 (Inherited: 0x28)
struct UNrmOUkg : UBlueprintFunctionLibrary {

	bool ShNrfWf(struct FText& JtJogrh, struct FText& tmVjSnf); // Function EnhancedWidget.NrmOUkg.ShNrfWf // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x125ca20
	bool hTgWNTf(struct FString& TjoLSQe); // Function EnhancedWidget.NrmOUkg.hTgWNTf // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x125cb90
	bool hjoQPVg(struct FString TjoLSQe); // Function EnhancedWidget.NrmOUkg.hjoQPVg // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x125cc40
};

// Class EnhancedWidget.nnoVqkh
// Size: 0x480 (Inherited: 0x460)
struct UnnoVqkh : UEditableText {
	bool gIWPntf; // 0x460(0x01)
	char pad_461[0x1f]; // 0x461(0x1f)

	void KSKStUg(struct FText& LtJlUhg, enum class ETextCommit lllTIMh); // Function EnhancedWidget.nnoVqkh.KSKStUg // (Final|Native|Protected|HasOutParms) // @ game+0x125cd80
	void jmoPoMh(); // Function EnhancedWidget.nnoVqkh.jmoPoMh // (Final|Native|Protected|BlueprintCallable) // @ game+0x125cce0
	void fRrmTVe(); // Function EnhancedWidget.nnoVqkh.fRrmTVe // (Final|Native|Protected) // @ game+0x125cd20
};

// Class EnhancedWidget.oUoqUSg
// Size: 0xa68 (Inherited: 0xa38)
struct UoUoqUSg : UEditableTextBox {
	bool gIWPntf; // 0xa38(0x01)
	char pad_A39[0x7]; // 0xa39(0x07)
	struct FMulticastInlineDelegate OiKkWNg; // 0xa40(0x10)
	char pad_A50[0x18]; // 0xa50(0x18)

	void fRrmTVe(); // Function EnhancedWidget.oUoqUSg.fRrmTVe // (Final|Native|Protected) // @ game+0x125cd40
};

// Class EnhancedWidget.KsUpWQf
// Size: 0xcc8 (Inherited: 0xc98)
struct UKsUpWQf : UMultiLineEditableTextBox {
	bool gIWPntf; // 0xc98(0x01)
	char pad_C99[0x7]; // 0xc99(0x07)
	struct FMulticastInlineDelegate OiKkWNg; // 0xca0(0x10)
	char pad_CB0[0x18]; // 0xcb0(0x18)

	void KSKStUg(struct FText& LtJlUhg, enum class ETextCommit lllTIMh); // Function EnhancedWidget.KsUpWQf.KSKStUg // (Final|Native|Protected|HasOutParms) // @ game+0x125cea0
	void jmoPoMh(); // Function EnhancedWidget.KsUpWQf.jmoPoMh // (Final|Native|Protected|BlueprintCallable) // @ game+0x125cd00
	void fRrmTVe(); // Function EnhancedWidget.KsUpWQf.fRrmTVe // (Final|Native|Protected) // @ game+0x125cd60
};

// Class EnhancedWidget.RJLRfqh
// Size: 0x438 (Inherited: 0x428)
struct URJLRfqh : UButton {
	float SRUVspf; // 0x428(0x04)
	char pad_42C[0xc]; // 0x42c(0x0c)
};

