// WidgetBlueprintGeneratedClass WBP_CustomSliderTemplate.WBP_CustomSliderTemplate_C
// Size: 0x2f0 (Inherited: 0x2e0)
struct UWBP_CustomSliderTemplate_C : UsLleQqf {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)
	struct UImage* Image_86; // 0x2e8(0x08)

	void PreConstruct(bool IsDesignTime); // Function WBP_CustomSliderTemplate.WBP_CustomSliderTemplate_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_WBP_CustomSliderTemplate(int32_t EntryPoint); // Function WBP_CustomSliderTemplate.WBP_CustomSliderTemplate_C.ExecuteUbergraph_WBP_CustomSliderTemplate // (Final|UbergraphFunction) // @ game+0x24b46a0
};

