// BlueprintGeneratedClass BP_Armored_01.BP_Armored_01_C
// Size: 0xfc8 (Inherited: 0xfb8)
struct ABP_Armored_01_C : ABP_WheelPawn_C {
	struct UNiagaraComponent* NS_EngineSmoke2; // 0xfb8(0x08)
	struct UNiagaraComponent* NS_DefenceSmoke2; // 0xfc0(0x08)

	void IFunc_GetEngineSmokeNiagaras(struct TArray<struct UNiagaraComponent*>& Niagaras); // Function BP_Armored_01.BP_Armored_01_C.IFunc_GetEngineSmokeNiagaras // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void UserConstructionScript(); // Function BP_Armored_01.BP_Armored_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
};

