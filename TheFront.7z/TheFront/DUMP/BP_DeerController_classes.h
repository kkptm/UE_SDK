// BlueprintGeneratedClass BP_DeerController.BP_DeerController_C
// Size: 0x890 (Inherited: 0x880)
struct ABP_DeerController_C : ALofnROg {
	struct UAIPerceptionComponent* AIPerception; // 0x880(0x08)
	struct AActor* PerceptionActor; // 0x888(0x08)
};

