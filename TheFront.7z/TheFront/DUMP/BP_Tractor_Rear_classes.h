// BlueprintGeneratedClass BP_Tractor_Rear.BP_Tractor_Rear_C
// Size: 0x220 (Inherited: 0x220)
struct UBP_Tractor_Rear_C : UChaosVehicleWheel {
};

