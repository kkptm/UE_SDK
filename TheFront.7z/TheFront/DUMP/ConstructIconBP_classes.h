// WidgetBlueprintGeneratedClass ConstructIconBP.ConstructIconBP_C
// Size: 0x294 (Inherited: 0x260)
struct UConstructIconBP_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* ButtonItem; // 0x268(0x08)
	struct UImage* ImageBack; // 0x270(0x08)
	struct UTextBlock* TextBlockItem; // 0x278(0x08)
	struct FString TextString; // 0x280(0x10)
	int32_t StructureID; // 0x290(0x04)

	void ResetCurrentStructure(int32_t SpecialStructureID); // Function ConstructIconBP.ConstructIconBP_C.ResetCurrentStructure // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void SetText(); // Function ConstructIconBP.ConstructIconBP_C.SetText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24b46a0
	void PreConstruct(bool IsDesignTime); // Function ConstructIconBP.ConstructIconBP_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void Construct(); // Function ConstructIconBP.ConstructIconBP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__ButtonItem_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function ConstructIconBP.ConstructIconBP_C.BndEvt__ButtonItem_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void BndEvt__ButtonItem_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function ConstructIconBP.ConstructIconBP_C.BndEvt__ButtonItem_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24b46a0
	void ExecuteUbergraph_ConstructIconBP(int32_t EntryPoint); // Function ConstructIconBP.ConstructIconBP_C.ExecuteUbergraph_ConstructIconBP // (Final|UbergraphFunction) // @ game+0x24b46a0
};

